# 🚀 Comment Lancer les Workflows - Guide Pratique

Guide étape par étape pour lancer vos premiers workflows GitHub Actions.

---

## 🎯 3 façons de lancer un workflow

---

## Méthode 1️⃣: Automatique (RECOMMANDÉE)

### Quand un workflow se lance automatiquement?

À chaque fois que vous faites un `git push` sur la branche `main`:

```bash
# Modifier votre code
nano src/App.js

# Stage les changements
git add src/App.js

# Commit
git commit -m "Update menu design"

# Push
git push origin main  ✅ WORKFLOW SE LANCE AUTOMATIQUEMENT!
```

### Vérifier l'exécution

1. Aller sur GitHub > votre repo
2. Cliquer **"Actions"** (en haut)
3. Vous verrez le workflow en cours: **🟠 En cours** ou **✅ Complété**

---

## Méthode 2️⃣: Manuel (Interface Web)

### Quand utiliser?

- Relancer un build sans modifier le code
- Tester un workflow spécifique
- Forcer un rebuild

### Étapes

1. **Aller sur GitHub Actions**
   - Ouvrir votre repo GitHub
   - Cliquer l'onglet **"Actions"**

2. **Sélectionner le workflow**
   - Liste à gauche: "Build APK - Complete"
   - Cliquer dessus

3. **Lancer manuellement**
   - Bouton bleu: **"Run workflow"**
   - Menu déroulant: Sélectionner branche (`main`)
   - Cliquer **"Run workflow"**

4. **Attendre**
   - Vous verrez: 🟠 In progress
   - Puis: ✅ Completed
   - Durée: ~15 minutes

5. **Télécharger l'APK**
   - Cliquer sur le run complété
   - Descendre à **"Artifacts"**
   - Télécharger `yaounde-delices-debug.zip`

---

## Méthode 3️⃣: Déclencher par Tag (GitHub Release)

### Quand utiliser?

- Créer une version officielle
- Générer Release notes
- Archiver les versions

### Étapes

```bash
# 1. Assurez-vous que tout est en place
git status  # Doit être propre

# 2. Créer un tag (version)
git tag -a v1.0.0 -m "Version 1.0.0 - First Release"

# 3. Pousser le tag
git push origin v1.0.0

# 4. GitHub Actions détecte le tag et:
# - Lance le workflow
# - Compile l'APK
# - Crée une GitHub Release
# - Attache l'APK à la release
```

### Voir la Release

1. GitHub > Releases (à droite)
2. Vous verrez: "v1.0.0" avec l'APK attaché
3. Télécharger directement depuis la Release

---

## 🎮 Comparaison des 3 méthodes

| Aspect | Automatique | Manuel | Tag |
|--------|-----------|--------|-----|
| Facilité | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| Quand | À chaque push | À la demande | Nouvelles versions |
| Durée | Immédiate | Immédiate | Immédiate |
| Résultat | Artifacts | Artifacts | GitHub Release |
| Recommandé | ✅ | ✅ | ✅ |

---

## 📋 Workflows disponibles

### **build-complete.yml** ⭐ PREMIER CHOIX

```yaml
# Se lance quand:
on:
  push:
    branches:
      - main
      - develop
  pull_request:
    branches:
      - main
  workflow_dispatch:  # ← Manuel possible
```

**Fonctionnalités:**
- ✅ Génère APK Debug ET Release
- ✅ Crée GitHub Releases automatiques
- ✅ Logs détaillés
- ✅ Summary post-build
- ⏱️ 15 minutes

**Comment l'utiliser:**
```bash
# Auto
git push origin main

# Manuel
GitHub > Actions > "Build APK - Complete" > "Run workflow"

# Tag
git tag v1.0.0 && git push origin v1.0.0
```

### **build-fast.yml** 🚀 DÉVELOPPEMENT

```yaml
on:
  push:
    branches: [main]
  workflow_dispatch:
```

**Fonctionnalités:**
- ✅ APK Debug seulement
- ✅ Plus rapide (10 min)
- ✅ Correction ajv incluse
- ✅ Cache npm

**Comment l'utiliser:**
```bash
git push origin main  # Auto
```

### **build-apk-simple.yml** 📱 DÉBUTANT

```yaml
on:
  push:
    branches: [main]
  workflow_dispatch:
```

**Fonctionnalités:**
- ✅ Ultra simple (8 min)
- ✅ Essentiels seulement
- ✅ Pas de complications

---

## ⏰ Temps d'exécution typique

| Étape | Durée |
|-------|-------|
| Checkout | 5s |
| Setup Java | 30s |
| Setup Android | 30s |
| Setup Node.js | 1m |
| npm install | 3m |
| Build React | 2m |
| Setup Capacitor | 1m |
| Build APK | 5m |
| Upload | 1m |
| **TOTAL** | **~13-15 min** |

---

## 🔍 Monitorer l'exécution

### En temps réel

1. GitHub > Actions
2. Cliquer le run en cours
3. Voir chaque step:
   - 🟢 Complétée
   - 🟡 En cours
   - 🔴 Échouée

### Logs détaillés

1. Actions > Run > Cliquer un step
2. Voir tous les détails
3. Si erreur: lire le message rouge

### Notifications

- **Email**: GitHub vous notifie si ❌ échoue
- **GitHub**: Badge ✅/❌ visible dans le repo

---

## 📥 Télécharger l'APK

### Depuis les Artifacts (tous les workflows)

1. **GitHub > Actions**
2. **Cliquer le run terminé** (✅)
3. **Descendre à "Artifacts"**
4. **Cliquer le dossier** (ex: `yaounde-delices-debug`)
5. **Le ZIP se télécharge**
6. **Extraire le `.apk`**

### Durée de stockage

```yaml
retention-days: 30  # Stocké pendant 30 jours
```

Après 30 jours, l'APK est supprimé automatiquement.

---

## ⚙️ Configuration recommandée

### Branches

```yaml
on:
  push:
    branches:
      - main      # ← Production prête
      - develop   # ← Tests en cours
```

### Fréquence

- **Quotidien**: Bonne pratique
- **À chaque push**: Idéal pour CI/CD
- **Hebdo**: Minimum

### Recommandation

Utiliser **build-complete.yml** avec:
- ✅ Auto-launch on main push
- ✅ Manual launch option (workflow_dispatch)
- ✅ Génération Release sur tag

---

## 🛠️ Dépannage

### Workflow n'apparaît pas

**Problème**: "Je ne vois pas le workflow dans Actions"

**Solution**:
1. Vérifier que le fichier `.yml` est dans `.github/workflows/`
2. Push le fichier: `git push origin main`
3. Rafraîchir GitHub (F5)
4. Attendre quelques secondes

### Workflow ne se lance pas automatiquement

**Problème**: "J'ai poussé du code, mais le workflow ne se lance pas"

**Solution**:
1. Vérifier la branche: Le workflow surveille `main` et `develop`
2. Vérifier que vous êtes sur la bonne branche:
   ```bash
   git branch  # Voir branche courante
   git checkout main  # Aller sur main
   ```
3. Pousser à nouveau: `git push origin main`

### Workflow échoue à "Fix dependencies & build"

**Problème**: npm install échoue avec erreur ajv

**Solution**:
- S'assurer que `package.json` a ajv et ajv-keywords
- Utiliser build-complete.yml (vérifie automatiquement)

### APK n'est pas dans Artifacts

**Problème**: "Pas d'artifact après le build réussi"

**Solution**:
1. Vérifier que le build s'est terminé avec ✅
2. Descendre complètement dans les artifacts
3. Si toujours rien: Le path du fichier est peut-être incorrect

---

## ✅ Checklist pour débuter

- [ ] Choisir un workflow (recommandé: build-complete.yml)
- [ ] Uploader le `.yml` dans `.github/workflows/`
- [ ] Committer et pousser
- [ ] Attendre quelques secondes
- [ ] Aller sur GitHub Actions
- [ ] Voir le workflow s'exécuter
- [ ] Attendre la compilation (~15 min)
- [ ] Télécharger l'APK depuis Artifacts
- [ ] Installer sur téléphone

---

## 🎉 Premier test réussi!

Une fois votre premier APK généré:

1. ✅ Télécharger le `.apk`
2. ✅ Envoyer à votre téléphone
3. ✅ Installer et tester
4. ✅ Célébrer! 🎉

Vous avez maintenant:
- ✅ Un workflow GitHub Actions fonctionnel
- ✅ Génération automatique d'APK
- ✅ Intégration continue (CI) en place

---

## 🚀 Prochaines étapes

1. **Utiliser régulièrement** - À chaque changement important
2. **Tester les changements** - Avant de pousser
3. **Versioning** - Utiliser des tags pour les releases
4. **Distribuer** - Mettre les APKs sur Google Play

---

**Bonne construction! 🏗️**

Chaque `git push` = nouvel APK généré automatiquement! 🚀
