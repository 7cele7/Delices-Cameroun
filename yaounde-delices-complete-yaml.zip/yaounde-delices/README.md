# 🍽️ Yaoundé Délices - Application de Livraison de Repas

Application web complète pour la livraison de repas camerounais authentiques à Yaoundé.

## ✨ Features

✅ **Menu dynamique** avec 10 plats populaires
✅ **Système de panier** avec modification en temps réel
✅ **localStorage** pour persistance automatique du panier
✅ **Formulaire de commande** avec validation
✅ **Calcul automatique des frais de livraison** (gratuit > 5000 FCFA)
✅ **Design responsive** - Optimisé mobile, tablette et desktop
✅ **Palette de couleurs** rouge (#E63946) et jaune (#F4A261)
✅ **Informations de contact** WhatsApp et Mobile Money
✅ **Confirmation de commande** avec résumé
✅ **PWA ready** - Peut être installée comme app native

## 🛠️ Tech Stack

- **Frontend**: React 18
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **State Management**: React Hooks
- **Storage**: Browser LocalStorage
- **Deployment**: Netlify / Vercel

## 📦 Installation

### Prérequis
- Node.js 16+ ([Télécharger](https://nodejs.org/))
- npm (inclus avec Node.js)
- Git (optionnel)

### Setup Local

```bash
# Cloner ou télécharger le projet
cd yaounde-delices

# Installer les dépendances
npm install

# Démarrer le serveur de développement
npm start

# Ouvrir http://localhost:3000 dans votre navigateur
```

### Build pour Production

```bash
# Créer le build optimisé
npm run build

# Tester le build localement
npm install -g serve
serve -s build
```

## 🚀 Déploiement

### Option 1: Netlify (Recommandé)

```bash
# Installer Netlify CLI
npm install -g netlify-cli

# Se connecter
netlify login

# Déployer
netlify deploy --prod --dir=build
```

**Ou via l'interface web:**
1. Aller sur https://app.netlify.com
2. Drag & drop le dossier `build/`
3. C'est en ligne! 🎉

### Option 2: Vercel

```bash
# Installer Vercel CLI
npm install -g vercel

# Déployer
vercel --prod
```

**Ou via GitHub + Vercel:**
1. Push sur GitHub
2. Importer le repo sur https://vercel.com
3. Déploiement automatique

### Option 3: GitHub Pages

```bash
# Modifier package.json
"homepage": "https://votreusername.github.io/yaounde-delices"

# Ajouter scripts
"predeploy": "npm run build",
"deploy": "gh-pages -d build"

# Installer et déployer
npm install --save-dev gh-pages
npm run deploy
```

## 📱 Structure du Projet

```
yaounde-delices/
├── public/
│   └── index.html
├── src/
│   ├── App.js (composant principal)
│   └── index.js
├── package.json
├── netlify.toml
└── README.md
```

## 🎨 Personnalisation

### Modifier les coordonnées

Éditer `src/App.js`:
```javascript
// Ligne ~450 (Footer)
<p>6X XX XX XX</p>  // WhatsApp
<p>6X XX XX XX</p>  // Mobile Money
```

### Ajouter/Modifier les plats

```javascript
const plats = [
  {
    id: 1,
    nom: 'Poulet DG',
    prix: 3500,
    categorie: 'Plat principal',
    description: 'Poulet mariné aux épices...',
    image: '🍗'
  },
  // Ajouter plus...
];
```

### Ajouter des zones de livraison

```javascript
<option value="Nouvelle Zone">Nouvelle Zone</option>
```

### Modifier les couleurs

- Rouge: `#E63946` (utiliser `bg-red-600`, `text-red-600`)
- Jaune: `#F4A261` (utiliser `bg-yellow-400`, `text-yellow-600`)

## 📧 Intégration Email

### Avec Formspree (Simple)

```javascript
// 1. Aller sur https://formspree.io
// 2. Créer un formulaire
// 3. Copier l'ID

const handleSubmitOrder = async (e) => {
  e.preventDefault();
  
  const formData = new FormData();
  formData.append('email', 'votreemail@gmail.com');
  formData.append('message', commandeText);
  
  await fetch('https://formspree.io/f/VOTRE_ID', {
    method: 'POST',
    body: formData
  });
};
```

### Avec EmailJS (Avancé)

```javascript
import emailjs from '@emailjs/browser';

// Setup
emailjs.init('YOUR_PUBLIC_KEY');

// Envoyer
emailjs.send('service_id', 'template_id', {
  to_email: 'votre@email.com',
  message: commandeText
});
```

## 📊 Analytics

### Google Analytics

```javascript
// Dans public/index.html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXX');
</script>
```

## 🔐 Sécurité

- ✅ Pas de données sensibles stockées côté client
- ✅ Validation des formulaires côté client
- ✅ Paiement à la livraison (pas de paiement en ligne)
- ✅ HTTPS automatique sur Netlify/Vercel

## ⚡ Optimisations

- Images emoji légères
- Lazy loading avec localStorage
- Cache service worker (PWA)
- Compression automatique

## 🐛 Dépannage

### "Cannot find module 'react'"
```bash
npm install
```

### Port 3000 déjà utilisé
```bash
npm start -- --port 3001
```

### Build échoue
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```

## 📞 Support & Améliorations Futures

- [ ] Intégration paiement mobile money
- [ ] Historique des commandes
- [ ] Programme de fidélité
- [ ] Notifications en temps réel
- [ ] Admin panel pour gérer les commandes
- [ ] Multi-langue (français/anglais)
- [ ] Dark mode

## 📄 Licence

MIT License - Utilisez librement pour Yaoundé Délices

## 🎯 Prochaines Étapes

1. **Domaine personnalisé**: Acheter un domaine `.cm` ou `.com`
2. **Logo**: Créer un logo professionnel
3. **Publicités**: Google Ads, Facebook Ads dans Yaoundé
4. **Partenariats**: Collaborer avec des restaurants
5. **Mobile App**: Convertir en app iOS/Android

---

**Créé avec ❤️ pour Yaoundé Délices**

Pour toute question ou amélioration, contactez le support.
