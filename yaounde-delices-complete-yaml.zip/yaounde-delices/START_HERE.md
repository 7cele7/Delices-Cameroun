# 🚀 COMMENCEZ ICI

Bienvenue dans **Yaoundé Délices**! Voici comment démarrer en 3 étapes.

## 📦 Vous avez reçu

Un fichier `yaounde-delices.zip` contenant l'application complète avec:
- ✅ Application React prête à l'emploi
- ✅ Design responsive & moderne
- ✅ Système de panier & commande
- ✅ Tous les guides & documentation

## 🎯 3 Étapes pour mettre en ligne

### Étape 1: Extraire le ZIP (30 secondes)

- **Sur Windows**: Double-cliquer le ZIP → "Extract All"
- **Sur Mac**: Double-cliquer le ZIP (s'extrait automatiquement)
- **Sur Linux**: `unzip yaounde-delices.zip`

Vous aurez un dossier `yaounde-delices/`

### Étape 2: Uploader sur GitHub (2 minutes)

1. Aller sur **https://github.com/signup** (créer compte si nécessaire)
2. Créer un nouveau repository: `yaounde-delices`
3. Cliquer "Upload files"
4. Drag & drop le dossier `yaounde-delices` complet
5. Message: "Initial commit"
6. Cliquer "Commit changes"

### Étape 3: Déployer sur Vercel (2 minutes)

1. Aller sur **https://vercel.com/signup**
2. Se connecter avec GitHub
3. Cliquer "New Project"
4. Sélectionner votre repository `yaounde-delices`
5. Cliquer "Deploy"

**Attendez 2-3 minutes... C'est en ligne! 🎉**

Votre URL: `https://yaounde-delices.vercel.app`

---

## 📚 Documentations incluses

Lire dans cet ordre:

1. **GITHUB_VERCEL_SETUP.md** ← Guide détaillé (commencer ici!)
2. **QUICK_START.md** ← Démarrage rapide 5min
3. **README.md** ← Documentation générale
4. **DEPLOYMENT_GUIDE.md** ← Déploiement avancé
5. **BONUS_FEATURES.md** ← Améliorations futures

## ⚙️ Personnaliser

### Ajouter vos numéros (Important!)

**Après déploiement sur Vercel:**

1. GitHub > Repository > `src/App.js`
2. Chercher "6X XX XX XX" (Ctrl+F)
3. Remplacer par vos vrais numéros:
   - WhatsApp: `697XXX XXX`
   - Mobile Money: `697XXX XXX`
4. Cliquer "Commit"
5. Vercel redéploiera automatiquement! ✨

### Modifier les plats

1. GitHub > `src/App.js`
2. Chercher `const plats = [`
3. Ajouter/Modifier les plats
4. Commit & redéploiement auto

---

## 🆘 Besoin d'aide?

Consultez:
- **GITHUB_VERCEL_SETUP.md** pour GitHub + Vercel
- **README.md** pour la documentation complète
- **YouTube**: Recherchez "GitHub beginner" ou "Vercel deploy"

---

## 📱 Tester localement (Optionnel)

Si vous avez **Node.js** installé:

```bash
cd yaounde-delices
npm install
npm start
# Ouvrir http://localhost:3000
```

---

## ✅ Checklist de démarrage

- [ ] Extraire le ZIP
- [ ] Créer compte GitHub
- [ ] Uploader sur GitHub
- [ ] Créer compte Vercel
- [ ] Déployer
- [ ] Remplacer les numéros
- [ ] Tester sur mobile
- [ ] Partager le lien!

---

**Vous êtes prêt! Commencez par GITHUB_VERCEL_SETUP.md 🚀**

Bonne chance! 🍽️
