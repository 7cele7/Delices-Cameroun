import React, { useState, useEffect } from 'react';
import { ShoppingCart, X, MapPin, Phone, DollarSign, Check } from 'lucide-react';

// Capacitor - Gestion app mobile
import { App } from '@capacitor/app';

export default function YaoundDelices() {
  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem('yaoundeCart');
    return saved ? JSON.parse(saved) : [];
  });
  const [currentStep, setCurrentStep] = useState('menu'); // menu, checkout, confirmation
  const [formData, setFormData] = useState({
    nom: '',
    telephone: '',
    quartier: ''
  });
  const [showCart, setShowCart] = useState(false);

  // Initialiser Capacitor et gestion du bouton retour
  useEffect(() => {
    const setupCapacitor = async () => {
      try {
        if (window.Capacitor) {
          // Gestion du bouton de retour Android
          await App.addListener('backButton', () => {
            if (currentStep !== 'menu') {
              setCurrentStep('menu');
            } else if (showCart) {
              setShowCart(false);
            }
          });
        }
      } catch (err) {
        console.log('Capacitor App plugin not available (running in web browser)');
      }
    };
    
    setupCapacitor();

    // Cleanup
    return () => {
      try {
        App.removeAllListeners();
      } catch (err) {
        console.log('Cleanup error');
      }
    };
  }, [currentStep, showCart]);

  // Sauvegarde automatique du panier
  useEffect(() => {
    localStorage.setItem('yaoundeCart', JSON.stringify(cart));
  }, [cart]);

  const plats = [
    { id: 1, nom: 'Poulet DG', prix: 3500, categorie: 'Plat principal', description: 'Poulet mariné aux épices, plantains et légumes', image: '🍗' },
    { id: 2, nom: 'Soya', prix: 2000, categorie: 'Grillade', description: 'Brochettes de bœuf épicées, oignons et piment', image: '🔥' },
    { id: 3, nom: 'Poisson braisé', prix: 4000, categorie: 'Poisson', description: 'Poisson frais au feu de bois, manioc et sauce', image: '🐟' },
    { id: 4, nom: 'Ragoût de bœuf', prix: 3000, categorie: 'Plat principal', description: 'Bœuf mijoté aux légumes, riz', image: '🍲' },
    { id: 5, nom: 'Ndolé', prix: 3500, categorie: 'Plat traditionnel', description: 'Feuilles de ndolé, crevettes, viande, plantain', image: '🥘' },
    { id: 6, nom: 'Brochettes de poulet', prix: 2500, categorie: 'Grillade', description: 'Brochettes marinées, sauce', image: '🍢' },
    { id: 7, nom: 'Poisson fumé', prix: 3500, categorie: 'Poisson', description: 'Poisson fumé, manioc et sauce', image: '🍖' },
    { id: 8, nom: 'Beignets de manioc', prix: 1000, categorie: 'Snack', description: 'Beignets croustillants, sauce', image: '🍴' },
    { id: 9, nom: 'Soya complet', prix: 3000, categorie: 'Grillade', description: 'Soya + plantain + sauce', image: '🔥' },
    { id: 10, nom: 'Riz sauté crevettes', prix: 3500, categorie: 'Poisson', description: 'Riz sauté, crevettes, légumes', image: '🍚' }
  ];

  const addToCart = (plat) => {
    const existing = cart.find(item => item.id === plat.id);
    if (existing) {
      setCart(cart.map(item => 
        item.id === plat.id ? { ...item, quantite: item.quantite + 1 } : item
      ));
    } else {
      setCart([...cart, { ...plat, quantite: 1 }]);
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const updateQuantity = (id, quantite) => {
    if (quantite <= 0) {
      removeFromCart(id);
    } else {
      setCart(cart.map(item =>
        item.id === id ? { ...item, quantite } : item
      ));
    }
  };

  const calculateTotal = () => {
    return cart.reduce((sum, item) => sum + (item.prix * item.quantite), 0);
  };

  const handleCheckout = () => {
    setCurrentStep('checkout');
    setShowCart(false);
  };

  const handleSubmitOrder = (e) => {
    e.preventDefault();
    
    const total = calculateTotal();
    const fraisLivraison = total >= 5000 ? 0 : 1000;
    const totalFinal = total + fraisLivraison;

    const commandeText = `
COMMANDE YAOUNDÉ DÉLICES
========================
Nom: ${formData.nom}
Téléphone: ${formData.telephone}
Quartier: ${formData.quartier}

DÉTAILS:
${cart.map(item => `- ${item.nom} x${item.quantite} = ${item.prix * item.quantite} FCFA`).join('\n')}

Sous-total: ${total} FCFA
Frais de livraison: ${fraisLivraison} FCFA
TOTAL: ${totalFinal} FCFA

Horaires: 11h-22h (lun-sam)
Contact WhatsApp: 6X XX XX XX
Mobile Money: 6X XX XX XX
    `;

    // Envoi par email ou stockage local
    console.log(commandeText);
    alert('Commande enregistrée ! Veuillez nous contacter sur WhatsApp pour confirmer.');
    
    // Réinitialiser
    setCart([]);
    setFormData({ nom: '', telephone: '', quartier: '' });
    setCurrentStep('confirmation');
    
    setTimeout(() => {
      setCurrentStep('menu');
    }, 3000);
  };

  // Page Menu
  const MenuPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-white via-yellow-50 to-red-50">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-red-600">🍽️ Yaoundé Délices</h1>
            <p className="text-sm text-gray-600">Cuisine camerounaise authentique • 11h-22h (lun-sam)</p>
          </div>
          <button
            onClick={() => setShowCart(true)}
            className="relative bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 transition"
          >
            <ShoppingCart size={20} />
            Panier ({cart.length})
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-yellow-400 text-red-600 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                {cart.reduce((sum, item) => sum + item.quantite, 0)}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-red-600 to-red-700 text-white py-12 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-2">Saveurs de Yaoundé</h2>
          <p className="text-xl">Livraison gratuite pour les commandes > 5000 FCFA</p>
          <p className="text-sm mt-2">Zones: Mvog-Mbi • Bastos • Mokolo</p>
        </div>
      </div>

      {/* Menu Grid */}
      <main className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {plats.map(plat => (
            <div key={plat.id} className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition transform hover:-translate-y-1 overflow-hidden">
              <div className="bg-gradient-to-r from-red-500 to-yellow-400 h-24 flex items-center justify-center text-6xl">
                {plat.image}
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-1">{plat.nom}</h3>
                <p className="text-sm text-yellow-600 font-semibold mb-2">{plat.categorie}</p>
                <p className="text-gray-600 text-sm mb-4">{plat.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-red-600">{plat.prix} FCFA</span>
                  <button
                    onClick={() => addToCart(plat)}
                    className="bg-yellow-400 hover:bg-yellow-500 text-gray-800 font-bold py-2 px-4 rounded-lg transition"
                  >
                    Ajouter
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Contact Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex items-start gap-3">
            <Phone size={20} className="text-yellow-400 mt-1" />
            <div>
              <p className="font-bold">WhatsApp</p>
              <p>6X XX XX XX</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <DollarSign size={20} className="text-yellow-400 mt-1" />
            <div>
              <p className="font-bold">Mobile Money</p>
              <p>6X XX XX XX</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <MapPin size={20} className="text-yellow-400 mt-1" />
            <div>
              <p className="font-bold">Zones de livraison</p>
              <p>Mvog-Mbi, Bastos, Mokolo</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );

  // Page Panier
  const CartPage = () => (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center md:justify-center">
      <div className="bg-white w-full md:max-w-2xl md:rounded-xl rounded-t-3xl h-screen md:h-auto md:max-h-96 flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-800">Votre Panier</h2>
          <button onClick={() => setShowCart(false)} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto p-6">
          {cart.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Votre panier est vide</p>
          ) : (
            <div className="space-y-4">
              {cart.map(item => (
                <div key={item.id} className="flex items-center justify-between bg-gray-50 p-4 rounded-lg">
                  <div className="flex-1">
                    <p className="font-bold text-gray-800">{item.nom}</p>
                    <p className="text-sm text-gray-600">{item.prix} FCFA x {item.quantite}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantite - 1)}
                      className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold w-8 h-8 rounded"
                    >
                      -
                    </button>
                    <span className="w-8 text-center font-bold">{item.quantite}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantite + 1)}
                      className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold w-8 h-8 rounded"
                    >
                      +
                    </button>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="ml-4 text-red-600 hover:text-red-800"
                    >
                      <X size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {cart.length > 0 && (
          <div className="border-t p-6 space-y-4">
            <div className="flex justify-between text-lg font-bold">
              <span>Total:</span>
              <span className="text-red-600">{calculateTotal()} FCFA</span>
            </div>
            <button
              onClick={handleCheckout}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-lg transition"
            >
              Passer la commande
            </button>
          </div>
        )}
      </div>
    </div>
  );

  // Page Checkout
  const CheckoutPage = () => {
    const total = calculateTotal();
    const fraisLivraison = total >= 5000 ? 0 : 1000;
    const totalFinal = total + fraisLivraison;

    return (
      <div className="min-h-screen bg-gradient-to-br from-white to-yellow-50 p-4">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <button
            onClick={() => setCurrentStep('menu')}
            className="text-red-600 hover:text-red-700 font-bold mb-6"
          >
            ← Retour au menu
          </button>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-6">Finaliser votre commande</h1>

            {/* Résumé */}
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <h2 className="font-bold text-lg mb-4 text-gray-800">Résumé</h2>
              {cart.map(item => (
                <div key={item.id} className="flex justify-between mb-2 text-gray-700">
                  <span>{item.nom} x{item.quantite}</span>
                  <span>{item.prix * item.quantite} FCFA</span>
                </div>
              ))}
              <div className="border-t border-gray-300 mt-4 pt-4">
                <div className="flex justify-between mb-2">
                  <span>Sous-total</span>
                  <span className="font-bold">{total} FCFA</span>
                </div>
                <div className="flex justify-between">
                  <span>Frais de livraison</span>
                  <span className={fraisLivraison === 0 ? 'text-green-600 font-bold' : 'font-bold'}>
                    {fraisLivraison === 0 ? '✓ GRATUIT' : fraisLivraison + ' FCFA'}
                  </span>
                </div>
              </div>
              <div className="border-t border-gray-300 mt-4 pt-4 flex justify-between">
                <span className="text-xl font-bold">TOTAL</span>
                <span className="text-3xl font-bold text-red-600">{totalFinal} FCFA</span>
              </div>
            </div>

            {/* Formulaire */}
            <form onSubmit={handleSubmitOrder} className="space-y-6">
              <div>
                <label className="block font-bold text-gray-800 mb-2">Votre nom *</label>
                <input
                  type="text"
                  required
                  value={formData.nom}
                  onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
                  className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 focus:border-red-600 focus:outline-none"
                  placeholder="Ex: Jean Dupont"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-800 mb-2">Téléphone *</label>
                <input
                  type="tel"
                  required
                  value={formData.telephone}
                  onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
                  className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 focus:border-red-600 focus:outline-none"
                  placeholder="Ex: 6XX XXX XXX"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-800 mb-2">Quartier / Adresse *</label>
                <select
                  required
                  value={formData.quartier}
                  onChange={(e) => setFormData({ ...formData, quartier: e.target.value })}
                  className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 focus:border-red-600 focus:outline-none"
                >
                  <option value="">Sélectionner un quartier</option>
                  <option value="Mvog-Mbi">Mvog-Mbi</option>
                  <option value="Bastos">Bastos</option>
                  <option value="Mokolo">Mokolo</option>
                </select>
              </div>

              {/* Mobile Money Info */}
              <div className="bg-yellow-50 border-2 border-yellow-400 rounded-lg p-4 mt-6">
                <p className="font-bold text-gray-800 mb-2">Paiement à la livraison</p>
                <p className="text-sm text-gray-700 mb-3">Préparez le montant exact ou versez via Mobile Money:</p>
                <div className="bg-white p-3 rounded border-2 border-yellow-400 text-center">
                  <p className="text-sm text-gray-600">Mobile Money</p>
                  <p className="text-2xl font-bold text-red-600">6X XX XX XX</p>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold py-4 rounded-lg text-lg transition"
              >
                Confirmer la commande
              </button>
            </form>

            <p className="text-sm text-gray-600 mt-6 text-center">
              Après confirmation, contactez-nous sur WhatsApp pour finaliser votre commande.
            </p>
          </div>
        </div>
      </div>
    );
  };

  // Page Confirmation
  const ConfirmationPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl p-8 text-center max-w-md">
        <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
          <Check size={32} className="text-white" />
        </div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Commande enregistrée!</h1>
        <p className="text-gray-600 mb-6">
          Merci pour votre commande. Veuillez nous contacter sur WhatsApp pour confirmer les détails.
        </p>
        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <p className="text-sm text-gray-600 mb-2">Contactez-nous:</p>
          <p className="text-2xl font-bold text-red-600">6X XX XX XX</p>
        </div>
        <button
          onClick={() => setCurrentStep('menu')}
          className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-lg"
        >
          Retour au menu
        </button>
      </div>
    </div>
  );

  return (
    <>
      {currentStep === 'menu' && <MenuPage />}
      {currentStep === 'checkout' && <CheckoutPage />}
      {currentStep === 'confirmation' && <ConfirmationPage />}
      {showCart && <CartPage />}
    </>
  );
}
