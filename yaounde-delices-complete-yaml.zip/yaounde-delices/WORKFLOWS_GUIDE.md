# 🤖 Workflows GitHub Actions - Guide Complet

Guide pour choisir et utiliser les workflows GitHub Actions optimisés pour générer des APK Android.

---

## 📋 Workflows disponibles

Vous avez **3 workflows** au choix dans `.github/workflows/`:

### 1. **build-complete.yml** ⭐ RECOMMANDÉ
- ✅ Workflow le plus robuste et complet
- ✅ Inclut la correction ajv
- ✅ Nettoie les caches npm
- ✅ Génère APK Debug et Release
- ✅ Crée GitHub Releases
- ✅ Logs détaillés et diagnostiques
- ✅ Summary post-build
- ⏱️ Durée: ~15 minutes

**Quand l'utiliser?**
- Production et déploiement régulier
- Quand vous avez des problèmes de dépendances
- Pour la génération de Release APK
- Quand vous voulez tous les détails

### 2. **build-fast.yml** 🚀 RAPIDE
- ✅ Version simplifiée et rapide
- ✅ Essentiels seulement
- ✅ Inclut la correction ajv
- ✅ Génère APK Debug
- ✅ Plus léger
- ⏱️ Durée: ~10 minutes

**Quand l'utiliser?**
- Développement rapide
- Tests fréquents
- Quand tout fonctionne bien
- Pour gagner du temps

### 3. **build-apk-simple.yml** 📱 ULTRA-SIMPLE
- ✅ Version minimale
- ✅ Dépannage basique
- ✅ APK Debug seulement
- ⏱️ Durée: ~8 minutes

**Quand l'utiliser?**
- Première fois / débutants
- Pas de problèmes connus
- Déploiement web d'abord

### 4. **build-android.yml** 🔧 LEGACY
- ⚠️ Ancienne version
- ❌ NON RECOMMANDÉE (utiliser build-complete.yml à la place)

---

## 🎯 Comparaison rapide

| Feature | Complete | Fast | Simple | Legacy |
|---------|----------|------|--------|--------|
| Correction ajv | ✅ | ✅ | ✅ | ❌ |
| APK Debug | ✅ | ✅ | ✅ | ✅ |
| APK Release | ✅ | ❌ | ❌ | ✅ |
| GitHub Releases | ✅ | ❌ | ❌ | ✅ |
| Cache npm | ✅ | ✅ | ❌ | ❌ |
| Summary report | ✅ | ❌ | ❌ | ❌ |
| Durée | 15 min | 10 min | 8 min | 15 min |
| Recommandé | ⭐⭐⭐ | ⭐⭐ | ⭐ | ❌ |

---

## 🚀 Comment utiliser un workflow

### Méthode 1: Activation automatique (recommandée)

Les workflows se lancent **automatiquement** quand vous poussez du code:

```bash
git add .
git commit -m "Update app"
git push origin main  # ✅ Workflow se lance automatiquement!
```

### Méthode 2: Lancement manuel

1. Allez sur GitHub > **Actions**
2. Sélectionnez le workflow (ex: "Build APK - Complete")
3. Cliquez **"Run workflow"**
4. Choisissez la branche
5. Cliquez **"Run workflow"**

### Méthode 3: Déclencher via tag (Release)

```bash
git tag v1.0.0
git push origin v1.0.0  # ✅ Crée une GitHub Release avec l'APK
```

---

## 📊 Séquence d'exécution du workflow

### build-complete.yml (le plus détaillé)

```
1. Checkout code
2. Setup Java 11
3. Setup Android SDK
4. Setup Node.js 18
5. Clean npm cache ← Important pour ajv!
6. Install dependencies ← npm ci avec ajv
7. Verify ajv ← Vérification supplémentaire
8. Build React app
9. Setup Capacitor
10. Build APK Debug
11. Upload APK Debug
12. Build APK Release (optionnel)
13. Upload APK Release
14. Create GitHub Release (si tag)
15. Build Success notification
16. Post build summary
```

### build-fast.yml (simplifié)

```
1. Checkout code
2. Setup Java 11
3. Setup Android SDK
4. Setup Node.js 18
5. Install dependencies (npm ci)
6. Verify ajv
7. Build React app
8. Setup Capacitor
9. Build APK
10. Upload APK
```

---

## 🔑 Points clés des workflows

### 1. **Clean npm cache** ✅

```yaml
- name: Clean npm cache
  run: |
    npm cache clean --force
    rm -rf node_modules
    rm -f package-lock.json
```

**Pourquoi?**
- Évite les conflits de versions
- Assure une installation fraîche
- Important pour la correction ajv

### 2. **npm ci vs npm install** ✅

```yaml
npm ci  # Utilise package-lock.json (déterministe)
# vs
npm install  # Peut modifier les versions
```

**Différence:**
- `npm ci` = **npm Clean Install** (recommandé pour CI/CD)
- `npm install` = Installation normale (peut causer des problèmes)

### 3. **Verify ajv dependency** ✅

```yaml
- name: Verify ajv dependency
  run: npm list ajv ajv-keywords || npm install ajv@^8.11.0 ajv-keywords@^5.1.0
```

**Pourquoi?**
- Double-vérification que ajv est installé
- Installe si manquant
- Prévient l'erreur "Cannot find module 'ajv/dist/compile/codegen'"

### 4. **Capacitor setup** ✅

```yaml
npx capacitor add android 2>/dev/null || true
npx capacitor sync android
```

**Explication:**
- `2>/dev/null` = Supprime les warnings
- `|| true` = Ignore les erreurs si déjà existant
- `sync` = Synchronise le code React avec le projet Android

### 5. **Gradle permissions** ✅

```yaml
chmod +x android/gradlew
```

**Pourquoi?**
- Windows peut ne pas avoir les bonnes permissions
- Linux/Mac ont besoin d'execute permissions
- Nécessaire avant `./gradlew`

---

## 📁 Quelle branche utiliser?

### Pour `build-complete.yml`:
```yaml
on:
  push:
    branches:
      - main      # ← Branche principale
      - develop   # ← Branche de développement
```

### Pour `build-fast.yml`:
```yaml
on:
  push:
    branches: [main]  # ← Seulement main
```

**Recommandation:**
- **main** = Production prête
- **develop** = Tests en cours
- Décider selon votre workflow Git

---

## 🔔 Notifications et résultats

### Où voir les résultats?

1. **GitHub > Actions** - Historique complet
2. **Log en temps réel** - Cliquer sur le run
3. **Artifacts** - Télécharger APK (30 jours)
4. **Email** - GitHub vous notifie si échec

### Interpréter les résultats

**✅ Vert (Succès)**
```
All steps passed
Artifacts uploaded
APK prêt à télécharger
```

**❌ Rouge (Échoue)**
```
Step échouée → Cliquer dessus pour voir les logs
Erreur affichée → Lire le message d'erreur
Ajuster et réessayer
```

---

## 🛠️ Dépannage rapide

### "ajv/dist/compile/codegen not found"
→ C'est corrigé dans tous les workflows!
→ Utilisez `build-complete.yml` qui vérifie explicitement

### "Cannot find gradle"
→ `chmod +x android/gradlew` manquant
→ build-complete.yml le fait automatiquement

### "npm install too slow"
→ Utilisez `build-fast.yml`
→ Ou utilisez le cache npm (build-complete.yml)

### "APK not generated"
→ Vérifier les logs complets (build-complete.yml)
→ S'assurer que `npm run build` réussit

---

## 📈 Optimiser les performances

### Cache gradle (économize ~5 min)

```yaml
- uses: actions/cache@v3
  with:
    path: |
      ~/.gradle/caches
      ~/.gradle/wrapper
    key: gradle-${{ runner.os }}
```

### Cache npm (économise ~2 min)

Automatique avec `actions/setup-node`:
```yaml
- uses: actions/setup-node@v4
  with:
    node-version: '18'
    cache: 'npm'  # ← Automatique!
```

### Désactiver source maps (réduit build time)

```yaml
env:
  GENERATE_SOURCEMAP: false
```

---

## 📋 Checklist de setup

- [ ] Choisir le workflow (recommandé: build-complete.yml)
- [ ] Uploader le workflow sur GitHub
- [ ] Pousser du code: `git push origin main`
- [ ] Vérifier Actions > Le workflow se lance
- [ ] Attendre la compilation
- [ ] Télécharger l'APK depuis Artifacts
- [ ] Tester sur téléphone

---

## 🎯 Workflows recommandés par cas

### **Cas 1: Production**
→ Utilisez `build-complete.yml`
- Génère Debug et Release
- Crée GitHub Releases
- Logs détaillés
- Notifications post-build

### **Cas 2: Développement actif**
→ Utilisez `build-fast.yml`
- Rapide (10 min)
- Essentiels seulement
- APK Debug prêt à tester

### **Cas 3: Débutant / Test**
→ Utilisez `build-apk-simple.yml`
- Très simple (8 min)
- Parfait pour apprendre
- Moins de configuration

### **Cas 4: Déploiement Google Play**
→ Utilisez `build-complete.yml` + signing
- Génère APK Release
- Peut être signé automatiquement
- Prêt pour Play Store

---

## ✨ Prochaines étapes

1. **Sélectionner un workflow** (recommandé: build-complete.yml)
2. **Pousser sur GitHub** (`git push origin main`)
3. **Attendre la compilation** (~10-15 min)
4. **Télécharger l'APK** (Actions > Artifacts)
5. **Tester sur téléphone** ✅

---

## 📚 Ressources

- [GitHub Actions Docs](https://docs.github.com/actions)
- [Android Gradle Plugin](https://developer.android.com/studio/releases/gradle-plugin)
- [Capacitor Docs](https://capacitorjs.com)

---

**Choix recommandé: build-complete.yml** ⭐

C'est le plus robuste et inclut toutes les corrections nécessaires!
