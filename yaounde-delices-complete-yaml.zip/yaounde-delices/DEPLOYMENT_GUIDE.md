# 🚀 Guide de Déploiement - Yaoundé Délices

## Option 1: Déploiement sur Netlify (RECOMMANDÉ - Gratuit & Simple)

### Étape 1: Préparer votre projet

1. Créez un dossier `yaounde-delices` sur votre ordinateur
2. Créez les fichiers suivants dans ce dossier:

#### `package.json`
```json
{
  "name": "yaounde-delices",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-scripts": "5.0.1",
    "lucide-react": "^0.263.1"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  },
  "eslintConfig": {
    "extends": [
      "react-app"
    ]
  },
  "browserslist": {
    "production": [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    "development": [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  }
}
```

#### `public/index.html`
```html
<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#E63946" />
    <meta name="description" content="Yaoundé Délices - Livraison de repas à Yaoundé" />
    <title>Yaoundé Délices - Livraison Repas</title>
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body>
    <noscript>Vous devez activer JavaScript pour utiliser cette application.</noscript>
    <div id="root"></div>
  </body>
</html>
```

#### `src/index.js`
```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

#### `src/App.js`
Copiez le contenu du fichier `yaounde-delices.jsx` fourni et renommez-le

### Étape 2: Installation locale

```bash
# Installer Node.js si ce n'est pas fait
# Télécharger depuis: https://nodejs.org/

# Dans le dossier du projet
npm install

# Tester localement
npm start
# Ouvrez http://localhost:3000 dans votre navigateur
```

### Étape 3: Déployer sur Netlify

#### Méthode A: Via GitHub (Recommandée)

1. **Créer un compte GitHub** (gratuit):
   - Allez sur https://github.com/signup
   - Créez un compte avec votre email

2. **Créer un repository**:
   - Cliquez sur "New" pour créer un nouveau repository
   - Nommez-le `yaounde-delices`
   - Sélectionnez "Add a README file"
   - Cliquez "Create repository"

3. **Uploader votre code**:
   ```bash
   # Dans votre dossier projet
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/VOTRE_USERNAME/yaounde-delices.git
   git push -u origin main
   ```

4. **Déployer sur Netlify**:
   - Allez sur https://app.netlify.com
   - Cliquez "Sign up" et connectez-vous avec GitHub
   - Cliquez "New site from Git"
   - Sélectionnez GitHub et votre repository `yaounde-delices`
   - Paramètres de build:
     - Build command: `npm run build`
     - Publish directory: `build`
   - Cliquez "Deploy site"

5. **Personnaliser le domaine**:
   - Dans les paramètres du site Netlify
   - Sous "Domain management", cliquez "Change site name"
   - Choisissez un nom comme `yaounde-delices` (sera: yaounde-delices.netlify.app)

#### Méthode B: Upload direct (Plus simple)

1. Allez sur https://app.netlify.com/drop
2. Déposez votre dossier `build/` (après `npm run build`)
3. Votre site est en ligne instantanément!

---

## Option 2: Déploiement sur Vercel

### Étape 1-2: Même préparation que Netlify

### Étape 3: Déployer sur Vercel

1. **Créer un compte Vercel**:
   - Allez sur https://vercel.com/signup
   - Connectez-vous avec GitHub

2. **Importer le projet**:
   - Cliquez "New Project"
   - Sélectionnez votre repository GitHub
   - Paramètres automatiques (Vercel détecte React)
   - Cliquez "Deploy"

3. **Accéder à votre site**:
   - URL: `yaounde-delices.vercel.app`

---

## Configuration personnalisée après déploiement

### 1. Mettre à jour vos coordonnées

Dans le fichier `src/App.js`, modifiez:

```javascript
// Ligne du numéro WhatsApp
<p>6X XX XX XX</p>

// Ligne du Mobile Money
<p>6X XX XX XX</p>
```

### 2. Modifier les zones de livraison

Dans le formulaire (section CheckoutPage):
```javascript
<option value="Mvog-Mbi">Mvog-Mbi</option>
<option value="Bastos">Bastos</option>
<option value="Mokolo">Mokolo</option>
```

### 3. Activer l'email de commande (Optional)

Pour envoyer les commandes par email, utilisez une service comme:

**Option A: EmailJS (Gratuit)**
```javascript
// npm install @emailjs/browser

import emailjs from '@emailjs/browser';

// Dans handleSubmitOrder:
emailjs.init('YOUR_PUBLIC_KEY'); // de emailjs.com
emailjs.send('service_xxx', 'template_xxx', {...});
```

**Option B: Formspree (Gratuit)**
- Allez sur https://formspree.io
- Créez un formulaire
- Récupérez l'ID
- Les emails seront envoyés à votre adresse

---

## Ajouter un domaine personnalisé

### Sur Netlify:
1. Achetez un domaine (.cm, .com, etc.)
2. Netlify > Site settings > Domain management
3. Custom domain > Ajouter votre domaine
4. Suivez les instructions DNS

### Sur Vercel:
1. Project settings > Domains
2. Ajouter votre domaine
3. Copier les enregistrements DNS chez votre registraire

---

## Dépannage

### "npm: command not found"
→ Installer Node.js: https://nodejs.org/

### L'app ne charge pas après déploiement
→ Vérifier les logs:
- Netlify: Site settings > Functions
- Vercel: Deployments > View logs

### Les images d'emoji ne s'affichent pas bien
→ Modifier dans App.js: utiliser des vrais images au lieu d'emojis:
```javascript
<img src="chicken.png" alt="Poulet DG" />
```

---

## Optimisations recommandées

1. **Ajouter un PWA** (Progressive Web App) pour mode hors ligne
2. **Intégrer WhatsApp Web** pour les commandes directes
3. **Ajouter Google Maps** pour localiser les zones de livraison
4. **Setup Analytics** avec Google Analytics ou Vercel Analytics

---

## Support

- 📧 Support Netlify: support@netlify.com
- 📧 Support Vercel: support@vercel.com
- 📖 Documentation React: https://react.dev

---

**Voilà! Votre app Yaoundé Délices est prête pour le monde! 🌍**
