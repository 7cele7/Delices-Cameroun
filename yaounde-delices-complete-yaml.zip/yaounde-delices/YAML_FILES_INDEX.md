# 📋 Index des Workflows YAML - Résumé Complet

Tous les fichiers `.yml` (workflows GitHub Actions) disponibles et comment les utiliser.

---

## 📂 Fichiers YAML dans `.github/workflows/`

### **1. build-complete.yml** ⭐ RECOMMANDÉ

**Emplacement**: `.github/workflows/build-complete.yml`

**Taille**: ~5 KB

**Durée**: ~15 minutes

**Points forts**:
- ✅ Workflow le plus robuste et complet
- ✅ Nettoie les caches npm
- ✅ Inclut la correction ajv explicite
- ✅ Génère APK Debug ET Release
- ✅ Crée GitHub Releases automatiques
- ✅ Summary report post-build
- ✅ Logs détaillés et diagnostiques

**Quand l'utiliser**:
- Production et déploiement régulier
- Quand vous avez des problèmes de dépendances
- Pour la génération de Release APK
- Quand vous voulez tous les détails

**Contenu clé**:
```yaml
- Clean npm cache
- npm ci (clean install)
- Verify ajv dependency
- Build React
- Setup Capacitor
- Build APK Debug & Release
- Upload artifacts
- Create GitHub Release (si tag)
- Post summary report
```

**Utilisation**:
```bash
# Auto
git push origin main

# Manuel
GitHub Actions > build-complete.yml > Run workflow
```

---

### **2. build-fast.yml** 🚀 RAPIDE

**Emplacement**: `.github/workflows/build-fast.yml`

**Taille**: ~1.5 KB

**Durée**: ~10 minutes

**Points forts**:
- ✅ Version simplifiée et rapide
- ✅ Inclut la correction ajv
- ✅ Essentiels seulement
- ✅ Génère APK Debug

**Quand l'utiliser**:
- Développement actif
- Tests fréquents
- Quand tout fonctionne bien
- Pour gagner du temps

**Contenu clé**:
```yaml
- Setup Java & Android
- Setup Node.js
- Clean npm cache
- npm ci
- Verify ajv
- Build React
- Setup Capacitor
- Build APK
- Upload artifact
```

**Utilisation**:
```bash
git push origin main  # Auto uniquement
```

---

### **3. build-apk-simple.yml** 📱 ULTRA-SIMPLE

**Emplacement**: `.github/workflows/build-apk-simple.yml`

**Taille**: ~1 KB

**Durée**: ~8 minutes

**Points forts**:
- ✅ Version minimale
- ✅ Dépannage basique
- ✅ Parfait pour débuter
- ✅ APK Debug seulement

**Quand l'utiliser**:
- Première fois
- Débutants
- Pas de problèmes connus
- Déploiement web d'abord

**Contenu clé**:
```yaml
- Setup Java, Android, Node.js
- npm ci
- Build React
- Setup Capacitor
- Build APK
- Upload artifact
```

**Utilisation**:
```bash
git push origin main  # Auto uniquement
```

---

### **4. build-android.yml** 🔧 LEGACY (NON RECOMMANDÉ)

**Emplacement**: `.github/workflows/build-android.yml`

**Taille**: ~3.2 KB

**Durée**: ~15 minutes

**Status**: ⚠️ Ancienne version

**Problèmes**:
- ❌ Pas de correction ajv explicite
- ❌ Versions SDK/Gradle potentially outdated
- ❌ Logs moins détaillés

**Recommandation**: **Utiliser build-complete.yml à la place** ⭐

---

## 🎯 Tableau comparatif

| Feature | Complete | Fast | Simple | Legacy |
|---------|----------|------|--------|--------|
| **Fichier** | build-complete.yml | build-fast.yml | build-apk-simple.yml | build-android.yml |
| **Taille** | ~5 KB | ~1.5 KB | ~1 KB | ~3.2 KB |
| **Durée** | 15 min | 10 min | 8 min | 15 min |
| Correction ajv | ✅ Explicite | ✅ Incluse | ✅ Incluse | ❌ Non |
| Clean cache | ✅ Oui | ✅ Oui | ❌ Non | ❌ Non |
| APK Debug | ✅ Oui | ✅ Oui | ✅ Oui | ✅ Oui |
| APK Release | ✅ Oui | ❌ Non | ❌ Non | ✅ Oui |
| GitHub Release | ✅ Oui | ❌ Non | ❌ Non | ✅ Oui |
| Summary report | ✅ Oui | ❌ Non | ❌ Non | ❌ Non |
| Logs détaillés | ✅ Oui | ⚠️ Standard | ⚠️ Basique | ⚠️ Standard |
| Recommandé | ⭐⭐⭐ | ⭐⭐ | ⭐ | ❌ |

---

## 🚀 Comment choisir?

```
┌─────────────────────────────┐
│ Quel est votre cas? │
└────────────┬────────────────┘
             │
    ┌────────┴────────┐
    │                 │
  PRODUCTION      DÉVELOPPEMENT
    │                 │
    │                 ├─→ Tests fréquents?
    │                 │   └─→ build-fast.yml 🚀
    │                 │
    │                 └─→ Première fois?
    │                     └─→ build-apk-simple.yml 📱
    │
    └─→ build-complete.yml ⭐
        (Google Play? Releases? Besoin de détails?)
```

---

## 📝 Contenu de build-complete.yml

Voici la structure complète du workflow recommandé:

```yaml
name: Build Android APK - Complete

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]
  workflow_dispatch:

env:
  JAVA_VERSION: 11
  ANDROID_API_LEVEL: 33
  ANDROID_BUILD_TOOLS_VERSION: 33.0.0
  NODE_VERSION: 18.x

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
      1. Checkout code
      2. Setup Java JDK 11
      3. Setup Android SDK
      4. Setup Node.js 18
      5. Clean npm cache          ← Important!
      6. Install dependencies (npm ci)
      7. Verify ajv dependency    ← Fix pour erreur!
      8. Build React application
      9. Setup Capacitor
      10. Grant gradle permissions
      11. Build APK (Debug)
      12. Upload APK Debug
      13. Build APK (Release)
      14. Upload APK Release
      15. Create GitHub Release (si tag)
      16. Build Success notification
      17. Build Failure notification
      18. Post build summary
```

---

## 📥 Clé: La correction AJV

La part la plus importante du workflow:

```yaml
- name: Verify critical dependencies
  run: |
    echo "Checking ajv installation..."
    npm list ajv ajv-keywords
    if [ $? -ne 0 ]; then
      echo "Installing missing dependencies..."
      npm install ajv@^8.11.0 ajv-keywords@^5.1.0
    fi
```

**Pourquoi?**
- Vérifie que ajv et ajv-keywords sont installés
- Installe automatiquement si manquant
- Prévient l'erreur "Cannot find module 'ajv/dist/compile/codegen'"

---

## 🎮 Utilisation pratique

### Exécution automatique

```bash
# Simple push
git add .
git commit -m "Update menu"
git push origin main

# ✅ Tous les workflows se lancent automatiquement!
```

### Lancement manuel

1. GitHub > Actions
2. Sélectionner le workflow: "Build Android APK - Complete"
3. Cliquer "Run workflow"
4. Choisir branche: `main`
5. Cliquer "Run workflow"

### Déclencher une GitHub Release

```bash
# Créer un tag
git tag -a v1.0.0 -m "Version 1.0.0"

# Pousser
git push origin v1.0.0

# ✅ Workflow se lance + GitHub Release créée
```

---

## 📊 Flux d'exécution détaillé

### build-complete.yml - Étape par étape

```
START
  ↓
Checkout code
  ↓
Setup Java 11
  ↓
Setup Android SDK 33
  ↓
Setup Node.js 18
  ↓
Clean npm cache ← Critique pour ajv!
  ↓
npm ci (clean install)
  ↓
Verify ajv dependency ← Fix principal!
  ↓
npm run build (React compile)
  ↓
Setup Capacitor Android
  ↓
chmod +x gradlew
  ↓
./gradlew assembleDebug
  ↓
Upload APK Debug
  ↓
./gradlew assembleRelease (optionnel)
  ↓
Upload APK Release (optionnel)
  ↓
Create GitHub Release (si tag)
  ↓
Post build summary
  ↓
SUCCESS ✅
```

---

## 🔑 Points critiques

### 1. **npm cache clean**
```yaml
npm cache clean --force
rm -rf node_modules
rm -f package-lock.json
```
→ Évite les conflits de versions

### 2. **npm ci au lieu de npm install**
```yaml
npm ci  # Utilise package-lock.json
```
→ Installation déterministe

### 3. **Verify ajv explicitement**
```yaml
npm list ajv ajv-keywords || npm install ajv@^8.11.0 ajv-keywords@^5.1.0
```
→ Double-vérification du fix

### 4. **Capacitor sync**
```yaml
npx capacitor add android 2>/dev/null || true
npx capacitor sync android
```
→ Synchronise React avec Android

---

## 🛠️ Modifier un workflow

### Exemple: Changer la branche

**Avant**:
```yaml
branches: [main]
```

**Après**:
```yaml
branches: [main, develop, staging]
```

### Exemple: Augmenter la rétention

**Avant**:
```yaml
retention-days: 30
```

**Après**:
```yaml
retention-days: 60
```

### Exemple: Changer Java version

**Avant**:
```yaml
JAVA_VERSION: 11
```

**Après**:
```yaml
JAVA_VERSION: 17
```

---

## ✅ Checklist pour débuter

- [ ] Choisir un workflow (recommandé: **build-complete.yml**)
- [ ] Vérifier que `.github/workflows/build-complete.yml` existe
- [ ] Vérifier que `package.json` a ajv et ajv-keywords
- [ ] Pousser sur GitHub
- [ ] Aller sur Actions
- [ ] Voir le workflow se lancer
- [ ] Attendre ~15 minutes
- [ ] Télécharger l'APK
- [ ] Tester sur téléphone

---

## 📚 Fichiers relatifs

Pour bien comprendre les workflows:

- **WORKFLOWS_GUIDE.md** - Guide détaillé des workflows
- **HOW_TO_RUN_WORKFLOWS.md** - Comment exécuter les workflows
- **FIX_AJV_ERROR.md** - Correction de l'erreur ajv
- **CORRECTIONS_SUMMARY.md** - Toutes les corrections appliquées

---

## 🎉 Résumé

| Votre besoin | Workflow à utiliser |
|-------------|-------------------|
| Production, détails, Release | build-complete.yml ⭐ |
| Développement rapide | build-fast.yml 🚀 |
| Première fois, débutant | build-apk-simple.yml 📱 |
| Éviter à tout prix | build-android.yml ❌ |

---

**Recommandation finale: Utilisez build-complete.yml** ⭐

C'est le plus robuste, inclut la correction ajv, et vous donne tous les détails!

---

**Prêt à lancer? `git push` et regardez la magie opérer! 🚀**
