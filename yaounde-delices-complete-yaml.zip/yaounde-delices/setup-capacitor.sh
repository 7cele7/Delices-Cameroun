#!/bin/bash

# Script de setup automatique pour Capacitor
# Usage: ./setup-capacitor.sh

echo "🚀 Setup Capacitor pour Yaoundé Délices"
echo "========================================"

# Vérifier Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js n'est pas installé"
    echo "Installer depuis: https://nodejs.org"
    exit 1
fi

echo "✅ Node.js installé: $(node --version)"

# Étape 1: Installer npm
echo ""
echo "📦 Étape 1: Installer les dépendances npm..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Erreur lors de l'installation npm"
    exit 1
fi
echo "✅ npm installé"

# Étape 2: Build React
echo ""
echo "🔨 Étape 2: Compiler React..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Erreur lors du build React"
    exit 1
fi
echo "✅ React compilé"

# Étape 3: Ajouter Capacitor Android
echo ""
echo "📱 Étape 3: Ajouter Capacitor Android..."
npx capacitor add android 2>/dev/null || true

if [ $? -ne 0 ]; then
    echo "⚠️  Capacitor Android peut être déjà ajouté"
fi
echo "✅ Capacitor Android configuré"

# Étape 4: Synchroniser
echo ""
echo "🔄 Étape 4: Synchroniser les fichiers..."
npx capacitor sync android

if [ $? -ne 0 ]; then
    echo "❌ Erreur lors de la synchronisation"
    exit 1
fi
echo "✅ Synchronisation complète"

# Étape 5: Résumé
echo ""
echo "========================================"
echo "✅ Setup Capacitor terminé!"
echo "========================================"
echo ""
echo "📋 Prochaines étapes:"
echo "1. Installer Android Studio:"
echo "   https://developer.android.com/studio"
echo ""
echo "2. Ouvrir le projet Android:"
echo "   npm run cap:open"
echo ""
echo "3. Builder l'APK via Android Studio:"
echo "   Build > Build APK(s)"
echo ""
echo "Ou via CLI:"
echo "   cd android && ./gradlew assembleDebug"
echo ""
echo "📚 Documentation complète:"
echo "   Voir CAPACITOR_SETUP.md"
echo ""
echo "🎉 Bonne chance!"
