# 🍽️ Yaoundé Délices - Application de Livraison de Repas à Yaoundé

Application web moderne, rapide et responsive conçue pour la commande et la livraison de repas traditionnels et grillades dans tous les quartiers de **Yaoundé, Cameroun** (Bastos, Mvog-Mbi, Mokolo, Etoudi, Nlongkak, Omnisports, Biyem-Assi, Odza, etc.).

---

## 🌟 Fonctionnalités Principales

1. **📍 Géolocalisation GPS Intégrée :**
   - Bouton « 📍 *Utiliser ma position GPS* » qui interroge les coordonnées satellites exactes du client.
   - Détection automatique du quartier et pré-remplissage de l'adresse.
   - Génération d'un lien Google Maps direct transmis au livreur.
   - Saisie manuelle du quartier et des repères (ex: *Face station, portail noir...*).

2. **🍽️ Menu & Personnalisation Complète des Plats :**
   - Affichage en grille optimisé (2 colonnes sur mobile).
   - Filtres par catégories : *Plats principaux*, *Grillades*, *Poissons*, *Plats traditionnels*, *Snacks*, *Boissons locales*.
   - Choix des accompagnements (Plantains frits, Bâton de manioc, Frites, Riz) et instructions personnalisées.
   - **Espace Gérant intégré** : Bouton ⚙️ permettant d'ajouter vos propres plats, modifier les prix, uploader vos photos de plats depuis votre appareil et gérer les stocks.

3. **🛒 Panier & Calcul des Frais de Livraison :**
   - Calcul en temps réel du sous-total.
   - **Livraison GRATUITE** automatique pour toute commande ≥ 5 000 FCFA.
   - Barre de progression dynamique incitant le client à atteindre le palier gratuit.

4. **📲 Validation & Envoi de Commande :**
   - **Commande direct WhatsApp** : Génère un message formaté avec émojis, récapitulatif détaillé, total, nom, téléphone et lien Google Maps GPS du client.
   - **Validation en ligne** : Génération de ticket (#YD-XXXXX) avec animations confettis et suivi en direct de la commande (Reçue ➔ En cuisine ➔ En route ➔ Livrée).

5. **💳 Paiement Mobile Money & Espèces :**
   - Prise en charge des espèces à la livraison.
   - Prise en charge de **MTN Mobile Money** (affichage du numéro, nom du titulaire, bouton « Copier le numéro »).

---

## 🚀 Déploiement & Hébergement

L'application est prête à être déployée immédiatement sur **Vercel** ou **Netlify** grâce aux fichiers de configuration inclus (`vercel.json` et `netlify.toml`).

### Déploiement Vercel :
1. Importez le projet sur GitHub ou directement sur Vercel.
2. La commande de build `npm run build` et le dossier de sortie `dist` sont configurés automatiquement.

### Déploiement Netlify :
1. Glissez-déposez le dossier de build ou connectez votre repo Git.
2. Le fichier `netlify.toml` assure la redirection SPA automatique.

---

## 🛠️ Technologies Utilisées
- **React 19** + **TypeScript**
- **Vite** (Build ultrarapide)
- **Tailwind CSS** (Design moderne et mobile-first)
- **Lucide Icons**
- **HTML5 Geolocation API & OpenStreetMap Nominatim**
- **Canvas-Confetti**
