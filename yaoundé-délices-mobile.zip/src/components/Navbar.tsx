import React from 'react';
import { ShoppingBag, Phone, Clock, UtensilsCrossed, Settings, MapPin, Truck } from 'lucide-react';
import { RestaurantConfig } from '../types';
import { isRestaurantOpen, formatFCFA } from '../utils/formatters';

interface NavbarProps {
  config: RestaurantConfig;
  cartCount: number;
  cartTotal: number;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenCart: () => void;
  onOpenAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  config,
  cartCount,
  cartTotal,
  activeTab,
  setActiveTab,
  onOpenCart,
  onOpenAdmin,
}) => {
  const openStatus = isRestaurantOpen(config.openingTime, config.closingTime);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-amber-100 shadow-xs">
      {/* Top emergency announcement bar */}
      <div className="bg-gradient-to-r from-rose-600 via-rose-500 to-amber-500 text-white text-xs py-1.5 px-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between font-medium">
          <div className="flex items-center gap-2 truncate">
            <span className="bg-white/20 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
              Yaoundé
            </span>
            <span className="truncate">
              🛵 Livraison à domicile • <strong>GRATUITE dès {formatFCFA(config.freeDeliveryThreshold)}</strong>
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-3 shrink-0 text-amber-100">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {config.workingDays} : {config.openingTime} - {config.closingTime}
            </span>
            <span>•</span>
            <a
              href={`tel:${config.phoneCall.replace(/\s+/g, '')}`}
              className="hover:underline flex items-center gap-1 font-bold text-white"
            >
              <Phone className="w-3.5 h-3.5" />
              {config.phoneCall}
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-2">
        {/* Brand Logo */}
        <div
          id="brand-logo-btn"
          onClick={() => setActiveTab('accueil')}
          className="flex items-center gap-2.5 cursor-pointer group select-none"
        >
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-br from-rose-600 to-amber-500 flex items-center justify-center text-white shadow-md shadow-rose-500/20 group-hover:scale-105 transition-transform duration-200">
            <UtensilsCrossed className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-display font-extrabold text-xl sm:text-2xl text-stone-900 tracking-tight leading-none">
                Yaoundé<span className="text-rose-600">Délices</span>
              </span>
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="En service" />
            </div>
            <div className="flex items-center gap-1.5 text-[11px] font-medium text-stone-500">
              <span className="truncate">Mets camerounais • Livraison à domicile</span>
              <span className="text-stone-300">•</span>
              <span className={openStatus.isOpen ? 'text-emerald-600 font-semibold' : 'text-amber-700'}>
                {openStatus.isOpen ? 'Ouvert' : 'Fermé'}
              </span>
            </div>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 bg-amber-50/80 p-1 rounded-xl border border-amber-100/80 text-sm font-medium">
          <button
            id="nav-tab-accueil"
            onClick={() => setActiveTab('accueil')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              activeTab === 'accueil'
                ? 'bg-white text-rose-600 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Accueil
          </button>
          <button
            id="nav-tab-menu"
            onClick={() => setActiveTab('menu')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              activeTab === 'menu'
                ? 'bg-white text-rose-600 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Notre Carte
          </button>
          <button
            id="nav-tab-commandes"
            onClick={() => setActiveTab('commandes')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              activeTab === 'commandes'
                ? 'bg-white text-rose-600 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Suivi Commandes
          </button>
          <button
            id="nav-tab-contact"
            onClick={() => setActiveTab('contact')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              activeTab === 'contact'
                ? 'bg-white text-rose-600 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Livraison & Contact
          </button>
          <button
            id="nav-tab-apropos"
            onClick={() => setActiveTab('apropos')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              activeTab === 'apropos'
                ? 'bg-white text-rose-600 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            À Propos
          </button>
        </nav>

        {/* Right Actions: Cart Button */}
        <div className="flex items-center gap-2">
          {/* Cart Button */}
          <button
            id="btn-header-cart"
            onClick={onOpenCart}
            className="relative flex items-center gap-2 bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-700 hover:to-rose-600 text-white px-3 sm:px-4 py-2 rounded-xl shadow-md shadow-rose-600/20 active:scale-95 transition-all"
          >
            <div className="relative">
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-amber-400 text-stone-900 text-[11px] font-black rounded-full h-5 w-5 flex items-center justify-center border-2 border-white shadow-xs">
                  {cartCount}
                </span>
              )}
            </div>
            <div className="text-left leading-tight hidden sm:block">
              <div className="text-[10px] uppercase font-bold text-rose-100 tracking-wider">Panier</div>
              <div className="text-xs font-extrabold">{formatFCFA(cartTotal)}</div>
            </div>
          </button>
        </div>
      </div>

      {/* Mobile bottom navigation bar is handled in MobileNav */}
    </header>
  );
};
