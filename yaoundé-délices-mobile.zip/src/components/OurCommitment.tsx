import React from 'react';

export const OurCommitment: React.FC = () => {
  const commitments = [
    { title: 'Sélection rigoureuse', desc: 'Fournisseurs de confiance et ingrédients frais' },
    { title: 'Conditionnement soigné', desc: 'Emballages hermétiques adaptés au transport' },
    { title: 'Livraison fiable', desc: 'Remise en main propre dans les meilleures conditions' },
    { title: 'Transparence', desc: 'Prix clairs, portions précises et sans surprise' },
  ];

  return (
    <section className="bg-white rounded-2xl p-4 sm:p-6 border border-stone-200 shadow-2xs">
      <div className="space-y-3">
        <div>
          <h2 className="font-display font-extrabold text-lg sm:text-xl text-stone-900">
            Notre engagement
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm mt-1 leading-relaxed max-w-3xl">
            Des mets soigneusement sélectionnés auprès de fournisseurs de confiance, conditionnés avec soin et livrés directement chez vous.
          </p>
        </div>

        {/* 4 Compact Points */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-1">
          {commitments.map((item, idx) => (
            <div
              key={idx}
              className="p-3 rounded-xl bg-stone-50/80 border border-stone-200/70 flex items-start gap-2.5"
            >
              <span className="text-emerald-600 font-black text-sm shrink-0 mt-0.5">✓</span>
              <div>
                <h3 className="font-bold text-stone-900 text-xs sm:text-sm">
                  {item.title}
                </h3>
                <p className="text-[11px] text-stone-500 mt-0.5 leading-snug">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

