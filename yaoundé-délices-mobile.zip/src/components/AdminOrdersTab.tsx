import React, { useState, useMemo } from 'react';
import {
  ShoppingBag,
  Search,
  Filter,
  Calendar,
  MapPin,
  Phone,
  MessageCircle,
  Clock,
  CheckCircle2,
  XCircle,
  Trash2,
  Edit3,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Plus,
  Send,
  Bike,
  ChefHat,
  PackageCheck,
  RotateCcw,
  Sparkles,
  Save,
  X
} from 'lucide-react';
import { Order, OrderStatus, RestaurantConfig } from '../types';
import { formatFCFA } from '../utils/formatters';
import { soundNotifier } from '../utils/audioAlert';

interface AdminOrdersTabProps {
  orders: Order[];
  config: RestaurantConfig;
  initialStatusFilter?: string;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, note?: string, cancellationReason?: string) => void;
  onDeleteOrder?: (orderId: string) => void;
  onAddOrder?: (newOrder: Order) => void;
  showToast: (msg: string) => void;
}

export const AdminOrdersTab: React.FC<AdminOrdersTabProps> = ({
  orders,
  config,
  initialStatusFilter = 'all',
  onUpdateOrderStatus,
  onDeleteOrder,
  onAddOrder,
  showToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>(initialStatusFilter);
  const [periodFilter, setPeriodFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [neighborhoodFilter, setNeighborhoodFilter] = useState<string>('all');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);

  // Note Edit Modal / Inline
  const [editingNoteOrderId, setEditingNoteOrderId] = useState<string | null>(null);
  const [tempNoteText, setTempNoteText] = useState('');

  // Cancel Modal with reason
  const [cancellingOrderId, setCancellingOrderId] = useState<string | null>(null);
  const [cancellationReason, setCancellationReason] = useState('');

  // Extract unique neighborhoods from orders + config
  const availableNeighborhoods = useMemo(() => {
    const set = new Set<string>();
    config.deliveryZones.forEach(z => set.add(z));
    orders.forEach(o => {
      if (o.neighborhood) set.add(o.neighborhood);
    });
    return Array.from(set).sort();
  }, [config.deliveryZones, orders]);

  // Filtered Orders
  const filteredOrders = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const weekStart = todayStart - 6 * 24 * 3600 * 1000;
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();

    return orders.filter(order => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = order.customerName.toLowerCase().includes(q);
        const matchesPhone = order.customerPhone.toLowerCase().includes(q);
        const matchesId = order.id.toLowerCase().includes(q);
        const matchesNeigh = (order.neighborhood || '').toLowerCase().includes(q);
        if (!matchesName && !matchesPhone && !matchesId && !matchesNeigh) return false;
      }

      // Status
      if (statusFilter === 'pending') {
        if (order.status !== 'received' && order.status !== 'preparing') return false;
      } else if (statusFilter !== 'all') {
        if (order.status !== statusFilter) return false;
      }

      // Period
      const orderTime = new Date(order.createdAt).getTime();
      if (periodFilter === 'today' && orderTime < todayStart) return false;
      if (periodFilter === 'week' && orderTime < weekStart) return false;
      if (periodFilter === 'month' && orderTime < monthStart) return false;

      // Neighborhood
      if (neighborhoodFilter !== 'all' && order.neighborhood !== neighborhoodFilter) {
        return false;
      }

      return true;
    });
  }, [orders, searchQuery, statusFilter, periodFilter, neighborhoodFilter]);

  // Change Status
  const handleStatusChange = (orderId: string, newStatus: OrderStatus) => {
    onUpdateOrderStatus(orderId, newStatus);
    soundNotifier.playStatusChangeAlert();
    const labels: Record<OrderStatus, string> = {
      received: 'Reçue',
      preparing: 'En préparation',
      on_the_way: 'En route',
      delivered: 'Livrée',
      cancelled: 'Annulée',
    };
    showToast(`Commande ${orderId} marquée comme : ${labels[newStatus]}`);
  };

  // Save Note
  const handleSaveNote = (order: Order) => {
    onUpdateOrderStatus(order.id, order.status, tempNoteText);
    setEditingNoteOrderId(null);
    setTempNoteText('');
    showToast(`Note administrative enregistrée sur ${order.id}`);
  };

  // Confirm Cancellation
  const handleConfirmCancel = () => {
    if (!cancellingOrderId) return;
    const reason = cancellationReason.trim() || 'Annulée par le restaurant';
    onUpdateOrderStatus(cancellingOrderId, 'cancelled', undefined, reason);
    soundNotifier.playStatusChangeAlert();
    showToast(`Commande ${cancellingOrderId} annulée.`);
    setCancellingOrderId(null);
    setCancellationReason('');
  };

  // Send WhatsApp notification to client
  const handleNotifyCustomer = (order: Order) => {
    const cleanPhone = order.customerPhone.replace(/\D/g, '');
    const phoneWithPrefix = cleanPhone.startsWith('237') ? cleanPhone : `237${cleanPhone}`;
    
    let message = '';
    if (order.status === 'preparing') {
      message = `Bonjour ${order.customerName} ! 🍲 Votre commande #${order.id} chez Yaoundé Délices est actuellement EN COURS DE PRÉPARATION en cuisine. Elle sera prête très bientôt !`;
    } else if (order.status === 'on_the_way') {
      message = `Bonjour ${order.customerName} ! 🛵 Bonne nouvelle : votre commande #${order.id} est EN ROUTE vers votre adresse (${order.neighborhood}). Le livreur arrive !`;
    } else if (order.status === 'delivered') {
      message = `Bonjour ${order.customerName} ! ✅ Votre commande #${order.id} a été marquée comme LIVRÉE. Toute l'équipe de Yaoundé Délices vous remercie et vous souhaite un excellent appétit ! 🇨🇲`;
    } else {
      message = `Bonjour ${order.customerName} ! Nous vous confirmons la bonne réception de votre commande #${order.id} (Montant: ${formatFCFA(order.total)}) chez Yaoundé Délices.`;
    }

    const url = `https://wa.me/${phoneWithPrefix}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  // Generate Sample Test Order
  const handleGenerateTestOrder = () => {
    const randomNum = Math.floor(100000 + Math.random() * 900000);
    const mockNames = ['Alexandre N.', 'Sandrine M.', 'Boris K.', 'Jeanne E.', 'Célestin T.'];
    const mockZones = ['Bastos', 'Mvog-Mbi', 'Mokolo', 'Biyem-Assi', 'Odza', 'Etoudi'];
    const randomName = mockNames[Math.floor(Math.random() * mockNames.length)];
    const randomZone = mockZones[Math.floor(Math.random() * mockZones.length)];

    const testOrder: Order = {
      id: `CMD-${randomNum}`,
      createdAt: new Date().toISOString(),
      items: [
        {
          id: `test-item-${Date.now()}`,
          item: {
            id: 'met-1',
            name: 'Poulet DG Royal Traditionnel',
            category: '🍃 Légumes & Feuilles',
            subcategory: 'Spécialités',
            description: 'Poulet fermier mijoté aux plantains.',
            image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=600&auto=format&fit=crop&q=80',
            availability: 'disponible',
            portions: [{ id: 'standard', name: 'Standard (1-2 pers.)', price: 4500 }],
            includedAccompaniments: ['Plantains frits'],
          },
          quantity: 1,
          selectedPortion: { id: 'standard', name: 'Standard (1-2 pers.)', price: 4500 },
          selectedAccompaniment: 'Plantains frits',
          selectedExtraAccompaniments: [],
          selectedSupplements: [],
          selectedPreparationOptions: ['Piment doux'],
          unitPrice: 4500,
          totalPrice: 4500,
        }
      ],
      subtotal: 4500,
      deliveryFee: 1000,
      total: 5500,
      customerName: randomName,
      customerPhone: `67${Math.floor(1000000 + Math.random() * 8999999)}`,
      neighborhood: randomZone,
      manualAddress: 'Adresse test générée pour la démonstration',
      landmark: 'Face carrefour principal',
      paymentMethod: 'momo',
      status: 'received',
      adminNote: 'Commande de test automatique',
    };

    if (onAddOrder) {
      onAddOrder(testOrder);
    }
    soundNotifier.playNewOrderAlert();
    showToast(`Nouvelle commande test #${testOrder.id} créée ! (Alerte sonore jouée)`);
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'received':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            <span>Reçue (En attente)</span>
          </span>
        );
      case 'preparing':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-900 border border-orange-300">
            <ChefHat className="w-3 h-3 text-orange-600" />
            <span>En préparation</span>
          </span>
        );
      case 'on_the_way':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-900 border border-blue-300">
            <Bike className="w-3 h-3 text-blue-600" />
            <span>En route</span>
          </span>
        );
      case 'delivered':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>Livrée</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-red-100 text-red-900 border border-red-300">
            <XCircle className="w-3 h-3 text-red-600" />
            <span>Annulée</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-4">
      {/* Header & Quick Create Test Order */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-stone-50 p-4 rounded-2xl border border-stone-200">
        <div>
          <h3 className="font-display font-extrabold text-stone-900 text-sm sm:text-base flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-amber-600" />
            <span>Gestion des Commandes en Temps Réel</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-stone-200 text-stone-700">
              {filteredOrders.length} / {orders.length}
            </span>
          </h3>
          <p className="text-xs text-stone-500 mt-0.5">
            Suivi des statuts, appels clients, notes et affectation des livreurs.
          </p>
        </div>

        <button
          type="button"
          onClick={handleGenerateTestOrder}
          className="bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-2xs transition-all active:scale-95 cursor-pointer shrink-0"
          title="Créer une commande de test pour vérifier la réception et les alertes"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>+ Créer commande test</span>
        </button>
      </div>

      {/* FILTER CONTROLS BAR (Search, Status, Period, Neighborhood) */}
      <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
        {/* Search & Period */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
          <div className="relative sm:col-span-6">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher client, tél, n° de commande..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-300 bg-stone-50/60 text-stone-900 font-medium placeholder:text-stone-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Period selector */}
          <div className="sm:col-span-3">
            <select
              value={periodFilter}
              onChange={(e) => setPeriodFilter(e.target.value as any)}
              className="w-full py-2 px-3 text-xs rounded-xl border border-stone-300 bg-stone-50/60 text-stone-800 font-bold focus:outline-none"
            >
              <option value="all">Toutes les dates</option>
              <option value="today">Aujourd'hui</option>
              <option value="week">7 derniers jours</option>
              <option value="month">Ce mois</option>
            </select>
          </div>

          {/* Neighborhood filter */}
          <div className="sm:col-span-3">
            <select
              value={neighborhoodFilter}
              onChange={(e) => setNeighborhoodFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-xl border border-stone-300 bg-stone-50/60 text-stone-800 font-bold focus:outline-none"
            >
              <option value="all">Tous les quartiers ({availableNeighborhoods.length})</option>
              {availableNeighborhoods.map(zone => (
                <option key={zone} value={zone}>{zone}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Status Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'all'
                ? 'bg-stone-900 text-white shadow-2xs'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            Tous ({orders.length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('pending')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1 ${
              statusFilter === 'pending'
                ? 'bg-amber-500 text-stone-950 shadow-2xs'
                : 'bg-amber-50 text-amber-900 hover:bg-amber-100'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <span>En attente ({orders.filter(o => o.status === 'received' || o.status === 'preparing').length})</span>
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('received')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'received'
                ? 'bg-amber-500 text-stone-950'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            Reçues ({orders.filter(o => o.status === 'received').length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('preparing')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'preparing'
                ? 'bg-orange-500 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            En préparation ({orders.filter(o => o.status === 'preparing').length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('on_the_way')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'on_the_way'
                ? 'bg-blue-600 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            En route ({orders.filter(o => o.status === 'on_the_way').length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('delivered')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'delivered'
                ? 'bg-emerald-600 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            Livrées ({orders.filter(o => o.status === 'delivered').length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('cancelled')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'cancelled'
                ? 'bg-red-600 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            Annulées ({orders.filter(o => o.status === 'cancelled').length})
          </button>
        </div>
      </div>

      {/* ORDERS LIST */}
      {filteredOrders.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl border border-stone-200 text-center space-y-3">
          <ShoppingBag className="w-10 h-10 text-stone-300 mx-auto" />
          <h4 className="font-bold text-stone-700 text-sm">Aucune commande trouvée</h4>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            Aucune commande ne correspond aux filtres sélectionnés. Vous pouvez réinitialiser les filtres ou créer une commande de test.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setStatusFilter('all');
              setPeriodFilter('all');
              setNeighborhoodFilter('all');
            }}
            className="text-xs font-bold text-amber-700 underline cursor-pointer"
          >
            Réinitialiser tous les filtres
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredOrders.map(order => {
            const isExpanded = expandedOrderId === order.id;
            const orderDate = new Date(order.createdAt).toLocaleString('fr-FR', {
              day: '2-digit',
              month: 'short',
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <div
                key={order.id}
                className={`bg-white rounded-2xl border transition-all shadow-2xs overflow-hidden ${
                  order.status === 'received'
                    ? 'border-amber-300 ring-2 ring-amber-400/20'
                    : order.status === 'preparing'
                    ? 'border-orange-300'
                    : 'border-stone-200'
                }`}
              >
                {/* Header Summary Row */}
                <div className="p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-stone-50/50">
                  <div className="flex items-start sm:items-center gap-3">
                    {/* Status Pill */}
                    {getStatusBadge(order.status)}

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-stone-900 text-xs sm:text-sm">
                          #{order.id}
                        </span>
                        <span className="text-[11px] text-stone-400 font-medium">
                          • {orderDate}
                        </span>
                      </div>
                      <div className="text-xs font-bold text-stone-900 flex items-center gap-1.5 mt-0.5">
                        <span>{order.customerName}</span>
                        <span className="text-stone-300">|</span>
                        <span className="text-stone-600 font-medium flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-rose-500" />
                          {order.neighborhood}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Side: Total & Expand Toggle */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-0 border-stone-100">
                    <div className="text-right">
                      <div className="font-display font-black text-sm sm:text-base text-stone-900">
                        {formatFCFA(order.total)}
                      </div>
                      <div className="text-[10px] text-stone-500 uppercase font-bold">
                        {order.paymentMethod === 'cash'
                          ? 'Espèces'
                          : order.paymentMethod === 'momo'
                          ? 'MTN MoMo'
                          : 'Orange Money'}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
                      className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
                    >
                      <span>{isExpanded ? 'Masquer' : 'Détails'}</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* Quick Status Action Strip */}
                <div className="px-3.5 py-2 bg-stone-100/70 border-t border-b border-stone-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-1 font-bold text-stone-700">
                    <span className="text-[11px] text-stone-500">Changer Statut :</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {order.status !== 'received' && (
                      <button
                        type="button"
                        onClick={() => handleStatusChange(order.id, 'received')}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 transition-colors cursor-pointer"
                      >
                        🟡 Reçue
                      </button>
                    )}

                    {order.status !== 'preparing' && (
                      <button
                        type="button"
                        onClick={() => handleStatusChange(order.id, 'preparing')}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-orange-50 hover:bg-orange-100 text-orange-900 border border-orange-200 transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <ChefHat className="w-3 h-3" /> En cuisine
                      </button>
                    )}

                    {order.status !== 'on_the_way' && (
                      <button
                        type="button"
                        onClick={() => handleStatusChange(order.id, 'on_the_way')}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <Bike className="w-3 h-3" /> En route
                      </button>
                    )}

                    {order.status !== 'delivered' && (
                      <button
                        type="button"
                        onClick={() => handleStatusChange(order.id, 'delivered')}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3 h-3" /> Livrée
                      </button>
                    )}

                    {order.status !== 'cancelled' && (
                      <button
                        type="button"
                        onClick={() => {
                          setCancellingOrderId(order.id);
                          setCancellationReason('');
                        }}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 transition-colors cursor-pointer"
                      >
                        🔴 Annuler
                      </button>
                    )}
                  </div>
                </div>

                {/* Expanded Details Body */}
                {isExpanded && (
                  <div className="p-4 space-y-4 text-xs bg-white">
                    {/* Customer & Delivery Coordinates */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3.5 rounded-xl bg-stone-50 border border-stone-200">
                      <div className="space-y-1.5">
                        <h5 className="font-bold text-stone-900 flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-rose-600" />
                          <span>Adresse & Livraison</span>
                        </h5>
                        <p className="text-stone-700 font-medium">
                          <strong>Quartier :</strong> {order.neighborhood}
                        </p>
                        <p className="text-stone-700">
                          <strong>Adresse :</strong> {order.manualAddress || 'Non spécifiée'}
                        </p>
                        {order.landmark && (
                          <p className="text-amber-800 bg-amber-50 p-1.5 rounded-lg border border-amber-200/80">
                            <strong>Repère :</strong> {order.landmark}
                          </p>
                        )}
                        {order.gpsLocation && (
                          <div className="pt-1">
                            <a
                              href={order.gpsLocation.googleMapsUrl || `https://maps.google.com/?q=${order.gpsLocation.latitude},${order.gpsLocation.longitude}`}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-600 hover:text-blue-800 bg-blue-50 px-2 py-1 rounded-lg border border-blue-200"
                            >
                              <ExternalLink className="w-3 h-3" />
                              <span>Voir Position GPS sur Google Maps</span>
                            </a>
                          </div>
                        )}
                      </div>

                      {/* Contact & Client Actions */}
                      <div className="space-y-2">
                        <h5 className="font-bold text-stone-900 flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Coordonnées Client</span>
                        </h5>
                        <p className="text-stone-700 font-medium">
                          <strong>Nom :</strong> {order.customerName}
                        </p>
                        <p className="text-stone-700 font-mono">
                          <strong>Tél :</strong> {order.customerPhone}
                        </p>

                        <div className="flex flex-wrap gap-2 pt-1">
                          <a
                            href={`tel:${order.customerPhone.replace(/\s+/g, '')}`}
                            className="px-2.5 py-1.5 rounded-lg bg-stone-900 text-white font-bold text-[11px] flex items-center gap-1 hover:bg-stone-800"
                          >
                            <Phone className="w-3 h-3 text-emerald-400" />
                            <span>Appeler</span>
                          </a>

                          <button
                            type="button"
                            onClick={() => handleNotifyCustomer(order)}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-[11px] flex items-center gap-1 hover:bg-emerald-700 cursor-pointer"
                          >
                            <MessageCircle className="w-3 h-3" />
                            <span>Notifier WhatsApp</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Order Items Detailed Breakdown */}
                    <div className="space-y-2">
                      <h5 className="font-bold text-stone-900 text-xs">
                        Contenu de la Commande ({order.items.length} mets)
                      </h5>
                      <div className="divide-y divide-stone-100 border border-stone-200 rounded-xl overflow-hidden">
                        {order.items.map((cartItem, idx) => (
                          <div key={idx} className="p-3 bg-stone-50/40 flex items-start justify-between gap-3">
                            <div className="space-y-1">
                              <div className="font-bold text-stone-900 text-xs flex items-center gap-2">
                                <span className="w-5 h-5 rounded-md bg-stone-900 text-white font-bold text-[10px] flex items-center justify-center">
                                  {cartItem.quantity}x
                                </span>
                                <span>{cartItem.item.name}</span>
                              </div>
                              <div className="text-[11px] text-stone-600 pl-7 space-y-0.5">
                                <div>Portion : <strong>{cartItem.selectedPortion.name}</strong></div>
                                {cartItem.selectedAccompaniment && (
                                  <div>Accompagnement : <strong>{cartItem.selectedAccompaniment}</strong></div>
                                )}
                                {cartItem.selectedExtraAccompaniments?.length > 0 && (
                                  <div>
                                    Garnitures extra : {cartItem.selectedExtraAccompaniments.map(e => e.name).join(', ')}
                                  </div>
                                )}
                                {cartItem.selectedSupplements?.length > 0 && (
                                  <div>
                                    Suppléments : {cartItem.selectedSupplements.map(s => s.name).join(', ')}
                                  </div>
                                )}
                                {cartItem.selectedPreparationOptions?.length > 0 && (
                                  <div className="text-amber-800 font-medium">
                                    Cuisson : {cartItem.selectedPreparationOptions.join(', ')}
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="font-bold text-stone-900 text-xs text-right shrink-0">
                              {formatFCFA(cartItem.totalPrice)}
                            </div>
                          </div>
                        ))}

                        {/* Calculation subtotal & delivery fee */}
                        <div className="p-3 bg-stone-100/60 space-y-1 text-[11px]">
                          <div className="flex justify-between text-stone-600">
                            <span>Sous-total plats :</span>
                            <span>{formatFCFA(order.subtotal)}</span>
                          </div>
                          <div className="flex justify-between text-stone-600">
                            <span>Frais de livraison :</span>
                            <span>{order.deliveryFee === 0 ? 'GRATUITE' : formatFCFA(order.deliveryFee)}</span>
                          </div>
                          <div className="flex justify-between font-extrabold text-stone-950 text-xs pt-1 border-t border-stone-200">
                            <span>Total à encaisser :</span>
                            <span className="text-amber-900">{formatFCFA(order.total)}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Admin Internal Note & Cancellation Reason */}
                    <div className="p-3 rounded-xl bg-amber-50/50 border border-amber-200/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-amber-950 text-xs flex items-center gap-1.5">
                          <Edit3 className="w-3.5 h-3.5 text-amber-700" />
                          <span>Note Administrative Interne</span>
                        </span>
                        {editingNoteOrderId !== order.id && (
                          <button
                            type="button"
                            onClick={() => {
                              setEditingNoteOrderId(order.id);
                              setTempNoteText(order.adminNote || '');
                            }}
                            className="text-[11px] font-bold text-amber-800 hover:underline cursor-pointer"
                          >
                            {order.adminNote ? 'Modifier la note' : '+ Ajouter une note'}
                          </button>
                        )}
                      </div>

                      {editingNoteOrderId === order.id ? (
                        <div className="space-y-2 pt-1">
                          <textarea
                            value={tempNoteText}
                            onChange={(e) => setTempNoteText(e.target.value)}
                            placeholder="Ex: Livreur appelé à 12h10, client absent demander de rappeler..."
                            rows={2}
                            className="w-full p-2 text-xs rounded-xl border border-amber-300 bg-white text-stone-900 focus:outline-none"
                          />
                          <div className="flex justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => setEditingNoteOrderId(null)}
                              className="px-2.5 py-1 text-[11px] rounded-lg text-stone-600 hover:bg-stone-200 cursor-pointer font-bold"
                            >
                              Annuler
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaveNote(order)}
                              className="px-3 py-1 text-[11px] rounded-lg bg-amber-600 text-white font-bold hover:bg-amber-700 flex items-center gap-1 cursor-pointer"
                            >
                              <Save className="w-3 h-3" />
                              <span>Enregistrer</span>
                            </button>
                          </div>
                        </div>
                      ) : (
                        <p className="text-xs text-stone-700 italic">
                          {order.adminNote || 'Aucune note administrative enregistrée.'}
                        </p>
                      )}

                      {order.cancellationReason && (
                        <div className="mt-2 p-2 rounded-lg bg-red-100/70 border border-red-200 text-red-900 text-xs">
                          <strong>Motif d'annulation :</strong> {order.cancellationReason}
                        </div>
                      )}
                    </div>

                    {/* Delete Order Action */}
                    {onDeleteOrder && (
                      <div className="pt-2 flex justify-end">
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Confirmez-vous la suppression définitive de la commande #${order.id} ?`)) {
                              onDeleteOrder(order.id);
                              showToast(`Commande #${order.id} supprimée.`);
                            }
                          }}
                          className="text-stone-400 hover:text-red-600 text-[11px] font-medium flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Supprimer cette commande</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Cancellation Reason Modal */}
      {cancellingOrderId && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 space-y-4 shadow-xl border border-stone-200">
            <div className="flex items-center justify-between">
              <h4 className="font-display font-extrabold text-stone-900 text-sm flex items-center gap-2">
                <XCircle className="w-4 h-4 text-red-600" />
                <span>Annuler la commande #{cancellingOrderId}</span>
              </h4>
              <button
                type="button"
                onClick={() => setCancellingOrderId(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-stone-600">
              Veuillez préciser le motif de l'annulation (ex: Rupture de stock, client injoignable, fausse commande) :
            </p>

            <input
              type="text"
              value={cancellationReason}
              onChange={(e) => setCancellationReason(e.target.value)}
              placeholder="Ex: Client injoignable après 3 tentatives"
              className="w-full p-2.5 text-xs rounded-xl border border-stone-300 bg-stone-50 font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500/30"
              autoFocus
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCancellingOrderId(null)}
                className="px-3 py-2 text-xs font-bold rounded-xl text-stone-600 hover:bg-stone-100 cursor-pointer"
              >
                Retour
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-4 py-2 text-xs font-bold rounded-xl bg-red-600 text-white hover:bg-red-700 flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <XCircle className="w-3.5 h-3.5" />
                <span>Confirmer l'annulation</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
