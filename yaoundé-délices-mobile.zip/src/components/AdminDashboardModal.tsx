import React, { useState, useMemo } from 'react';
import {
  X,
  Plus,
  Edit2,
  Trash2,
  Upload,
  Save,
  RotateCcw,
  Settings,
  Utensils,
  Check,
  Eye,
  EyeOff,
  FolderTree,
  AlertCircle,
  Clock,
  Sparkles,
  Lock,
  Unlock,
  KeyRound,
  ShoppingBag,
  Phone,
  Send,
  MapPin,
  Search,
  Filter,
  DollarSign,
  TrendingUp,
  Package,
  Layers,
  HelpCircle,
  Flame,
  CheckCircle2,
  Calendar,
  CreditCard,
  ChefHat,
  Bike,
  PackageCheck,
  ShieldCheck,
  ChevronRight,
  ExternalLink,
  BarChart3,
  Image as ImageIcon,
  RefreshCw,
  Zap,
  Bell
} from 'lucide-react';
import {
  getAutoUpdateMode,
  setAutoUpdateMode,
  getAutoUpdateInterval,
  setAutoUpdateInterval,
  checkForUpdate,
  simulateNewVersion
} from '../utils/versionChecker';
import {
  MenuItem,
  RestaurantConfig,
  CategoryDef,
  PortionOption,
  ExtraAccompanimentOption,
  SupplementOption,
  Order,
  OrderStatus,
} from '../types';
import { formatFCFA } from '../utils/formatters';
import { openWhatsAppOrder } from '../utils/whatsapp';
import { AdminStatsTab } from './AdminStatsTab';
import { AdminOrdersTab } from './AdminOrdersTab';

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  menu: MenuItem[];
  categories: CategoryDef[];
  config: RestaurantConfig;
  orders: Order[];
  onSaveMenu: (newMenu: MenuItem[]) => void;
  onSaveCategories: (newCategories: CategoryDef[]) => void;
  onSaveConfig: (newConfig: RestaurantConfig) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, note?: string, cancellationReason?: string) => void;
  onDeleteOrder?: (orderId: string) => void;
  onAddOrder?: (newOrder: Order) => void;
  onResetMenu: () => MenuItem[];
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  isOpen,
  onClose,
  menu,
  categories,
  config,
  orders,
  onSaveMenu,
  onSaveCategories,
  onSaveConfig,
  onUpdateOrderStatus,
  onDeleteOrder,
  onAddOrder,
  onResetMenu,
}) => {
  if (!isOpen) return null;

  // 1-Hour Session Management (60 minutes = 3600000 ms)
  const SESSION_DURATION_MS = 60 * 60 * 1000;

  const isSessionValid = (): boolean => {
    try {
      const isAuth = localStorage.getItem('yaounde_admin_auth') === 'true' || sessionStorage.getItem('yaounde_admin_auth') === 'true';
      const timestampStr = localStorage.getItem('yaounde_admin_auth_timestamp') || sessionStorage.getItem('yaounde_admin_auth_timestamp');
      if (!isAuth || !timestampStr) return false;
      const timestamp = parseInt(timestampStr, 10);
      const now = Date.now();
      if (isNaN(timestamp) || (now - timestamp) > SESSION_DURATION_MS) {
        localStorage.removeItem('yaounde_admin_auth');
        localStorage.removeItem('yaounde_admin_auth_timestamp');
        sessionStorage.removeItem('yaounde_admin_auth');
        sessionStorage.removeItem('yaounde_admin_auth_timestamp');
        return false;
      }
      return true;
    } catch {
      return false;
    }
  };

  const touchSession = () => {
    try {
      const nowStr = String(Date.now());
      localStorage.setItem('yaounde_admin_auth', 'true');
      localStorage.setItem('yaounde_admin_auth_timestamp', nowStr);
      sessionStorage.setItem('yaounde_admin_auth', 'true');
      sessionStorage.setItem('yaounde_admin_auth_timestamp', nowStr);
    } catch {}
  };

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => isSessionValid());
  const [enteredPassword, setEnteredPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Inactivity Session Check
  React.useEffect(() => {
    if (!isAuthenticated) return;
    touchSession();
    const interval = setInterval(() => {
      if (!isSessionValid()) {
        setIsAuthenticated(false);
        setAuthError("Votre session a expiré après 1 heure d'inactivité. Veuillez vous reconnecter.");
      }
    }, 20000);
    return () => clearInterval(interval);
  }, [isAuthenticated]);

  // Tabs: stats | orders | dishes | categories | settings | security
  const [activeTab, setActiveTab] = useState<'stats' | 'orders' | 'dishes' | 'categories' | 'settings' | 'security'>('stats');
  const [ordersInitialStatusFilter, setOrdersInitialStatusFilter] = useState<string>('all');

  // State copies
  const [items, setItems] = useState<MenuItem[]>([...menu]);
  const [categoryList, setCategoryList] = useState<CategoryDef[]>([...categories]);
  const [restaurantSettings, setRestaurantSettings] = useState<RestaurantConfig>({ ...config });
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // Dish Management States
  const [dishSearchQuery, setDishSearchQuery] = useState('');
  const [dishCategoryFilter, setDishCategoryFilter] = useState('Tous');
  const [editingDish, setEditingDish] = useState<MenuItem | null>(null);
  const [isDishFormOpen, setIsDishFormOpen] = useState(false);

  // Dish Form Fields
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('Légumes & Feuilles');
  const [formSubcategory, setFormSubcategory] = useState('Légumes traditionnels');
  const [formDescription, setFormDescription] = useState('');
  const [formImage, setFormImage] = useState('');
  const [formBadge, setFormBadge] = useState('');
  const [formPopular, setFormPopular] = useState(false);
  const [formPrepTime, setFormPrepTime] = useState('25-35 min');
  const [formAvailability, setFormAvailability] = useState<'disponible' | 'indisponible' | 'epuise'>('disponible');
  const [formPortions, setFormPortions] = useState<PortionOption[]>([
    { id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 pers.' }
  ]);
  const [formIncludedAcc, setFormIncludedAcc] = useState<string[]>(['Plantain vapeur', 'Bâton de manioc']);
  const [formNewIncludedInput, setFormNewIncludedInput] = useState('');
  const [formExtraAcc, setFormExtraAcc] = useState<ExtraAccompanimentOption[]>([
    { id: 'extra-1', name: 'Portion Plantains frits', price: 500 },
    { id: 'extra-2', name: 'Bâton de manioc additionnel', price: 300 }
  ]);
  const [formSupplements, setFormSupplements] = useState<SupplementOption[]>([
    { id: 'sup-1', name: 'Poulet fermier', price: 1500 },
    { id: 'sup-2', name: 'Poisson braisé', price: 2000 },
    { id: 'sup-3', name: 'Viande de bœuf', price: 1500 },
    { id: 'sup-4', name: 'Œuf dur', price: 500 }
  ]);
  const [formPrepOptions, setFormPrepOptions] = useState<string[]>(['Sans sel ajouté', 'Piment à part', 'Bien épicé']);
  const [formNewPrepInput, setFormNewPrepInput] = useState('');

  // Category Edit / Add State
  const [editingCategory, setEditingCategory] = useState<CategoryDef | null>(null);
  const [newCatName, setNewCatName] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('🍲');
  const [newCatSubcategories, setNewCatSubcategories] = useState('');
  const [isCatFormOpen, setIsCatFormOpen] = useState(false);

  // Delivery Zones manager
  const [newZoneInput, setNewZoneInput] = useState('');

  // Orders Filter State
  const [orderDateFilter, setOrderDateFilter] = useState<'all' | 'today' | 'week'>('all');
  const [orderStatusFilter, setOrderStatusFilter] = useState<'all' | 'received' | 'preparing' | 'on_the_way' | 'delivered'>('all');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');

  // Password Change States
  const [currentPwInput, setCurrentPwInput] = useState('');
  const [newPwInput, setNewPwInput] = useState('');
  const [confirmPwInput, setConfirmPwInput] = useState('');
  const [pwChangeError, setPwChangeError] = useState<string | null>(null);

  // Handle Login
  const handleLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const targetPw = config.adminPassword || 'yaounde2026';
    if (enteredPassword.trim() === targetPw) {
      setIsAuthenticated(true);
      touchSession();
      setAuthError(null);
    } else {
      setAuthError('Mot de passe incorrect');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('yaounde_admin_auth');
    localStorage.removeItem('yaounde_admin_auth_timestamp');
    sessionStorage.removeItem('yaounde_admin_auth');
    sessionStorage.removeItem('yaounde_admin_auth_timestamp');
    setEnteredPassword('');
  };

  const showToast = (msg: string) => {
    setSuccessNotice(msg);
    setTimeout(() => setSuccessNotice(null), 3500);
  };

  // Open Dish Form
  const openDishForm = (dish?: MenuItem) => {
    if (dish) {
      setEditingDish(dish);
      setFormName(dish.name);
      setFormCategory(dish.category);
      setFormSubcategory(dish.subcategory || '');
      setFormDescription(dish.description);
      setFormImage(dish.image);
      setFormBadge(dish.badge || '');
      setFormPopular(dish.popular || false);
      setFormPrepTime(dish.preparationTime || '25-35 min');
      setFormAvailability(dish.availability || 'disponible');
      setFormPortions(
        dish.portions && dish.portions.length > 0
          ? JSON.parse(JSON.stringify(dish.portions))
          : [{ id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 pers.' }]
      );
      setFormIncludedAcc(dish.includedAccompaniments || ['Plantain vapeur', 'Bâton de manioc', 'Riz']);
      setFormExtraAcc(dish.extraAccompaniments || []);
      setFormSupplements(dish.supplements || []);
      setFormPrepOptions(dish.preparationOptions || ['Sans sel ajouté', 'Piment à part']);
    } else {
      setEditingDish(null);
      setFormName('');
      const defaultCat = categoryList[0]?.name || 'Légumes & Feuilles';
      setFormCategory(defaultCat);
      const matched = categoryList.find(c => c.name === defaultCat);
      setFormSubcategory(matched?.subcategories[0] || 'Légumes traditionnels');
      setFormDescription('');
      setFormImage('https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80');
      setFormBadge('');
      setFormPopular(false);
      setFormPrepTime('25-35 min');
      setFormAvailability('disponible');
      setFormPortions([
        { id: 'petite', name: 'Petite', price: 2500, servesInfo: '1 pers.' },
        { id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 pers.' },
        { id: 'grande', name: 'Grande', price: 5000, servesInfo: '2-3 pers.' },
        { id: 'familiale', name: 'Familiale', price: 8500, servesInfo: '4-6 pers.' }
      ]);
      setFormIncludedAcc(['Plantain vapeur', 'Bâton de manioc', 'Riz']);
      setFormExtraAcc([
        { id: `extra-${Date.now()}-1`, name: 'Portion Plantains frits', price: 500 },
        { id: `extra-${Date.now()}-2`, name: 'Bâton de manioc additionnel', price: 300 }
      ]);
      setFormSupplements([
        { id: `sup-${Date.now()}-1`, name: 'Poulet fermier', price: 1500 },
        { id: `sup-${Date.now()}-2`, name: 'Poisson braisé', price: 2000 },
        { id: `sup-${Date.now()}-3`, name: 'Viande de bœuf', price: 1500 },
        { id: `sup-${Date.now()}-4`, name: 'Œuf dur', price: 500 }
      ]);
      setFormPrepOptions(['Sans sel ajouté', 'Piment à part', 'Bien épicé']);
    }
    setIsDishFormOpen(true);
  };

  // Image Upload helper
  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("La photo est un peu lourde (> 5 Mo). Privilégiez une image compressée.");
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setFormImage(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Save Dish
  const handleSaveDish = () => {
    if (!formName.trim()) {
      alert('Veuillez renseigner le nom du met.');
      return;
    }
    if (formPortions.length === 0) {
      alert('Définissez au moins une taille/portion avec son prix.');
      return;
    }

    const dishToSave: MenuItem = {
      id: editingDish ? editingDish.id : `met-${Date.now()}`,
      name: formName.trim(),
      category: formCategory,
      subcategory: formSubcategory.trim() || 'Spécialité',
      description: formDescription.trim(),
      image: formImage.trim() || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
      badge: formBadge.trim() || undefined,
      popular: formPopular,
      preparationTime: formPrepTime.trim() || undefined,
      availability: formAvailability,
      portions: formPortions,
      includedAccompaniments: formIncludedAcc.length > 0 ? formIncludedAcc : undefined,
      extraAccompaniments: formExtraAcc.length > 0 ? formExtraAcc : undefined,
      supplements: formSupplements.length > 0 ? formSupplements : undefined,
      preparationOptions: formPrepOptions.length > 0 ? formPrepOptions : undefined,
    };

    let updatedList: MenuItem[];
    if (editingDish) {
      updatedList = items.map(d => (d.id === editingDish.id ? dishToSave : d));
    } else {
      updatedList = [dishToSave, ...items];
    }

    setItems(updatedList);
    onSaveMenu(updatedList);
    setIsDishFormOpen(false);
    setEditingDish(null);
    showToast(editingDish ? `Met "${dishToSave.name}" mis à jour !` : `Nouveau met "${dishToSave.name}" ajouté avec succès !`);
  };

  // Delete Dish
  const handleDeleteDish = (id: string, name: string) => {
    if (confirm(`Confirmez-vous la suppression du met "${name}" ? Cette action est irréversible.`)) {
      const updated = items.filter(d => d.id !== id);
      setItems(updated);
      onSaveMenu(updated);
      showToast(`Le met "${name}" a été supprimé.`);
    }
  };

  // Toggle Dish Availability
  const handleToggleDishStock = (dish: MenuItem) => {
    const nextStatus: MenuItem['availability'] =
      dish.availability === 'disponible' ? 'epuise' : dish.availability === 'epuise' ? 'indisponible' : 'disponible';

    const updated = items.map(d => (d.id === dish.id ? { ...d, availability: nextStatus } : d));
    setItems(updated);
    onSaveMenu(updated);
    showToast(`Statut de "${dish.name}" modifié : ${nextStatus.toUpperCase()}`);
  };

  // Categories Handlers
  const handleOpenCatForm = (cat?: CategoryDef) => {
    if (cat) {
      setEditingCategory(cat);
      setNewCatName(cat.name);
      setNewCatIcon(cat.icon);
      setNewCatSubcategories(cat.subcategories.join(', '));
    } else {
      setEditingCategory(null);
      setNewCatName('');
      setNewCatIcon('🍲');
      setNewCatSubcategories('Spécialités, Nouveautés');
    }
    setIsCatFormOpen(true);
  };

  const handleSaveCategory = () => {
    if (!newCatName.trim()) {
      alert('Veuillez saisir un nom de catégorie.');
      return;
    }

    const parsedSubs = newCatSubcategories
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    const catToSave: CategoryDef = {
      id: editingCategory ? editingCategory.id : `cat-${Date.now()}`,
      name: newCatName.trim(),
      icon: newCatIcon.trim() || '🍲',
      subcategories: parsedSubs.length > 0 ? parsedSubs : ['Général'],
    };

    let updatedCats: CategoryDef[];
    if (editingCategory) {
      updatedCats = categoryList.map(c => (c.id === editingCategory.id ? catToSave : c));
    } else {
      updatedCats = [...categoryList, catToSave];
    }

    setCategoryList(updatedCats);
    onSaveCategories(updatedCats);
    setIsCatFormOpen(false);
    setEditingCategory(null);
    showToast(`Catégorie "${catToSave.name}" enregistrée !`);
  };

  const handleDeleteCategory = (catId: string, catName: string) => {
    const linkedDishesCount = items.filter(d => d.category === catName).length;
    if (linkedDishesCount > 0) {
      if (!confirm(`Attention : ${linkedDishesCount} plat(s) utilisent la catégorie "${catName}". Si vous la supprimez, ils devront être réassignés. Continuer ?`)) {
        return;
      }
    } else {
      if (!confirm(`Supprimer la catégorie "${catName}" ?`)) return;
    }

    const updatedCats = categoryList.filter(c => c.id !== catId);
    setCategoryList(updatedCats);
    onSaveCategories(updatedCats);
    showToast(`Catégorie "${catName}" supprimée.`);
  };

  // Delivery Zones Handlers
  const handleAddZone = () => {
    const clean = newZoneInput.trim();
    if (!clean) return;
    if (restaurantSettings.deliveryZones.includes(clean)) {
      alert('Ce quartier est déjà dans la liste.');
      return;
    }
    const updatedZones = [...restaurantSettings.deliveryZones, clean];
    const newConfig = { ...restaurantSettings, deliveryZones: updatedZones };
    setRestaurantSettings(newConfig);
    onSaveConfig(newConfig);
    setNewZoneInput('');
    showToast(`Quartier "${clean}" ajouté à la zone de livraison !`);
  };

  const handleRemoveZone = (zoneName: string) => {
    const updatedZones = restaurantSettings.deliveryZones.filter(z => z !== zoneName);
    const newConfig = { ...restaurantSettings, deliveryZones: updatedZones };
    setRestaurantSettings(newConfig);
    onSaveConfig(newConfig);
    showToast(`Quartier "${zoneName}" retiré.`);
  };

  // Save Settings
  const handleSaveSettings = () => {
    onSaveConfig(restaurantSettings);
    showToast('Coordonnées, numéros MoMo/OM et tarifs enregistrés !');
  };

  // Change Password
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    const currentAdminPw = restaurantSettings.adminPassword || 'yaounde2026';
    if (currentPwInput.trim() !== currentAdminPw) {
      setPwChangeError('Le mot de passe actuel saisi est incorrect.');
      return;
    }
    if (newPwInput.trim().length < 4) {
      setPwChangeError('Le nouveau mot de passe doit comporter au moins 4 caractères.');
      return;
    }
    if (newPwInput.trim() !== confirmPwInput.trim()) {
      setPwChangeError('Les deux nouveaux mots de passe ne correspondent pas.');
      return;
    }

    const newConfig: RestaurantConfig = {
      ...restaurantSettings,
      adminPassword: newPwInput.trim(),
    };
    setRestaurantSettings(newConfig);
    onSaveConfig(newConfig);
    setCurrentPwInput('');
    setNewPwInput('');
    setConfirmPwInput('');
    setPwChangeError(null);
    showToast('Mot de passe administrateur modifié avec succès !');
  };

  // Filtered Dishes list
  const filteredDishes = useMemo(() => {
    return items.filter(dish => {
      const matchCat = dishCategoryFilter === 'Tous' || dish.category === dishCategoryFilter;
      const matchSearch =
        dishSearchQuery === '' ||
        dish.name.toLowerCase().includes(dishSearchQuery.toLowerCase()) ||
        dish.description.toLowerCase().includes(dishSearchQuery.toLowerCase()) ||
        (dish.subcategory && dish.subcategory.toLowerCase().includes(dishSearchQuery.toLowerCase()));
      return matchCat && matchSearch;
    });
  }, [items, dishCategoryFilter, dishSearchQuery]);

  // Orders filtering & stats
  const filteredOrders = useMemo(() => {
    const now = new Date();
    return orders.filter(order => {
      // Date filter
      if (orderDateFilter === 'today') {
        const orderDate = new Date(order.createdAt);
        const isToday =
          orderDate.getDate() === now.getDate() &&
          orderDate.getMonth() === now.getMonth() &&
          orderDate.getFullYear() === now.getFullYear();
        if (!isToday) return false;
      } else if (orderDateFilter === 'week') {
        const orderDate = new Date(order.createdAt);
        const diffDays = (now.getTime() - orderDate.getTime()) / (1000 * 3600 * 24);
        if (diffDays > 7) return false;
      }

      // Status filter
      if (orderStatusFilter !== 'all' && order.status !== orderStatusFilter) {
        return false;
      }

      // Search
      if (orderSearchQuery) {
        const q = orderSearchQuery.toLowerCase();
        const matchName = order.customerName.toLowerCase().includes(q);
        const matchPhone = order.customerPhone.includes(q);
        const matchNeighborhood = order.neighborhood.toLowerCase().includes(q);
        const matchId = order.id.toLowerCase().includes(q);
        if (!matchName && !matchPhone && !matchNeighborhood && !matchId) return false;
      }

      return true;
    });
  }, [orders, orderDateFilter, orderStatusFilter, orderSearchQuery]);

  // Orders KPI stats
  const orderStats = useMemo(() => {
    const today = new Date();
    const todayOrders = orders.filter(o => {
      const d = new Date(o.createdAt);
      return (
        d.getDate() === today.getDate() &&
        d.getMonth() === today.getMonth() &&
        d.getFullYear() === today.getFullYear()
      );
    });

    const totalRevenueToday = todayOrders.reduce((sum, o) => sum + o.total, 0);
    const pendingOrdersCount = orders.filter(o => o.status === 'received' || o.status === 'preparing').length;
    const deliveredCount = orders.filter(o => o.status === 'delivered').length;

    return {
      totalRevenueToday,
      todayOrdersCount: todayOrders.length,
      pendingOrdersCount,
      deliveredCount,
      allOrdersCount: orders.length,
    };
  }, [orders]);

  // If not authenticated, render Login Screen
  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
        <div
          id="admin-login-modal"
          className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-stone-200 text-center space-y-6 relative"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-700 rounded-xl hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header Icon */}
          <div className="w-16 h-16 rounded-3xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto shadow-inner border border-rose-100">
            <Lock className="w-8 h-8" />
          </div>

          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-rose-600 bg-rose-50 px-3 py-1 rounded-full">
              Espace Administrateur Sécurisé
            </span>
            <h2 className="font-display font-extrabold text-2xl text-stone-900 mt-2">
              Yaoundé Délices Gérance
            </h2>
            <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
              Veuillez saisir votre mot de passe gérant pour accéder à la gestion du menu, des prix et des commandes.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4 text-left">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                Mot de passe d'accès *
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={enteredPassword}
                  onChange={(e) => setEnteredPassword(e.target.value)}
                  placeholder="Saisissez le mot de passe..."
                  autoFocus
                  className="w-full p-3 pl-10 pr-10 rounded-xl border border-stone-300 focus:border-rose-500 focus:ring-2 focus:ring-rose-200 outline-none text-sm font-medium bg-stone-50/50"
                />
                <KeyRound className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-stone-400 hover:text-stone-600 absolute right-3 top-3 p-0.5 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {authError && (
              <div className="bg-red-50 text-red-700 text-xs font-medium p-2.5 rounded-xl border border-red-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            <div className="bg-amber-50 p-2.5 rounded-xl border border-amber-200/80 text-[11px] text-amber-900 flex items-center justify-between">
              <span>💡 Mot de passe initial : <strong className="font-mono font-bold">yaounde2026</strong></span>
              <button
                type="button"
                onClick={() => setEnteredPassword(config.adminPassword || 'yaounde2026')}
                className="text-rose-600 hover:underline font-bold text-[10px]"
              >
                Remplir
              </button>
            </div>

            <div className="pt-2 flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 px-4 rounded-xl text-xs font-bold text-stone-600 bg-stone-100 hover:bg-stone-200 transition-colors"
              >
                Annuler
              </button>
              <button
                type="submit"
                id="btn-admin-unlock"
                className="flex-2 py-3 px-4 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-md shadow-rose-600/20 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Unlock className="w-4 h-4" />
                <span>Déverrouiller l'Espace</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-fade-in">
      <div
        id="admin-full-dashboard-modal"
        className="bg-stone-50 rounded-3xl max-w-5xl w-full max-h-[94vh] overflow-hidden shadow-2xl border border-stone-200 flex flex-col"
      >
        {/* Top Header with Brand & Tabs */}
        <div className="bg-white border-b border-stone-200 p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-rose-600 to-amber-500 flex items-center justify-center text-white shadow-md shadow-rose-600/20">
              <Utensils className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display font-extrabold text-lg sm:text-xl text-stone-900">
                  Espace Gérant & Administration
                </h2>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Connecté
                </span>
              </div>
              <p className="text-xs text-stone-500">
                Gestion complète du catalogue, prix, photos, catégories et commandes de Yaoundé Délices
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleLogout}
              className="text-xs font-bold text-stone-600 hover:text-rose-600 bg-stone-100 hover:bg-rose-50 px-3 py-1.5 rounded-xl border border-stone-200 transition-colors flex items-center gap-1.5"
              title="Verrouiller la session"
            >
              <Lock className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Verrouiller</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-stone-400 hover:text-stone-700 rounded-xl hover:bg-stone-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Toast Success Message */}
        {successNotice && (
          <div className="bg-emerald-600 text-white text-xs font-bold px-4 py-2 flex items-center justify-between gap-2 shadow-xs shrink-0 animate-fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>{successNotice}</span>
            </div>
            <button onClick={() => setSuccessNotice(null)} className="text-emerald-200 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Navigation Tabs Bar */}
        <div className="bg-white border-b border-stone-200 px-3 sm:px-6 flex overflow-x-auto gap-1 sm:gap-2 shrink-0 scrollbar-none py-1">
          <button
            onClick={() => {
              setActiveTab('stats');
              setIsDishFormOpen(false);
            }}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'stats'
                ? 'bg-amber-500 text-stone-950 font-black shadow-2xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-stone-800" />
            <span>Statistiques</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('orders');
              setIsDishFormOpen(false);
            }}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'orders'
                ? 'bg-rose-50 text-rose-600 border border-rose-200 font-black'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Commandes ({orders.length})</span>
            {orderStats.pendingOrdersCount > 0 && (
              <span className="bg-rose-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-black">
                {orderStats.pendingOrdersCount}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              setActiveTab('dishes');
              setIsDishFormOpen(false);
            }}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'dishes'
                ? 'bg-rose-50 text-rose-600 border border-rose-200 font-black'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <Utensils className="w-4 h-4" />
            <span>Mets & Prix ({items.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('categories');
              setIsCatFormOpen(false);
            }}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'categories'
                ? 'bg-rose-50 text-rose-600 border border-rose-200 font-black'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <FolderTree className="w-4 h-4" />
            <span>Catégories ({categoryList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-rose-50 text-rose-600 border border-rose-200 font-black'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>MoMo, OM & Livraison</span>
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'security'
                ? 'bg-rose-50 text-rose-600 border border-rose-200 font-black'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>Mot de passe</span>
          </button>
        </div>

        {/* Body Content Area */}
        <div className="p-3 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* ========================================================================= */}
          {/* TAB 0: STATISTIQUES & TABLEAU DE BORD */}
          {/* ========================================================================= */}
          {activeTab === 'stats' && (
            <AdminStatsTab
              orders={orders}
              onNavigateToOrders={(filter) => {
                setOrdersInitialStatusFilter(filter || 'all');
                setActiveTab('orders');
              }}
              showToast={showToast}
            />
          )}

          {/* ========================================================================= */}
          {/* TAB 1: COMMANDES EN TEMPS RÉEL */}
          {/* ========================================================================= */}
          {activeTab === 'orders' && (
            <AdminOrdersTab
              orders={orders}
              config={restaurantSettings}
              initialStatusFilter={ordersInitialStatusFilter}
              onUpdateOrderStatus={onUpdateOrderStatus}
              onDeleteOrder={onDeleteOrder}
              onAddOrder={onAddOrder}
              showToast={showToast}
            />
          )}

          {/* ========================================================================= */}
          {/* TAB 2: GESTION DU MENU, DES METS & DES PRIX */}
          {/* ========================================================================= */}
          {activeTab === 'dishes' && (
            <div className="space-y-4 text-xs">
              {isDishFormOpen ? (
                /* FORMULAIRE COMPLET AJOUT / MODIF MET */
                <div className="bg-white rounded-2xl p-4 sm:p-6 border border-stone-200 shadow-2xs space-y-5">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                    <div>
                      <h3 className="font-display font-extrabold text-stone-900 text-base">
                        {editingDish ? `Modifier le met "${editingDish.name}"` : 'Créer un nouveau met camerounais'}
                      </h3>
                      <p className="text-stone-500 text-[11px]">
                        Renseignez les détails, portions, prix en FCFA, photos et accompagnements.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsDishFormOpen(false)}
                      className="text-stone-400 hover:text-stone-800 p-1 rounded-lg"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* General dish info */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Nom du met *</label>
                      <input
                        type="text"
                        value={formName}
                        onChange={(e) => setFormName(e.target.value)}
                        placeholder="Ex: SANGA Traditionnel, Ndolè Royal..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 font-bold text-stone-900"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Catégorie Principale *</label>
                      <select
                        value={formCategory}
                        onChange={(e) => {
                          setFormCategory(e.target.value);
                          const matched = categoryList.find(c => c.name === e.target.value);
                          if (matched && matched.subcategories.length > 0) {
                            setFormSubcategory(matched.subcategories[0]);
                          }
                        }}
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 font-medium"
                      >
                        {categoryList.map(cat => (
                          <option key={cat.id} value={cat.name}>
                            {cat.icon} {cat.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Sous-catégorie *</label>
                      <input
                        type="text"
                        value={formSubcategory}
                        onChange={(e) => setFormSubcategory(e.target.value)}
                        placeholder="Ex: Légumes traditionnels, Feuilles sautées..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 font-medium"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Disponibilité immédiate *</label>
                      <select
                        value={formAvailability}
                        onChange={(e) => setFormAvailability(e.target.value as any)}
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 font-bold"
                      >
                        <option value="disponible">🟢 Disponible à la commande</option>
                        <option value="epuise">🟡 Épuisé (Rupture aujourd'hui)</option>
                        <option value="indisponible">🔴 Indisponible au menu</option>
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 mb-1">Description détaillée du met *</label>
                      <textarea
                        rows={2}
                        value={formDescription}
                        onChange={(e) => setFormDescription(e.target.value)}
                        placeholder="Décrivez les saveurs, les épices traditionnelles, le mode de préparation..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                      />
                    </div>

                    {/* Photo Management */}
                    <div className="sm:col-span-2 bg-stone-50 p-3.5 rounded-2xl border border-stone-200 space-y-2">
                      <label className="block font-bold text-stone-800">Photo du met (Galerie ou Lien Web) *</label>
                      <div className="flex items-center gap-3">
                        {formImage && (
                          <div className="relative group shrink-0">
                            <img
                              src={formImage}
                              alt="Aperçu"
                              className="w-20 h-20 rounded-2xl object-cover border border-stone-300 shadow-2xs"
                            />
                            <button
                              type="button"
                              onClick={() => setFormImage('')}
                              className="absolute -top-1.5 -right-1.5 bg-red-600 text-white rounded-full p-0.5 shadow-md hover:bg-red-700"
                              title="Supprimer la photo"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}

                        <div className="flex-1 space-y-2">
                          <label className="inline-flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white px-3.5 py-2 rounded-xl font-bold cursor-pointer transition-colors shadow-2xs text-xs">
                            <Upload className="w-4 h-4" />
                            <span>Charger une photo depuis ma galerie / téléphone</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleImageFileUpload}
                              className="hidden"
                            />
                          </label>

                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              value={formImage}
                              onChange={(e) => setFormImage(e.target.value)}
                              placeholder="Ou collez une URL d'image (https://...)"
                              className="w-full p-2 rounded-xl border border-stone-300 bg-white text-[11px]"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Portions & Prices */}
                    <div className="sm:col-span-2 bg-rose-50/50 p-4 rounded-2xl border border-rose-200/80 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <label className="font-black text-rose-950 uppercase tracking-wide">
                            Tailles & Portions (Petite, Standard, Grande, Familiale) *
                          </label>
                          <p className="text-rose-800 text-[10px]">
                            Ajustez le prix en FCFA pour chaque taille proposée au client
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setFormPortions(prev => [
                              ...prev,
                              { id: `portion-${Date.now()}`, name: 'Nouvelle portion', price: 4000, servesInfo: '1-2 pers.' }
                            ]);
                          }}
                          className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 shadow-2xs"
                        >
                          <Plus className="w-3.5 h-3.5" /> Ajouter une portion
                        </button>
                      </div>

                      <div className="space-y-2">
                        {formPortions.map((portion, idx) => (
                          <div key={portion.id || idx} className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-rose-100 shadow-2xs">
                            <input
                              type="text"
                              value={portion.name}
                              onChange={(e) => {
                                const copy = [...formPortions];
                                copy[idx].name = e.target.value;
                                setFormPortions(copy);
                              }}
                              placeholder="Nom (Petite, Standard, Grande...)"
                              className="flex-1 p-2 rounded-lg border border-stone-300 bg-white font-bold text-xs"
                            />
                            <input
                              type="text"
                              value={portion.servesInfo || ''}
                              onChange={(e) => {
                                const copy = [...formPortions];
                                copy[idx].servesInfo = e.target.value;
                                setFormPortions(copy);
                              }}
                              placeholder="Convient pour (ex: 1-2 pers.)"
                              className="w-32 p-2 rounded-lg border border-stone-300 bg-white text-xs"
                            />
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                value={portion.price}
                                onChange={(e) => {
                                  const copy = [...formPortions];
                                  copy[idx].price = Number(e.target.value);
                                  setFormPortions(copy);
                                }}
                                step="100"
                                className="w-24 p-2 rounded-lg border border-stone-300 bg-white font-black text-rose-600 text-xs"
                              />
                              <span className="text-[10px] text-stone-400 font-bold">FCFA</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                if (formPortions.length <= 1) {
                                  alert('Un met doit avoir au moins une portion !');
                                  return;
                                }
                                setFormPortions(prev => prev.filter((_, i) => i !== idx));
                              }}
                              className="p-1 text-stone-400 hover:text-red-600 rounded-lg cursor-pointer"
                              title="Supprimer cette portion"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Accompagnements Inclus */}
                    <div className="sm:col-span-2 bg-stone-50 p-3.5 rounded-2xl border border-stone-200 space-y-2">
                      <label className="block font-bold text-stone-800">
                        Accompagnements inclus au choix (Le client en choisit un sans supplément)
                      </label>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {formIncludedAcc.map((acc, idx) => (
                          <span
                            key={idx}
                            className="bg-white border border-stone-300 px-2.5 py-1 rounded-xl text-stone-800 font-medium flex items-center gap-1.5 shadow-2xs"
                          >
                            <span>{acc}</span>
                            <button
                              type="button"
                              onClick={() => setFormIncludedAcc(prev => prev.filter((_, i) => i !== idx))}
                              className="text-stone-400 hover:text-red-500"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </span>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={formNewIncludedInput}
                          onChange={(e) => setFormNewIncludedInput(e.target.value)}
                          placeholder="Ajouter un accompagnement (ex: Bâton de manioc, Plantain vapeur, Riz)..."
                          className="flex-1 p-2 rounded-xl border border-stone-300 bg-white text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (formNewIncludedInput.trim()) {
                              setFormIncludedAcc(prev => [...prev, formNewIncludedInput.trim()]);
                              setFormNewIncludedInput('');
                            }
                          }}
                          className="bg-stone-800 text-white font-bold px-3 py-2 rounded-xl text-xs"
                        >
                          + Ajouter
                        </button>
                      </div>
                    </div>

                    {/* Suppléments Payants */}
                    <div className="sm:col-span-2 bg-stone-50 p-3.5 rounded-2xl border border-stone-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="font-bold text-stone-800">
                          Suppléments & Garnitures payantes (Viande, Poisson, Poulet, Œuf...)
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            setFormSupplements(prev => [
                              ...prev,
                              { id: `sup-${Date.now()}`, name: 'Nouveau supplément', price: 1000 }
                            ]);
                          }}
                          className="text-rose-600 font-bold text-xs flex items-center gap-1 hover:underline"
                        >
                          <Plus className="w-3.5 h-3.5" /> Ajouter
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {formSupplements.map((sup, idx) => (
                          <div key={sup.id || idx} className="flex items-center gap-2 bg-white p-2 rounded-xl border border-stone-200">
                            <input
                              type="text"
                              value={sup.name}
                              onChange={(e) => {
                                const copy = [...formSupplements];
                                copy[idx].name = e.target.value;
                                setFormSupplements(copy);
                              }}
                              placeholder="Nom supplément"
                              className="flex-1 p-1.5 rounded-lg border border-stone-300 text-xs font-medium"
                            />
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                value={sup.price}
                                onChange={(e) => {
                                  const copy = [...formSupplements];
                                  copy[idx].price = Number(e.target.value);
                                  setFormSupplements(copy);
                                }}
                                step="100"
                                className="w-20 p-1.5 rounded-lg border border-stone-300 text-xs font-bold text-rose-600"
                              />
                              <span className="text-[10px] text-stone-400">FCFA</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => setFormSupplements(prev => prev.filter((_, i) => i !== idx))}
                              className="text-stone-400 hover:text-red-500 p-1"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Badges & Options */}
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Badge d'accroche (optionnel)</label>
                      <input
                        type="text"
                        value={formBadge}
                        onChange={(e) => setFormBadge(e.target.value)}
                        placeholder="Ex: Recette Royale, Coup de cœur, Le + Commandé"
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Temps de préparation estimé</label>
                      <input
                        type="text"
                        value={formPrepTime}
                        onChange={(e) => setFormPrepTime(e.target.value)}
                        placeholder="Ex: 25-35 min"
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                      />
                    </div>

                    <div className="sm:col-span-2 flex items-center gap-2 pt-1">
                      <input
                        type="checkbox"
                        id="check-popular"
                        checked={formPopular}
                        onChange={(e) => setFormPopular(e.target.checked)}
                        className="w-4 h-4 text-rose-600 rounded-md border-stone-300 cursor-pointer"
                      />
                      <label htmlFor="check-popular" className="font-bold text-stone-800 cursor-pointer">
                        Mettre en vedette dans "Les Incontournables" de la page d'accueil
                      </label>
                    </div>
                  </div>

                  {/* Form Actions */}
                  <div className="pt-3 border-t border-stone-200 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsDishFormOpen(false)}
                      className="px-4 py-2.5 rounded-xl text-xs font-bold text-stone-600 bg-stone-200 hover:bg-stone-300 transition-colors"
                    >
                      Annuler
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveDish}
                      className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-md shadow-rose-600/20 active:scale-95 transition-all flex items-center gap-1.5"
                    >
                      <Save className="w-4 h-4" />
                      <span>{editingDish ? 'Sauvegarder les modifications' : 'Ajouter au catalogue'}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {/* Top search & Add Button */}
                  <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-stone-200">
                    <div className="relative flex-1 min-w-[200px]">
                      <input
                        type="text"
                        value={dishSearchQuery}
                        onChange={(e) => setDishSearchQuery(e.target.value)}
                        placeholder="Rechercher un met..."
                        className="w-full pl-8 pr-3 py-2 rounded-xl border border-stone-300 bg-stone-50/50 text-xs"
                      />
                      <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-3" />
                    </div>

                    <select
                      value={dishCategoryFilter}
                      onChange={(e) => setDishCategoryFilter(e.target.value)}
                      className="p-2 rounded-xl border border-stone-300 bg-stone-50/50 font-medium text-xs"
                    >
                      <option value="Tous">Toutes les catégories</option>
                      {categoryList.map(c => (
                        <option key={c.id} value={c.name}>{c.icon} {c.name}</option>
                      ))}
                    </select>

                    <button
                      type="button"
                      onClick={() => openDishForm()}
                      className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-md shadow-rose-600/20 active:scale-95 transition-all cursor-pointer text-xs"
                    >
                      <Plus className="w-4 h-4" />
                      <span>+ Nouveau Met</span>
                    </button>
                  </div>

                  {/* Dishes Table / Cards list */}
                  <div className="bg-white rounded-2xl border border-stone-200 divide-y divide-stone-100 overflow-hidden">
                    {filteredDishes.map((dish) => {
                      const minPrice = dish.portions && dish.portions.length > 0
                        ? Math.min(...dish.portions.map(p => p.price))
                        : 3000;
                      const maxPrice = dish.portions && dish.portions.length > 0
                        ? Math.max(...dish.portions.map(p => p.price))
                        : 3000;

                      const isAvailable = dish.availability === 'disponible' || !dish.availability;

                      return (
                        <div
                          key={dish.id}
                          className="p-3.5 hover:bg-rose-50/20 transition-colors flex items-center justify-between gap-3 text-xs"
                        >
                          <img
                            src={dish.image}
                            alt={dish.name}
                            referrerPolicy="no-referrer"
                            className="w-14 h-14 rounded-xl object-cover border border-stone-200 shrink-0"
                          />

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-stone-900 text-sm truncate">{dish.name}</span>
                              <span className="bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md text-[10px] font-medium shrink-0">
                                {dish.category}
                              </span>
                              {dish.badge && (
                                <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded-md text-[10px] font-bold shrink-0">
                                  {dish.badge}
                                </span>
                              )}
                              {!isAvailable && (
                                <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded-md text-[10px] font-bold shrink-0">
                                  {dish.availability === 'epuise' ? 'Épuisé' : 'Indisponible'}
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="font-extrabold text-rose-600 font-mono">
                                {dish.portions && dish.portions.length > 1
                                  ? `${formatFCFA(minPrice)} - ${formatFCFA(maxPrice)} (${dish.portions.length} tailles)`
                                  : formatFCFA(minPrice)}
                              </span>
                              <span className="text-stone-300">•</span>
                              <span className="text-stone-500 text-[11px] truncate">
                                {dish.description}
                              </span>
                            </div>
                          </div>

                          {/* Quick Actions */}
                          <div className="flex items-center gap-1.5 shrink-0">
                            {/* Stock toggle */}
                            <button
                              type="button"
                              onClick={() => handleToggleDishStock(dish)}
                              title={isAvailable ? 'Marquer comme épuisé' : 'Marquer comme disponible'}
                              className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                                !isAvailable
                                  ? 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                                  : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                              }`}
                            >
                              {!isAvailable ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>

                            {/* Edit */}
                            <button
                              type="button"
                              onClick={() => openDishForm(dish)}
                              className="p-2 bg-stone-100 hover:bg-rose-100 text-stone-700 hover:text-rose-700 rounded-xl transition-colors cursor-pointer"
                              title="Modifier toutes les options"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>

                            {/* Delete */}
                            <button
                              type="button"
                              onClick={() => handleDeleteDish(dish.id, dish.name)}
                              className="p-2 bg-stone-100 hover:bg-red-100 text-stone-400 hover:text-red-600 rounded-xl transition-colors cursor-pointer"
                              title="Supprimer du menu"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Reset and Clear Demo data buttons */}
                  <div className="pt-3 border-t border-stone-200 flex flex-wrap justify-between items-center gap-3 text-xs">
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm('Attention : Voulez-vous supprimer TOUS les plats de démonstration pour partir de zéro ?')) {
                          setItems([]);
                          onSaveMenu([]);
                          showToast('Tous les plats de démo ont été supprimés. Vous pouvez ajouter vos vrais mets.');
                        }
                      }}
                      className="text-red-500 hover:text-red-700 flex items-center gap-1.5 font-medium hover:underline cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Supprimer tous les plats (Vider la démo)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (confirm('Attention : Voulez-vous réinitialiser le catalogue avec les 15 mets camerounais par défaut ?')) {
                          const restored = onResetMenu();
                          setItems(restored);
                          showToast('Catalogue réinitialisé avec succès !');
                        }
                      }}
                      className="text-stone-500 hover:text-stone-800 flex items-center gap-1.5 font-medium hover:underline cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Restaurer les 15 mets officiels</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 3: CATÉGORIES & SOUS-CATÉGORIES */}
          {/* ========================================================================= */}
          {activeTab === 'categories' && (
            <div className="space-y-4 text-xs">
              {isCatFormOpen ? (
                /* Category Form */
                <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-2">
                    <h3 className="font-bold text-stone-900 text-sm">
                      {editingCategory ? `Modifier "${editingCategory.name}"` : 'Créer une nouvelle catégorie'}
                    </h3>
                    <button onClick={() => setIsCatFormOpen(false)} className="text-stone-400 hover:text-stone-700">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Nom de la catégorie *</label>
                      <input
                        type="text"
                        value={newCatName}
                        onChange={(e) => setNewCatName(e.target.value)}
                        placeholder="Ex: Légumes & Feuilles, Grillades..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Icône Emoji</label>
                      <input
                        type="text"
                        value={newCatIcon}
                        onChange={(e) => setNewCatIcon(e.target.value)}
                        placeholder="Ex: 🍃, 🔥, 🍲, 🍖..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 text-base"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 mb-1">
                        Sous-catégories associées (séparées par une virgule)
                      </label>
                      <input
                        type="text"
                        value={newCatSubcategories}
                        onChange={(e) => setNewCatSubcategories(e.target.value)}
                        placeholder="Ex: Poissons braisés, Volailles braisées, Brochettes..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsCatFormOpen(false)}
                      className="px-4 py-2 rounded-xl text-stone-600 bg-stone-200 hover:bg-stone-300 font-bold"
                    >
                      Annuler
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveCategory}
                      className="px-5 py-2 rounded-xl text-white bg-rose-600 hover:bg-rose-700 font-bold flex items-center gap-1.5 shadow-2xs"
                    >
                      <Save className="w-4 h-4" />
                      <span>Enregistrer la catégorie</span>
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between bg-white p-3.5 rounded-2xl border border-stone-200">
                    <p className="text-stone-500">
                      Gérez vos 8 grandes familles de mets et leurs sous-catégories de recherche.
                    </p>
                    <button
                      onClick={() => handleOpenCatForm()}
                      className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-3.5 py-2 rounded-xl flex items-center gap-1 shadow-2xs"
                    >
                      <Plus className="w-4 h-4" />
                      <span>+ Nouvelle Catégorie</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {categoryList.map((cat) => {
                      const count = items.filter(i => i.category === cat.name).length;
                      return (
                        <div key={cat.id} className="bg-white p-4 rounded-2xl border border-stone-200 space-y-2 shadow-2xs">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-xl">{cat.icon}</span>
                              <span className="font-bold text-stone-900 text-sm">{cat.name}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <span className="bg-stone-100 text-stone-600 px-2 py-0.5 rounded-md text-[10px] font-bold">
                                {count} met{count > 1 ? 's' : ''}
                              </span>
                              <button
                                onClick={() => handleOpenCatForm(cat)}
                                className="p-1.5 text-stone-500 hover:text-rose-600 rounded-lg hover:bg-stone-100"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteCategory(cat.id, cat.name)}
                                className="p-1.5 text-stone-400 hover:text-red-600 rounded-lg hover:bg-red-50"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-1 pt-1">
                            {cat.subcategories.map((sub, sIdx) => (
                              <span key={sIdx} className="bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md text-[10px]">
                                {sub}
                              </span>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 4: SETTINGS & PAIEMENTS (MOMO / OM / ESPÈCES / HORAIRES / QUARTIERS) */}
          {/* ========================================================================= */}
          {activeTab === 'settings' && (
            <div className="space-y-5 text-xs">
              {/* 1. Modes de Paiement */}
              <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4">
                <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                  <h3 className="font-display font-extrabold text-stone-900 text-sm">
                    1. Moyens de Paiement (Activer, Modifier les numéros et comptes)
                  </h3>
                </div>

                {/* MTN Mobile Money */}
                <div className="p-3.5 rounded-xl border border-stone-200 bg-amber-50/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="flex items-center gap-2 cursor-pointer font-bold text-stone-900">
                      <input
                        type="checkbox"
                        checked={restaurantSettings.momoEnabled !== false}
                        onChange={(e) =>
                          setRestaurantSettings({ ...restaurantSettings, momoEnabled: e.target.checked })
                        }
                        className="w-4 h-4 text-amber-600 rounded-md border-stone-300 cursor-pointer"
                      />
                      <span className="flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-md bg-amber-400 text-stone-900 font-black text-[10px] flex items-center justify-center">MoMo</span>
                        Activer le paiement par MTN Mobile Money
                      </span>
                    </label>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${restaurantSettings.momoEnabled !== false ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-600'}`}>
                      {restaurantSettings.momoEnabled !== false ? 'Activé' : 'Désactivé'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                    <div>
                      <label className="block text-[11px] font-bold text-stone-700 mb-1">Numéro MTN MoMo *</label>
                      <input
                        type="text"
                        value={restaurantSettings.momoNumber}
                        onChange={(e) =>
                          setRestaurantSettings({ ...restaurantSettings, momoNumber: e.target.value })
                        }
                        placeholder="Ex: 6 70 00 00 00"
                        className="w-full p-2 rounded-xl border border-stone-300 bg-white font-bold text-stone-900"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-stone-700 mb-1">Nom du titulaire MTN MoMo</label>
                      <input
                        type="text"
                        value={restaurantSettings.momoName}
                        onChange={(e) =>
                          setRestaurantSettings({ ...restaurantSettings, momoName: e.target.value })
                        }
                        placeholder="Ex: YAOUNDÉ DÉLICES"
                        className="w-full p-2 rounded-xl border border-stone-300 bg-white font-medium"
                      />
                    </div>
                  </div>
                </div>

                {/* Orange Money */}
                <div className="p-3.5 rounded-xl border border-stone-200 bg-orange-50/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="flex items-center gap-2 cursor-pointer font-bold text-stone-900">
                      <input
                        type="checkbox"
                        checked={restaurantSettings.omEnabled !== false}
                        onChange={(e) =>
                          setRestaurantSettings({ ...restaurantSettings, omEnabled: e.target.checked })
                        }
                        className="w-4 h-4 text-orange-600 rounded-md border-stone-300 cursor-pointer"
                      />
                      <span className="flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-md bg-orange-500 text-white font-black text-[10px] flex items-center justify-center">OM</span>
                        Activer le paiement par Orange Money
                      </span>
                    </label>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${restaurantSettings.omEnabled !== false ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-600'}`}>
                      {restaurantSettings.omEnabled !== false ? 'Activé' : 'Désactivé'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                    <div>
                      <label className="block text-[11px] font-bold text-stone-700 mb-1">Numéro Orange Money *</label>
                      <input
                        type="text"
                        value={restaurantSettings.omNumber}
                        onChange={(e) =>
                          setRestaurantSettings({ ...restaurantSettings, omNumber: e.target.value })
                        }
                        placeholder="Ex: 6 90 00 00 00"
                        className="w-full p-2 rounded-xl border border-stone-300 bg-white font-bold text-stone-900"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-stone-700 mb-1">Nom du titulaire Orange Money</label>
                      <input
                        type="text"
                        value={restaurantSettings.omName || ''}
                        onChange={(e) =>
                          setRestaurantSettings({ ...restaurantSettings, omName: e.target.value })
                        }
                        placeholder="Ex: YAOUNDÉ DÉLICES"
                        className="w-full p-2 rounded-xl border border-stone-300 bg-white font-medium"
                      />
                    </div>
                  </div>
                </div>

                {/* Espèces */}
                <div className="p-3.5 rounded-xl border border-stone-200 bg-emerald-50/40 flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-stone-900">
                    <input
                      type="checkbox"
                      checked={restaurantSettings.cashEnabled !== false}
                      onChange={(e) =>
                        setRestaurantSettings({ ...restaurantSettings, cashEnabled: e.target.checked })
                      }
                      className="w-4 h-4 text-emerald-600 rounded-md border-stone-300 cursor-pointer"
                    />
                    <span>💵 Activer le paiement en Espèces à la livraison</span>
                  </label>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${restaurantSettings.cashEnabled !== false ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-600'}`}>
                    {restaurantSettings.cashEnabled !== false ? 'Activé' : 'Désactivé'}
                  </span>
                </div>
              </div>

              {/* Delivery Rates & Working Hours */}
              <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4">
                <h3 className="font-display font-extrabold text-stone-900 text-sm border-b border-stone-100 pb-2">
                  2. Tarifs de Livraison & Horaires de Service
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Frais de livraison standard (FCFA)</label>
                    <input
                      type="number"
                      value={restaurantSettings.standardDeliveryFee}
                      onChange={(e) =>
                        setRestaurantSettings({ ...restaurantSettings, standardDeliveryFee: Number(e.target.value) })
                      }
                      step="100"
                      className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 font-bold"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Seuil Livraison Offerte (FCFA)</label>
                    <input
                      type="number"
                      value={restaurantSettings.freeDeliveryThreshold}
                      onChange={(e) =>
                        setRestaurantSettings({ ...restaurantSettings, freeDeliveryThreshold: Number(e.target.value) })
                      }
                      step="500"
                      className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 font-bold"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Numéro WhatsApp (sans le +)</label>
                    <input
                      type="text"
                      value={restaurantSettings.phoneWhatsApp}
                      onChange={(e) =>
                        setRestaurantSettings({ ...restaurantSettings, phoneWhatsApp: e.target.value })
                      }
                      placeholder="Ex: 237670000000"
                      className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Téléphone pour Appels</label>
                    <input
                      type="text"
                      value={restaurantSettings.phoneCall}
                      onChange={(e) =>
                        setRestaurantSettings({ ...restaurantSettings, phoneCall: e.target.value })
                      }
                      placeholder="Ex: +237 6 70 00 00 00"
                      className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Horaires de commande</label>
                    <div className="flex gap-2">
                      <input
                        type="time"
                        value={restaurantSettings.openingTime}
                        onChange={(e) =>
                          setRestaurantSettings({ ...restaurantSettings, openingTime: e.target.value })
                        }
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 font-medium"
                      />
                      <span className="self-center font-bold text-stone-400">à</span>
                      <input
                        type="time"
                        value={restaurantSettings.closingTime}
                        onChange={(e) =>
                          setRestaurantSettings({ ...restaurantSettings, closingTime: e.target.value })
                        }
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 font-medium"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Jours d'ouverture</label>
                    <input
                      type="text"
                      value={restaurantSettings.workingDays}
                      onChange={(e) =>
                        setRestaurantSettings({ ...restaurantSettings, workingDays: e.target.value })
                      }
                      placeholder="Ex: Lundi au Samedi"
                      className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 font-medium"
                    />
                  </div>
                </div>
              </div>

              {/* Delivery Zones */}
              <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3">
                <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                  <h3 className="font-display font-extrabold text-stone-900 text-sm">
                    3. Quartiers & Zones de Livraison à Yaoundé ({restaurantSettings.deliveryZones.length})
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm('Voulez-vous restaurer les 20 quartiers principaux de Yaoundé ?')) {
                        const defaultZones = [
                          "Bastos", "Mvog-Mbi", "Mokolo", "Etoudi", "Nlongkak", "Omnisports",
                          "Biyem-Assi", "Tsinga", "Odza", "Mendong", "Essos", "Melen",
                          "Santa Barbara", "Nkolbisson", "Ngousso", "Emana", "Ekounou", "Messassi",
                          "Madagascar", "Camp SIC"
                        ];
                        setRestaurantSettings({ ...restaurantSettings, deliveryZones: defaultZones });
                        showToast('Zones de livraison restaurées.');
                      }
                    }}
                    className="text-stone-500 hover:text-stone-900 text-[11px] underline flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" /> Restaurer quartiers par défaut
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto p-1">
                  {restaurantSettings.deliveryZones.map((zone, zIdx) => (
                    <span
                      key={zIdx}
                      className="bg-stone-100 hover:bg-stone-200 border border-stone-300 px-2.5 py-1 rounded-xl text-stone-800 font-medium flex items-center gap-1.5 shadow-2xs"
                    >
                      <MapPin className="w-3 h-3 text-rose-500 shrink-0" />
                      <span>{zone}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveZone(zone)}
                        className="text-stone-400 hover:text-red-600 ml-1 cursor-pointer"
                        title="Retirer ce quartier"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>

                <div className="flex gap-2 pt-2">
                  <input
                    type="text"
                    value={newZoneInput}
                    onChange={(e) => setNewZoneInput(e.target.value)}
                    placeholder="Ajouter un nouveau quartier (ex: Mvan, Simbock, Ahala)..."
                    className="flex-1 p-2.5 rounded-xl border border-stone-300 bg-stone-50/50 text-xs"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddZone();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddZone}
                    className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Ajouter quartier</span>
                  </button>
                </div>
              </div>

              {/* 4. Auto-Update & Synchronisation Système */}
              <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4">
                <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="font-display font-extrabold text-stone-900 text-sm">
                        4. Système de Mise à Jour Automatique & Rechargement
                      </h3>
                      <p className="text-stone-500 text-[11px]">
                        Vérifie en continu (toutes les 30s) si une nouvelle version ou modification est disponible.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Mode */}
                  <div className="space-y-2">
                    <label className="block font-bold text-stone-700">Mode de mise à jour :</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setAutoUpdateMode('banner');
                          showToast('Mode défini : Notification avec bouton de rechargement');
                        }}
                        className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                          getAutoUpdateMode() === 'banner'
                            ? 'bg-amber-50 border-amber-400 text-amber-950 font-bold shadow-2xs'
                            : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <Bell className="w-3.5 h-3.5 text-amber-600" />
                          <span>Notification</span>
                        </div>
                        <p className="text-[10px] text-stone-500 mt-1 font-normal">
                          Affiche « Une nouvelle version est disponible » avec un bouton pour recharger.
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setAutoUpdateMode('silent');
                          showToast('Mode défini : Rechargement automatique silencieux');
                        }}
                        className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                          getAutoUpdateMode() === 'silent'
                            ? 'bg-emerald-50 border-emerald-400 text-emerald-950 font-bold shadow-2xs'
                            : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <Zap className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Silencieux</span>
                        </div>
                        <p className="text-[10px] text-stone-500 mt-1 font-normal">
                          Recharge automatiquement la page sans action requise de votre part.
                        </p>
                      </button>
                    </div>
                  </div>

                  {/* Interval & Tests */}
                  <div className="space-y-2">
                    <label className="block font-bold text-stone-700">Fréquence de vérification :</label>
                    <div className="flex items-center gap-2 bg-stone-50 p-1.5 rounded-xl border border-stone-200">
                      {[15, 30, 60].map((sec) => (
                        <button
                          key={sec}
                          type="button"
                          onClick={() => {
                            setAutoUpdateInterval(sec);
                            showToast(`Fréquence ajustée à toutes les ${sec} secondes`);
                          }}
                          className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                            getAutoUpdateInterval() === sec
                              ? 'bg-stone-900 text-white shadow-2xs'
                              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200'
                          }`}
                        >
                          {sec} secondes
                        </button>
                      ))}
                    </div>

                    <div className="pt-2 flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          const hasUpdate = await checkForUpdate(true);
                          if (hasUpdate) {
                            showToast('✨ Une nouvelle version a été détectée !');
                          } else {
                            showToast('✅ Votre application est déjà à jour (aucune nouvelle version détectée)');
                          }
                        }}
                        className="flex-1 py-2 px-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <RefreshCw className="w-3 h-3 text-stone-600" />
                        <span>Vérifier maintenant</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          simulateNewVersion();
                          showToast('Simulation d\'une nouvelle version activée !');
                        }}
                        className="py-2 px-3 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                        title="Déclenche l'alerte pour tester le bandeau ou le rechargement"
                      >
                        <Sparkles className="w-3 h-3 text-amber-700" />
                        <span>Tester l'alerte</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Save Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={handleSaveSettings}
                  className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-6 py-3 rounded-xl text-xs flex items-center gap-2 shadow-md shadow-rose-600/20 active:scale-95 transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Enregistrer tous les paramètres</span>
                </button>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 5: SÉCURITÉ & CHANGEMENT DE MOT DE PASSE */}
          {/* ========================================================================= */}
          {activeTab === 'security' && (
            <div className="max-w-md mx-auto bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-5 text-xs">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
                  <KeyRound className="w-6 h-6" />
                </div>
                <h3 className="font-display font-extrabold text-stone-900 text-base">
                  Changer le mot de passe Administrateur
                </h3>
                <p className="text-stone-500 text-[11px]">
                  Définissez un nouveau mot de passe pour verrouiller l'accès au tableau de bord.
                </p>
              </div>

              <form onSubmit={handleChangePassword} className="space-y-3.5">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Mot de passe actuel *</label>
                  <input
                    type="password"
                    value={currentPwInput}
                    onChange={(e) => setCurrentPwInput(e.target.value)}
                    placeholder="Saisissez le mot de passe actuel..."
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Nouveau mot de passe *</label>
                  <input
                    type="password"
                    value={newPwInput}
                    onChange={(e) => setNewPwInput(e.target.value)}
                    placeholder="Minimum 4 caractères..."
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Confirmer le nouveau mot de passe *</label>
                  <input
                    type="password"
                    value={confirmPwInput}
                    onChange={(e) => setConfirmPwInput(e.target.value)}
                    placeholder="Répétez le nouveau mot de passe..."
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-stone-50/50"
                  />
                </div>

                {pwChangeError && (
                  <div className="bg-red-50 text-red-700 p-2.5 rounded-xl border border-red-200 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{pwChangeError}</span>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full bg-rose-600 hover:bg-rose-700 text-white font-bold py-3 rounded-xl shadow-md shadow-rose-600/20 active:scale-95 transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer"
                >
                  <Lock className="w-4 h-4" />
                  <span>Enregistrer le nouveau mot de passe</span>
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
