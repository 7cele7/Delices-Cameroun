import React from 'react';
import { Clock, CheckCircle, ChefHat, Bike, PackageCheck, Phone, Send, MapPin } from 'lucide-react';
import { Order, RestaurantConfig } from '../types';
import { formatFCFA } from '../utils/formatters';
import { openWhatsAppOrder } from '../utils/whatsapp';

interface OrdersTrackerProps {
  orders: Order[];
  config: RestaurantConfig;
  onUpdateStatus: (orderId: string, status: Order['status']) => void;
  onStartNewOrder: () => void;
}

const STATUS_STEPS = [
  { key: 'received', label: 'Commande Reçue', icon: CheckCircle, desc: 'Prise en compte par la cuisine' },
  { key: 'preparing', label: 'En Préparation', icon: ChefHat, desc: 'Cuisson et assaisonnement en cours' },
  { key: 'on_the_way', label: 'En Route', icon: Bike, desc: 'Le livreur arrive dans votre quartier' },
  { key: 'delivered', label: 'Livrée', icon: PackageCheck, desc: 'Bon appétit !' },
] as const;

export const OrdersTracker: React.FC<OrdersTrackerProps> = ({
  orders,
  config,
  onUpdateStatus,
  onStartNewOrder,
}) => {
  if (orders.length === 0) {
    return (
      <div className="max-w-xl mx-auto py-16 px-4 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8" />
        </div>
        <h2 className="font-display font-bold text-stone-900 text-xl">
          Aucune commande en cours
        </h2>
        <p className="text-stone-500 text-xs sm:text-sm max-w-sm mx-auto">
          Vous n'avez pas encore passé de commande aujourd'hui. Découvrez notre délicieuse sélection de mets camerounais !
        </p>
        <button
          onClick={onStartNewOrder}
          className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs shadow-md shadow-rose-600/20 active:scale-95 transition-all cursor-pointer"
        >
          Commander maintenant
        </button>
      </div>
    );
  }

  const getStepIndex = (status: Order['status']): number => {
    switch (status) {
      case 'received': return 0;
      case 'preparing': return 1;
      case 'on_the_way': return 2;
      case 'delivered': return 3;
      default: return 0;
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-extrabold text-2xl text-stone-900">
            Suivi de vos commandes
          </h1>
          <p className="text-stone-500 text-xs mt-0.5">
            Historique et état en direct de vos plats à Yaoundé
          </p>
        </div>
        <button
          onClick={onStartNewOrder}
          className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl shadow-xs cursor-pointer"
        >
          + Nouvelle commande
        </button>
      </div>

      <div className="space-y-4">
        {orders.map((order) => {
          const currentStep = getStepIndex(order.status);

          return (
            <div
              key={order.id}
              id={`order-tracking-${order.id}`}
              className="bg-white rounded-3xl border border-stone-200 shadow-xs hover:shadow-md transition-shadow p-5 sm:p-6 space-y-5"
            >
              {/* Top Header */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-stone-100">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                  <span className="font-mono font-extrabold text-rose-600 text-base">
                    #{order.id}
                  </span>
                  <span className="text-stone-300">•</span>
                  <span className="text-xs text-stone-500">
                    {new Date(order.createdAt).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200 px-2.5 py-1 rounded-lg">
                    {STATUS_STEPS[currentStep].label}
                  </span>
                  <span className="font-display font-extrabold text-stone-900 text-sm">
                    {formatFCFA(order.total)}
                  </span>
                </div>
              </div>

              {/* Status Stepper */}
              <div className="py-2">
                <div className="grid grid-cols-4 gap-2 relative">
                  {/* Connecting line */}
                  <div className="absolute top-4 left-6 right-6 h-1 bg-stone-200 -z-0">
                    <div
                      className="h-full bg-emerald-500 transition-all duration-500"
                      style={{ width: `${(currentStep / 3) * 100}%` }}
                    />
                  </div>

                  {STATUS_STEPS.map((step, idx) => {
                    const isCompleted = idx <= currentStep;
                    const isCurrent = idx === currentStep;
                    const StepIcon = step.icon;

                    return (
                      <div key={step.key} className="flex flex-col items-center text-center z-10">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all ${
                            isCompleted
                              ? 'bg-emerald-500 border-emerald-500 text-white shadow-md shadow-emerald-500/20'
                              : 'bg-white border-stone-300 text-stone-400'
                          } ${isCurrent ? 'ring-4 ring-emerald-100 scale-110' : ''}`}
                        >
                          <StepIcon className="w-4 h-4" />
                        </div>
                        <div className="mt-2 text-[10px] sm:text-xs font-bold text-stone-800 leading-tight">
                          {step.label}
                        </div>
                        <div className="text-[9px] text-stone-400 hidden sm:block mt-0.5">
                          {step.desc}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Order Content & Location Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 bg-stone-50/70 p-3.5 rounded-2xl border border-stone-100 text-xs">
                <div>
                  <div className="font-bold text-stone-700 uppercase text-[10px] tracking-wider mb-1.5">
                    Mets commandés
                  </div>
                  <div className="space-y-1">
                    {order.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between text-stone-600">
                        <span className="font-medium truncate pr-2">
                          {it.quantity}x {it.item.name} {it.selectedPortion ? `(${it.selectedPortion.name})` : ''}
                        </span>
                        <span className="shrink-0">{formatFCFA(it.totalPrice || (it.item.price * it.quantity))}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-t md:border-t-0 md:border-l border-stone-200 pt-2 md:pt-0 md:pl-3">
                  <div className="font-bold text-stone-700 uppercase text-[10px] tracking-wider mb-1.5">
                    Destination & Client
                  </div>
                  <div className="text-stone-600 space-y-0.5">
                    <div className="font-semibold text-stone-900">{order.customerName} ({order.customerPhone})</div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-rose-500 shrink-0" />
                      <span>{order.neighborhood} • {order.landmark || order.manualAddress}</span>
                    </div>
                    {order.gpsLocation && (
                      <div className="text-[10px] text-emerald-700 font-medium">
                        📍 GPS : {order.gpsLocation.latitude.toFixed(4)}, {order.gpsLocation.longitude.toFixed(4)}
                      </div>
                    )}
                    <div className="pt-1">
                      <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded-md bg-stone-200/80 text-stone-700">
                        Paiement :{' '}
                        {order.paymentMethod === 'momo'
                          ? '🟡 MTN MoMo'
                          : order.paymentMethod === 'om'
                          ? '🟠 Orange Money'
                          : '💵 Espèces'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Actions (Call kitchen, WhatsApp, Advance Status for Demo) */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${config.phoneCall.replace(/\s+/g, '')}`}
                    className="inline-flex items-center gap-1 text-xs font-bold text-stone-700 hover:text-rose-600 bg-stone-100 hover:bg-stone-200 px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Appeler le restaurant</span>
                  </a>

                  <button
                    onClick={() => openWhatsAppOrder(order, config)}
                    className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                </div>

                {/* Status Advancement Button */}
                {order.status !== 'delivered' && order.status !== 'cancelled' && (
                  <button
                    onClick={() => {
                      const nextStatusMap: Record<Order['status'], Order['status']> = {
                        received: 'preparing',
                        preparing: 'on_the_way',
                        on_the_way: 'delivered',
                        delivered: 'delivered',
                        cancelled: 'cancelled',
                      };
                      onUpdateStatus(order.id, nextStatusMap[order.status]);
                    }}
                    className="text-[11px] font-semibold text-rose-600 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>Faire avancer l'état (Test) →</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
