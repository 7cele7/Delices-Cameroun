import React from 'react';
import { Phone, MessageCircle, MapPin, Lock, UtensilsCrossed } from 'lucide-react';
import { RestaurantConfig } from '../types';

interface FooterProps {
  config: RestaurantConfig;
  setActiveTab: (tab: string) => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ config, onOpenAdmin }) => {
  return (
    <footer className="bg-stone-900 text-stone-300 py-8 pb-20 md:pb-8 border-t border-stone-800">
      <div className="max-w-4xl mx-auto px-4 text-center space-y-4">
        {/* Brand */}
        <div className="space-y-1">
          <div className="flex items-center justify-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-rose-600 to-amber-500 flex items-center justify-center text-white shadow-md">
              <UtensilsCrossed className="w-4 h-4" />
            </div>
            <span className="font-display font-extrabold text-2xl text-white tracking-tight">
              Yaoundé<span className="text-rose-500">Délices</span>
            </span>
          </div>
          <p className="text-xs text-stone-400 font-medium">
            Mets camerounais • Livraison à domicile
          </p>
        </div>

        {/* Contact info */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-stone-300">
          <a
            href={`https://wa.me/${config.phoneWhatsApp.replace(/\D/g, '')}`}
            target="_blank"
            rel="noreferrer"
            className="hover:text-white inline-flex items-center gap-1.5 bg-stone-800/80 hover:bg-stone-800 px-3 py-1.5 rounded-xl border border-stone-700/60 transition-colors"
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>📞 Contact WhatsApp : {config.phoneCall}</span>
          </a>

          <div className="inline-flex items-center gap-1.5 text-stone-400 bg-stone-800/40 px-3 py-1.5 rounded-xl">
            <MapPin className="w-3.5 h-3.5 text-rose-400" />
            <span>📍 Yaoundé</span>
          </div>
        </div>

        {/* Copyright & Admin button */}
        <div className="pt-2 border-t border-stone-800/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-stone-500">
          <div>
            © 2026 YaoundéDélices
          </div>

          <button
            id="btn-footer-admin"
            onClick={onOpenAdmin}
            className="inline-flex items-center gap-1.5 text-[11px] text-stone-500 hover:text-amber-400 px-2.5 py-1 rounded-lg hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <Lock className="w-3 h-3" />
            <span>Administration</span>
          </button>
        </div>
      </div>
    </footer>
  );
};

