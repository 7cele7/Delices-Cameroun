import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  RefreshCw,
  Zap,
  CheckCircle2,
  X,
  Settings2,
  Bell,
  EyeOff,
  Clock,
  ArrowRight
} from 'lucide-react';
import {
  VersionInfo,
  subscribeToVersionUpdates,
  checkForUpdate,
  triggerReload,
  dismissUpdateNotification,
  setAutoUpdateMode,
  setAutoUpdateInterval,
  simulateNewVersion,
  isAutoUpdateEnabled,
  setAutoUpdateEnabled
} from '../utils/versionChecker';

export const AutoUpdateBanner: React.FC = () => {
  const [versionInfo, setVersionInfo] = useState<VersionInfo>({
    versionId: 'v1',
    checkedAt: Date.now(),
    hasUpdate: false,
    mode: 'banner',
    checkIntervalSeconds: 30,
    isChecking: false,
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [secondsAgo, setSecondsAgo] = useState(0);
  const [isReloading, setIsReloading] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToVersionUpdates((info) => {
      setVersionInfo(info);
    });

    // Tick for seconds since last check
    const ticker = setInterval(() => {
      const diff = Math.floor((Date.now() - versionInfo.checkedAt) / 1000);
      setSecondsAgo(Math.max(0, diff));
    }, 1000);

    return () => {
      unsubscribe();
      clearInterval(ticker);
    };
  }, [versionInfo.checkedAt]);

  const handleManualCheck = async () => {
    await checkForUpdate(true);
  };

  const handleReloadClick = () => {
    setIsReloading(true);
    setTimeout(() => {
      triggerReload();
    }, 300);
  };

  const handleToggleMode = () => {
    const nextMode = versionInfo.mode === 'banner' ? 'silent' : 'banner';
    setAutoUpdateMode(nextMode);
  };

  return (
    <>
      {/* 1. PRIMARY NOTIFICATION BANNER (When update is available) */}
      {versionInfo.hasUpdate && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 w-[94%] max-w-2xl animate-bounce-short">
          <div className="bg-gradient-to-r from-stone-950 via-stone-900 to-amber-950 text-white p-3.5 sm:p-4 rounded-2xl shadow-2xl border-2 border-amber-400/80 ring-4 ring-amber-500/20 backdrop-blur-md">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              {/* Message & Icon */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-black shrink-0 animate-pulse">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-display font-extrabold text-sm sm:text-base text-amber-300">
                      Une nouvelle version est disponible !
                    </h4>
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Nouveau
                    </span>
                  </div>
                  <p className="text-xs text-stone-300 mt-0.5">
                    Cliquez ici pour charger les dernières améliorations et données en direct.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end pt-1 sm:pt-0">
                <button
                  type="button"
                  onClick={handleReloadClick}
                  disabled={isReloading}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-stone-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${isReloading ? 'animate-spin' : ''}`} />
                  <span>{isReloading ? 'Chargement...' : 'Recharger la page'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => dismissUpdateNotification()}
                  className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
                  title="Fermer cette alerte"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Quick Option toggle inside banner */}
            <div className="mt-2.5 pt-2 border-t border-stone-800/80 flex items-center justify-between text-[11px] text-stone-400">
              <span className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Mode actuel : {versionInfo.mode === 'silent' ? 'Rechargement silencieux' : 'Notification visuelle'}</span>
              </span>
              <button
                type="button"
                onClick={handleToggleMode}
                className="text-amber-300 hover:underline font-medium cursor-pointer"
              >
                {versionInfo.mode === 'banner' ? 'Activer le rechargement silencieux' : 'Passer en mode notification'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. DISCREET AUTO-SYNC STATUS BADGE (Fixed Bottom Right on Desktop & Mobile) */}
      <div className="fixed bottom-20 sm:bottom-4 right-3 sm:right-4 z-40">
        <div className="relative">
          {/* Main Status Pill */}
          <div className="flex items-center gap-1.5 bg-stone-900/90 hover:bg-stone-900 text-white pl-2.5 pr-2 py-1.5 rounded-full shadow-lg border border-stone-700/80 backdrop-blur-xs text-[11px] transition-all">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                versionInfo.isChecking ? 'bg-amber-400' : 'bg-emerald-400'
              }`} />
              <span className={`relative inline-flex rounded-full h-2 w-2 ${
                versionInfo.isChecking ? 'bg-amber-500' : 'bg-emerald-500'
              }`} />
            </span>

            <span className="font-medium text-stone-300">
              {versionInfo.isChecking
                ? 'Vérification...'
                : versionInfo.mode === 'silent'
                ? 'Sync Silencieux (30s)'
                : `Vérifié il y a ${secondsAgo}s`}
            </span>

            {/* Quick Check Button */}
            <button
              type="button"
              onClick={handleManualCheck}
              disabled={versionInfo.isChecking}
              className="p-1 rounded-full text-stone-400 hover:text-amber-300 hover:bg-stone-800 transition-colors cursor-pointer"
              title="Vérifier immédiatement si une nouvelle version est disponible"
            >
              <RefreshCw className={`w-3 h-3 ${versionInfo.isChecking ? 'animate-spin text-amber-400' : ''}`} />
            </button>

            {/* Open Settings Popover */}
            <button
              type="button"
              onClick={() => setIsSettingsOpen(!isSettingsOpen)}
              className="p-1 rounded-full text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
              title="Configurer les options de mise à jour automatique"
            >
              <Settings2 className="w-3 h-3" />
            </button>
          </div>

          {/* Quick Settings Dropdown */}
          {isSettingsOpen && (
            <div className="absolute bottom-full right-0 mb-2 w-72 bg-white rounded-2xl p-4 shadow-2xl border border-stone-200 text-stone-800 space-y-3 z-50 animate-fadeIn">
              <div className="flex items-center justify-between pb-2 border-b border-stone-100">
                <div className="flex items-center gap-1.5 font-bold text-xs text-stone-900">
                  <Zap className="w-3.5 h-3.5 text-amber-600" />
                  <span>Mise à Jour Automatique</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSettingsOpen(false)}
                  className="text-stone-400 hover:text-stone-700"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Mode Selection */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-stone-600">Comportement de détection :</label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setAutoUpdateMode('banner')}
                    className={`p-2 rounded-xl text-left border text-xs font-medium transition-all cursor-pointer ${
                      versionInfo.mode === 'banner'
                        ? 'bg-amber-50 border-amber-400 text-amber-950 font-bold'
                        : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      <Bell className="w-3 h-3 text-amber-600" />
                      <span>Bannière</span>
                    </div>
                    <div className="text-[10px] text-stone-500 mt-0.5">Demande de clic</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setAutoUpdateMode('silent')}
                    className={`p-2 rounded-xl text-left border text-xs font-medium transition-all cursor-pointer ${
                      versionInfo.mode === 'silent'
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-950 font-bold'
                        : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      <EyeOff className="w-3 h-3 text-emerald-600" />
                      <span>Silencieux</span>
                    </div>
                    <div className="text-[10px] text-stone-500 mt-0.5">Auto-recharge</div>
                  </button>
                </div>
              </div>

              {/* Frequency Interval */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-stone-600 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-stone-400" />
                  <span>Fréquence de vérification :</span>
                </label>
                <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-xl">
                  {[15, 30, 60].map((sec) => (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => setAutoUpdateInterval(sec)}
                      className={`flex-1 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        versionInfo.checkIntervalSeconds === sec
                          ? 'bg-white text-stone-900 shadow-2xs'
                          : 'text-stone-500 hover:text-stone-900'
                      }`}
                    >
                      {sec}s
                    </button>
                  ))}
                </div>
              </div>

              {/* Simulation test button */}
              <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => {
                    simulateNewVersion();
                    setIsSettingsOpen(false);
                  }}
                  className="w-full py-1.5 px-2.5 rounded-xl bg-stone-100 hover:bg-amber-100 text-stone-700 hover:text-amber-900 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-600" />
                  <span>Simuler une nouvelle version (Test)</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};
