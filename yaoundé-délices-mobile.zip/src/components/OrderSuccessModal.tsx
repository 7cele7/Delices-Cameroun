import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { CheckCircle2, Clock, MapPin, Send, ArrowRight, Utensils } from 'lucide-react';
import { Order, RestaurantConfig } from '../types';
import { formatFCFA } from '../utils/formatters';
import { openWhatsAppOrder } from '../utils/whatsapp';

interface OrderSuccessModalProps {
  order: Order | null;
  config: RestaurantConfig;
  onClose: () => void;
  onViewTracker: () => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  config,
  onClose,
  onViewTracker,
}) => {
  useEffect(() => {
    if (order) {
      // Fire celebratory confetti
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  }, [order]);

  if (!order) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div
        id="order-success-modal"
        className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-200 text-center space-y-5 relative"
      >
        {/* Success Icon */}
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        {/* Title */}
        <div>
          <span className="text-xs font-black uppercase tracking-widest text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">
            Commande confirmée !
          </span>
          <h2 className="font-display font-extrabold text-2xl text-stone-900 mt-2">
            Merci {order.customerName} !
          </h2>
          <p className="text-stone-500 text-xs mt-1">
            Votre commande a bien été enregistrée et est transmise à nos cuisiniers.
          </p>
        </div>

        {/* Receipt Box */}
        <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 text-left space-y-3 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-stone-200">
            <span className="text-stone-500">Numéro de Commande :</span>
            <span className="font-mono font-bold text-rose-600 text-sm">#{order.id}</span>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-stone-800">
              <Clock className="w-3.5 h-3.5 text-amber-500" />
              <span>Délai estimé : 30 à 45 minutes</span>
            </div>
            <div className="flex items-start gap-1.5 text-stone-600">
              <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
              <span>{order.neighborhood} • {order.landmark || order.manualAddress}</span>
            </div>
          </div>

          {/* Items summary */}
          <div className="pt-2 border-t border-stone-200 space-y-1">
            <div className="font-bold text-stone-700">Mets commandés :</div>
            {order.items.map((i, idx) => (
              <div key={idx} className="flex justify-between text-stone-600">
                <span className="truncate pr-2">
                  {i.quantity}x {i.item.name} {i.selectedPortion ? `(${i.selectedPortion.name})` : ''}
                </span>
                <span className="font-medium shrink-0">{formatFCFA(i.totalPrice || (i.item.price * i.quantity))}</span>
              </div>
            ))}
            <div className="pt-1.5 border-t border-stone-200 flex justify-between font-bold text-stone-900 text-sm">
              <span>Total :</span>
              <span className="text-rose-600 font-mono">{formatFCFA(order.total)}</span>
            </div>
          </div>

          {/* Payment Method reminder */}
          <div className="bg-amber-50 p-2.5 rounded-xl text-[11px] text-amber-900 border border-amber-200">
            <strong>Paiement choisi :</strong>{' '}
            {order.paymentMethod === 'momo'
              ? `MTN Mobile Money (${config.momoNumber}${config.momoName ? ` - ${config.momoName}` : ''})`
              : order.paymentMethod === 'om'
              ? `Orange Money (${config.omNumber}${config.omName ? ` - ${config.omName}` : ''})`
              : 'Espèces à la livraison'}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          <button
            id="btn-whatsapp-order-confirm"
            onClick={() => openWhatsAppOrder(order, config)}
            className="w-full bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Envoyer le récapitulatif sur WhatsApp</span>
          </button>

          <button
            id="btn-view-tracker"
            onClick={() => {
              onClose();
              onViewTracker();
            }}
            className="w-full bg-rose-600 hover:bg-rose-700 active:scale-95 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Utensils className="w-4 h-4" />
            <span>Suivre l’état de la commande</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onClose}
            className="w-full text-stone-400 hover:text-stone-700 py-1.5 text-xs font-medium cursor-pointer"
          >
            Retourner au menu
          </button>
        </div>
      </div>
    </div>
  );
};
