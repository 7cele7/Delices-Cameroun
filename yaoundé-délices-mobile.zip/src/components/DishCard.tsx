import React from 'react';
import { Plus, Clock, Sparkles, SlidersHorizontal, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { MenuItem } from '../types';
import { formatFCFA } from '../utils/formatters';

interface DishCardProps {
  dish: MenuItem;
  inCartCount?: number;
  onOpenDetail: (dish: MenuItem) => void;
  onQuickAdd?: (dish: MenuItem) => void;
}

export const DishCard: React.FC<DishCardProps> = ({
  dish,
  inCartCount = 0,
  onOpenDetail,
}) => {
  const isAvailable = dish.availability === 'disponible' || dish.availability === undefined;
  const isSoldOut = dish.availability === 'epuise';
  const isUnavailable = dish.availability === 'indisponible';

  // Calculate price display from portions
  const portions = dish.portions || [];
  const minPrice = portions.length > 0
    ? Math.min(...portions.map(p => p.price))
    : 2500;
  const maxPrice = portions.length > 0
    ? Math.max(...portions.map(p => p.price))
    : minPrice;

  const priceLabel = minPrice === maxPrice
    ? formatFCFA(minPrice)
    : `Dès ${formatFCFA(minPrice)}`;

  return (
    <div
      id={`dish-card-${dish.id}`}
      onClick={() => onOpenDetail(dish)}
      className={`group bg-white rounded-3xl border border-stone-200/80 hover:border-amber-400/80 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col overflow-hidden relative cursor-pointer ${
        !isAvailable ? 'opacity-70 grayscale-30' : ''
      }`}
    >
      {/* Image Container with Badges */}
      <div className="relative aspect-4/3 sm:aspect-16/10 w-full overflow-hidden bg-stone-100">
        <img
          src={dish.image}
          alt={dish.name}
          referrerPolicy="no-referrer"
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80';
          }}
        />

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-70 pointer-events-none" />

        {/* Badges top left */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {dish.badge && (
            <span className="bg-rose-600/95 backdrop-blur-xs text-white text-[10px] sm:text-xs font-bold px-2.5 py-0.5 rounded-lg shadow-xs flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-300" />
              {dish.badge}
            </span>
          )}
        </div>

        {/* In Cart Indicator */}
        {inCartCount > 0 && (
          <span className="absolute top-2.5 right-2.5 bg-rose-600 text-white font-black text-xs px-2 py-0.5 rounded-full shadow-md">
            {inCartCount} dans le panier
          </span>
        )}

        {/* Subcategory & Category pill */}
        <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1.5 flex-wrap">
          <span className="bg-black/65 backdrop-blur-md text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-md">
            {dish.category}
          </span>
          {dish.subcategory && (
            <span className="bg-white/85 text-stone-800 text-[10px] font-semibold px-2 py-0.5 rounded-md">
              {dish.subcategory}
            </span>
          )}
        </div>

        {/* Time estimate */}
        {dish.preparationTime && (
          <span className="absolute bottom-2.5 right-2.5 bg-white/90 text-stone-700 text-[10px] font-semibold px-1.5 py-0.5 rounded-md flex items-center gap-1">
            <Clock className="w-3 h-3 text-rose-500" />
            {dish.preparationTime}
          </span>
        )}

        {/* Sold out overlay */}
        {isSoldOut && (
          <div className="absolute inset-0 bg-stone-900/75 backdrop-blur-xs flex items-center justify-center">
            <span className="bg-red-600 text-white font-bold text-xs px-3 py-1 rounded-full border border-red-400 flex items-center gap-1 shadow-md">
              <AlertCircle className="w-3.5 h-3.5" /> Épuisé aujourd'hui
            </span>
          </div>
        )}
        {isUnavailable && (
          <div className="absolute inset-0 bg-stone-900/75 backdrop-blur-xs flex items-center justify-center">
            <span className="bg-stone-800 text-white font-bold text-xs px-3 py-1 rounded-full border border-stone-600 flex items-center gap-1">
              <XCircle className="w-3.5 h-3.5" /> Non disponible
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-3.5 sm:p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <h3 className="font-display font-bold text-stone-900 text-sm sm:text-base leading-snug line-clamp-1 group-hover:text-rose-600 transition-colors">
            {dish.name}
          </h3>
          <p className="text-stone-500 text-xs line-clamp-2 mt-1 leading-relaxed">
            {dish.description}
          </p>

          {/* Portions tags preview */}
          {portions.length > 1 && (
            <div className="flex items-center gap-1 mt-2 flex-wrap">
              <span className="text-[10px] text-stone-400 font-medium">Tailles :</span>
              {portions.map(p => (
                <span key={p.id} className="text-[10px] bg-stone-100 text-stone-600 px-1.5 py-0.2 rounded-md font-medium">
                  {p.name}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Price & Choose options button */}
        <div className="pt-2.5 border-t border-stone-100 flex items-center justify-between gap-2">
          <div>
            <div className="text-[10px] uppercase font-bold text-stone-400">Prix</div>
            <div className="font-display font-black text-stone-900 text-sm sm:text-base text-rose-600">
              {priceLabel}
            </div>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOpenDetail(dish);
            }}
            disabled={!isAvailable}
            className={`font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer ${
              isAvailable
                ? 'bg-amber-400 hover:bg-amber-500 text-stone-950 active:scale-95'
                : 'bg-stone-200 text-stone-400 cursor-not-allowed'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-stone-900" />
            <span>Choisir</span>
          </button>
        </div>
      </div>
    </div>
  );
};
