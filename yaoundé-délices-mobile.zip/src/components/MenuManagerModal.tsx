import React, { useState } from 'react';
import {
  X,
  Plus,
  Edit2,
  Trash2,
  Upload,
  Save,
  RotateCcw,
  Settings,
  Utensils,
  Check,
  Eye,
  EyeOff,
  FolderTree,
  AlertCircle,
  Clock,
  Sparkles
} from 'lucide-react';
import { MenuItem, RestaurantConfig, CategoryDef, PortionOption, ExtraAccompanimentOption, SupplementOption } from '../types';
import { formatFCFA } from '../utils/formatters';

interface MenuManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  menu: MenuItem[];
  categories: CategoryDef[];
  config: RestaurantConfig;
  onSaveMenu: (newMenu: MenuItem[]) => void;
  onSaveCategories: (newCategories: CategoryDef[]) => void;
  onSaveConfig: (newConfig: RestaurantConfig) => void;
  onResetMenu: () => void;
}

export const MenuManagerModal: React.FC<MenuManagerModalProps> = ({
  isOpen,
  onClose,
  menu,
  categories,
  config,
  onSaveMenu,
  onSaveCategories,
  onSaveConfig,
  onResetMenu,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'dishes' | 'categories' | 'settings'>('dishes');
  const [items, setItems] = useState<MenuItem[]>([...menu]);
  const [categoryList, setCategoryList] = useState<CategoryDef[]>([...categories]);
  const [editingDish, setEditingDish] = useState<MenuItem | null>(null);
  const [restaurantSettings, setRestaurantSettings] = useState<RestaurantConfig>({ ...config });
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Form fields for editing/creating a dish
  const [name, setName] = useState('');
  const [selectedCatName, setSelectedCatName] = useState('Légumes & Feuilles');
  const [selectedSubcatName, setSelectedSubcatName] = useState('Légumes traditionnels');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState('');
  const [badge, setBadge] = useState('');
  const [preparationTime, setPreparationTime] = useState('25-35 min');
  const [availability, setAvailability] = useState<'disponible' | 'indisponible' | 'epuise'>('disponible');

  // Portions state
  const [portions, setPortions] = useState<PortionOption[]>([
    { id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 pers.' }
  ]);

  // Accompaniments & Supplements strings for quick intuitive editing
  const [includedAccStr, setIncludedAccStr] = useState('Plantain vapeur, Bâton de manioc, Riz');
  const [extraAccStr, setExtraAccStr] = useState('Portion Plantains frits: 500, Bâton de manioc: 300');
  const [supplementsStr, setSupplementsStr] = useState('Poulet: 1500, Poisson: 2000, Viande: 1500, Œuf: 500');
  const [prepOptionsStr, setPrepOptionsStr] = useState('Sans sel ajouté, Piment à part');

  const openDishForm = (dish?: MenuItem) => {
    if (dish) {
      setEditingDish(dish);
      setName(dish.name);
      setSelectedCatName(dish.category);
      setSelectedSubcatName(dish.subcategory || '');
      setDescription(dish.description);
      setImage(dish.image);
      setBadge(dish.badge || '');
      setPreparationTime(dish.preparationTime || '25-35 min');
      setAvailability(dish.availability || 'disponible');
      setPortions(dish.portions && dish.portions.length > 0 ? dish.portions : [
        { id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 pers.' }
      ]);
      setIncludedAccStr(dish.includedAccompaniments ? dish.includedAccompaniments.join(', ') : '');
      setExtraAccStr(
        dish.extraAccompaniments
          ? dish.extraAccompaniments.map(e => `${e.name}: ${e.price}`).join(', ')
          : ''
      );
      setSupplementsStr(
        dish.supplements
          ? dish.supplements.map(s => `${s.name}: ${s.price}`).join(', ')
          : ''
      );
      setPrepOptionsStr(dish.preparationOptions ? dish.preparationOptions.join(', ') : '');
    } else {
      setEditingDish(null);
      setName('');
      setSelectedCatName(categoryList[0]?.name || 'Légumes & Feuilles');
      setSelectedSubcatName(categoryList[0]?.subcategories[0] || '');
      setDescription('');
      setImage('https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80');
      setBadge('');
      setPreparationTime('25-35 min');
      setAvailability('disponible');
      setPortions([
        { id: 'petite', name: 'Petite', price: 2500, servesInfo: '1 pers.' },
        { id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 pers.' },
        { id: 'grande', name: 'Grande', price: 5000, servesInfo: '2-3 pers.' },
        { id: 'familiale', name: 'Familiale', price: 8500, servesInfo: '4-6 pers.' },
      ]);
      setIncludedAccStr('Plantain vapeur, Bâton de manioc');
      setExtraAccStr('Portion Plantains frits: 500, Bâton de manioc: 300');
      setSupplementsStr('Poulet: 1500, Poisson: 2000, Viande: 1500, Œuf: 500, Sauce extra: 300');
      setPrepOptionsStr('Sans sel ajouté, Piment à part');
    }
  };

  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setImage(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Portions Helpers
  const addPortion = () => {
    const newId = `portion-${Date.now()}`;
    setPortions(prev => [...prev, { id: newId, name: 'Nouvelle portion', price: 4000, servesInfo: '1 pers.' }]);
  };

  const updatePortion = (idx: number, field: keyof PortionOption, val: any) => {
    setPortions(prev => {
      const copy = [...prev];
      copy[idx] = { ...copy[idx], [field]: val };
      return copy;
    });
  };

  const removePortion = (idx: number) => {
    if (portions.length <= 1) {
      alert('Un met doit avoir au moins une portion !');
      return;
    }
    setPortions(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSaveDish = () => {
    if (!name.trim()) {
      alert('Veuillez saisir un nom de plat.');
      return;
    }
    if (portions.length === 0) {
      alert('Veuillez définir au moins une portion avec son prix.');
      return;
    }

    // Parse included accompaniments
    const parsedIncluded = includedAccStr
      ? includedAccStr.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    // Parse extra accompaniments "Nom: Prix, ..."
    const parsedExtras: ExtraAccompanimentOption[] = extraAccStr
      ? extraAccStr.split(',').map((part, idx) => {
          const [n, p] = part.split(':');
          return {
            id: `extra-${idx}-${Date.now()}`,
            name: (n || '').trim(),
            price: Number((p || '0').replace(/\D/g, '')) || 500,
          };
        }).filter(e => e.name.length > 0)
      : [];

    // Parse supplements "Poulet: 1500, ..."
    const parsedSupplements: SupplementOption[] = supplementsStr
      ? supplementsStr.split(',').map((part, idx) => {
          const [n, p] = part.split(':');
          return {
            id: `sup-${idx}-${Date.now()}`,
            name: (n || '').trim(),
            price: Number((p || '0').replace(/\D/g, '')) || 1000,
          };
        }).filter(s => s.name.length > 0)
      : [];

    // Parse prep options
    const parsedPrep = prepOptionsStr
      ? prepOptionsStr.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    const newDish: MenuItem = {
      id: editingDish ? editingDish.id : `met-custom-${Date.now()}`,
      name: name.trim(),
      category: selectedCatName,
      subcategory: selectedSubcatName.trim() || undefined,
      description: description.trim(),
      image: image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
      badge: badge.trim() || undefined,
      preparationTime: preparationTime.trim() || undefined,
      availability,
      portions,
      includedAccompaniments: parsedIncluded.length > 0 ? parsedIncluded : undefined,
      extraAccompaniments: parsedExtras.length > 0 ? parsedExtras : undefined,
      supplements: parsedSupplements.length > 0 ? parsedSupplements : undefined,
      preparationOptions: parsedPrep.length > 0 ? parsedPrep : undefined,
      popular: editingDish?.popular || false,
    };

    let updatedList: MenuItem[];
    if (editingDish) {
      updatedList = items.map(d => (d.id === editingDish.id ? newDish : d));
    } else {
      updatedList = [newDish, ...items];
    }

    setItems(updatedList);
    onSaveMenu(updatedList);
    setEditingDish(null);
    setName('');
    showNotice('Met et portions enregistrés avec succès !');
  };

  const handleDeleteDish = (id: string) => {
    if (confirm('Voulez-vous vraiment supprimer ce plat du menu ?')) {
      const updated = items.filter(d => d.id !== id);
      setItems(updated);
      onSaveMenu(updated);
      showNotice('Met supprimé.');
    }
  };

  const handleToggleStock = (dish: MenuItem) => {
    const nextStatus = dish.availability === 'disponible' || !dish.availability
      ? 'epuise'
      : 'disponible';

    const updated = items.map(d => (d.id === dish.id ? { ...d, availability: nextStatus } : d));
    setItems(updated);
    onSaveMenu(updated);
  };

  const handleSaveSettings = () => {
    onSaveConfig(restaurantSettings);
    showNotice('Paramètres et numéros MoMo/OM enregistrés !');
  };

  const showNotice = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  // Find subcategories for currently chosen category in the dish form
  const currentCategoryDef = categoryList.find(c => c.name === selectedCatName);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div
        id="menu-manager-modal"
        className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-stone-200 flex flex-col"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50/80 sticky top-0 z-20">
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded-full">
              Espace Gérant & Administration
            </span>
            <h2 className="font-display font-black text-lg sm:text-xl text-stone-900 mt-1">
              Catalogue des Mets, Portions & Numéros
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 rounded-xl hover:bg-stone-200/60 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Alert */}
        {successMessage && (
          <div className="bg-emerald-600 text-white text-xs font-bold px-4 py-2 flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Tabs */}
        <div className="flex border-b border-stone-200 px-4 pt-2 bg-stone-50/50">
          <button
            onClick={() => {
              setActiveTab('dishes');
              setEditingDish(null);
            }}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'dishes'
                ? 'border-rose-600 text-rose-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Utensils className="w-4 h-4" />
            <span>Gestion des Mets ({items.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('categories')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'categories'
                ? 'border-rose-600 text-rose-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <FolderTree className="w-4 h-4" />
            <span>8 Catégories & Sous-catégories</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'border-rose-600 text-rose-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>MoMo, OM & Livraison</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-4 sm:p-6 flex-1 space-y-6">
          {/* TAB 1: DISHES */}
          {activeTab === 'dishes' && (
            <>
              {editingDish !== null || name !== '' ? (
                /* FORM ADD/EDIT DISH */
                <div className="bg-stone-50 rounded-2xl p-4 sm:p-5 border border-stone-200 space-y-4 text-xs">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-2">
                    <h3 className="font-bold text-stone-900 text-sm">
                      {editingDish ? `Modifier "${editingDish.name}"` : 'Créer un nouveau met'}
                    </h3>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingDish(null);
                        setName('');
                      }}
                      className="text-xs text-stone-500 hover:text-stone-800 underline cursor-pointer"
                    >
                      Fermer le formulaire
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Nom du met *</label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Ex: SANGA Traditionnel, Poisson Braisé..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Catégorie Principale *</label>
                      <select
                        value={selectedCatName}
                        onChange={(e) => {
                          setSelectedCatName(e.target.value);
                          const matched = categoryList.find(c => c.name === e.target.value);
                          if (matched && matched.subcategories.length > 0) {
                            setSelectedSubcatName(matched.subcategories[0]);
                          }
                        }}
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      >
                        {categoryList.map(cat => (
                          <option key={cat.id} value={cat.name}>
                            {cat.icon} {cat.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Sous-catégorie</label>
                      <input
                        type="text"
                        value={selectedSubcatName}
                        onChange={(e) => setSelectedSubcatName(e.target.value)}
                        placeholder="Ex: Légumes traditionnels, Feuilles sautées..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Disponibilité *</label>
                      <select
                        value={availability}
                        onChange={(e) => setAvailability(e.target.value as any)}
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      >
                        <option value="disponible">🟢 Disponible</option>
                        <option value="epuise">🔴 Épuisé (Aujourd'hui)</option>
                        <option value="indisponible">⚪ Indisponible</option>
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 mb-1">Description détaillée du met *</label>
                      <textarea
                        rows={2}
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Description des ingrédients, recette, épices, authenticité..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      />
                    </div>

                    {/* Image */}
                    <div className="sm:col-span-2 space-y-2">
                      <label className="block font-bold text-stone-700">Photo du met (Fichier ou URL) *</label>
                      <div className="flex items-center gap-3">
                        {image && (
                          <img
                            src={image}
                            alt="Aperçu"
                            className="w-16 h-16 rounded-xl object-cover border border-stone-300 shrink-0"
                          />
                        )}
                        <div className="flex-1 space-y-2">
                          <label className="inline-flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 px-3 py-1.5 rounded-xl font-bold cursor-pointer transition-colors text-xs">
                            <Upload className="w-3.5 h-3.5" />
                            <span>Charger une photo depuis ma galerie</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleImageFileUpload}
                              className="hidden"
                            />
                          </label>
                          <input
                            type="text"
                            value={image}
                            onChange={(e) => setImage(e.target.value)}
                            placeholder="Ou URL directe (https://...)"
                            className="w-full p-2 rounded-lg border border-stone-300 bg-white text-[11px]"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Portions Editor */}
                    <div className="sm:col-span-2 bg-white p-3.5 rounded-xl border border-stone-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="font-black text-stone-900 uppercase">
                          Tailles & Portions (Petite, Standard, Grande, Familiale) *
                        </label>
                        <button
                          type="button"
                          onClick={addPortion}
                          className="text-rose-600 hover:text-rose-700 font-bold text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" /> Ajouter une portion
                        </button>
                      </div>

                      <div className="space-y-2">
                        {portions.map((portion, idx) => (
                          <div key={portion.id || idx} className="flex items-center gap-2 bg-stone-50 p-2 rounded-xl">
                            <input
                              type="text"
                              value={portion.name}
                              onChange={(e) => updatePortion(idx, 'name', e.target.value)}
                              placeholder="Nom portion (ex: Petite, Standard)"
                              className="flex-1 p-1.5 rounded-lg border border-stone-300 bg-white text-xs font-bold"
                            />
                            <input
                              type="text"
                              value={portion.servesInfo || ''}
                              onChange={(e) => updatePortion(idx, 'servesInfo', e.target.value)}
                              placeholder="Pour (ex: 1-2 pers.)"
                              className="w-24 p-1.5 rounded-lg border border-stone-300 bg-white text-xs"
                            />
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                value={portion.price}
                                onChange={(e) => updatePortion(idx, 'price', Number(e.target.value))}
                                step="100"
                                placeholder="Prix FCFA"
                                className="w-24 p-1.5 rounded-lg border border-stone-300 bg-white text-xs font-bold text-rose-600"
                              />
                              <span className="text-[10px] text-stone-400">FCFA</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => removePortion(idx)}
                              className="text-stone-400 hover:text-red-500 p-1 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Accompagnements Inclus */}
                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 mb-1">
                        Accompagnements inclus (séparés par une virgule)
                      </label>
                      <input
                        type="text"
                        value={includedAccStr}
                        onChange={(e) => setIncludedAccStr(e.target.value)}
                        placeholder="Ex: Plantain vapeur, Bâton de manioc, Riz..."
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      />
                    </div>

                    {/* Accompagnements Supplémentaires Payants */}
                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 mb-1">
                        Accompagnements supplémentaires payants (Format: "Nom: Prix, Nom: Prix")
                      </label>
                      <input
                        type="text"
                        value={extraAccStr}
                        onChange={(e) => setExtraAccStr(e.target.value)}
                        placeholder="Ex: Portion Plantains frits: 500, Bâton de manioc: 300, Riz sauté: 700"
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      />
                    </div>

                    {/* Suppléments Payants */}
                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 mb-1">
                        Suppléments & Garnitures (Format: "Poulet: 1500, Poisson: 2000, Œuf: 500")
                      </label>
                      <input
                        type="text"
                        value={supplementsStr}
                        onChange={(e) => setSupplementsStr(e.target.value)}
                        placeholder="Ex: Poulet: 1500, Poisson: 2000, Viande: 1500, Œuf: 500, Sauce: 300"
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      />
                    </div>

                    {/* Options de préparation */}
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">
                        Options de préparation (séparées par virgule)
                      </label>
                      <input
                        type="text"
                        value={prepOptionsStr}
                        onChange={(e) => setPrepOptionsStr(e.target.value)}
                        placeholder="Ex: Sans sel ajouté, Piment à part, Bien épicé"
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      />
                    </div>

                    {/* Badge & Timing */}
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Badge spécial (optionnel)</label>
                      <input
                        type="text"
                        value={badge}
                        onChange={(e) => setBadge(e.target.value)}
                        placeholder="Ex: Recette Royale, Coup de cœur"
                        className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                      />
                    </div>
                  </div>

                  {/* Actions buttons */}
                  <div className="pt-3 border-t border-stone-200 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingDish(null);
                        setName('');
                      }}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 bg-stone-200 hover:bg-stone-300 cursor-pointer"
                    >
                      Annuler
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveDish}
                      className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 flex items-center gap-1.5 shadow-sm cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>Enregistrer le Met</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <p className="text-xs text-stone-500">
                    Gérez vos 15-20 mets avec leurs portions, photos et options.
                  </p>
                  <button
                    type="button"
                    onClick={() => openDishForm()}
                    className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Ajouter un met</span>
                  </button>
                </div>
              )}

              {/* Mets List */}
              <div className="divide-y divide-stone-100 border border-stone-200 rounded-2xl overflow-hidden">
                {items.map((dish) => {
                  const minPrice = dish.portions && dish.portions.length > 0
                    ? Math.min(...dish.portions.map(p => p.price))
                    : 3000;
                  const isAvailable = dish.availability === 'disponible' || !dish.availability;

                  return (
                    <div
                      key={dish.id}
                      className="p-3 bg-white hover:bg-amber-50/30 flex items-center justify-between gap-3 text-xs"
                    >
                      <img
                        src={dish.image}
                        alt={dish.name}
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 rounded-xl object-cover border border-stone-200 shrink-0"
                      />

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-stone-900 truncate">{dish.name}</span>
                          <span className="bg-stone-100 text-stone-600 px-1.5 py-0.2 rounded-md text-[10px]">
                            {dish.category}
                          </span>
                          {!isAvailable && (
                            <span className="bg-red-100 text-red-700 px-1.5 py-0.2 rounded-md text-[10px] font-bold">
                              {dish.availability === 'epuise' ? 'Épuisé' : 'Indisponible'}
                            </span>
                          )}
                        </div>
                        <div className="font-semibold text-rose-600">
                          {dish.portions && dish.portions.length > 1
                            ? `Dès ${formatFCFA(minPrice)} (${dish.portions.length} tailles)`
                            : formatFCFA(minPrice)}
                        </div>
                        <div className="text-[11px] text-stone-500 truncate">{dish.description}</div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleToggleStock(dish)}
                          title={isAvailable ? 'Marquer comme épuisé' : 'Marquer comme disponible'}
                          className={`p-1.5 rounded-lg border cursor-pointer ${
                            !isAvailable
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-stone-50 text-stone-600 border-stone-200'
                          }`}
                        >
                          {!isAvailable ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>

                        <button
                          type="button"
                          onClick={() => openDishForm(dish)}
                          className="p-1.5 bg-stone-100 hover:bg-rose-100 text-stone-700 hover:text-rose-700 rounded-lg transition-colors cursor-pointer"
                          title="Modifier"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteDish(dish.id)}
                          className="p-1.5 bg-stone-100 hover:bg-red-100 text-stone-400 hover:text-red-600 rounded-lg transition-colors cursor-pointer"
                          title="Supprimer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Reset to defaults button */}
              <div className="pt-2 flex justify-between items-center text-xs">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Voulez-vous restaurer le menu officiel avec les 15 mets camerounais préconfigurés ?')) {
                      onResetMenu();
                      showNotice('Catalogue réinitialisé.');
                    }
                  }}
                  className="text-stone-400 hover:text-stone-700 flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restaurer les 15 mets par défaut</span>
                </button>
              </div>
            </>
          )}

          {/* TAB 2: CATEGORIES */}
          {activeTab === 'categories' && (
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between">
                <p className="text-stone-500">
                  Les 8 catégories officielles et leurs sous-catégories associées.
                </p>
              </div>

              <div className="space-y-3">
                {categoryList.map((cat, catIdx) => (
                  <div key={cat.id} className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{cat.icon}</span>
                        <span className="font-bold text-stone-900 text-sm">{cat.name}</span>
                      </div>
                      <span className="text-stone-400 text-[11px]">
                        {items.filter(i => i.category === cat.name).length} mets
                      </span>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-stone-500 uppercase">
                        Sous-catégories (séparées par une virgule) :
                      </label>
                      <input
                        type="text"
                        value={cat.subcategories.join(', ')}
                        onChange={(e) => {
                          const updatedSubs = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                          const updatedCatList = [...categoryList];
                          updatedCatList[catIdx] = { ...cat, subcategories: updatedSubs };
                          setCategoryList(updatedCatList);
                        }}
                        className="w-full p-2 rounded-xl border border-stone-300 bg-white text-xs font-medium"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    onSaveCategories(categoryList);
                    showNotice('Catégories et sous-catégories enregistrées !');
                  }}
                  className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Enregistrer les catégories</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-4 text-xs">
              <p className="text-stone-500">
                Coordonnées du restaurant, numéros MTN MoMo / Orange Money et tarifs de livraison.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Nom de l'enseigne</label>
                  <input
                    type="text"
                    value={restaurantSettings.restaurantName}
                    onChange={(e) =>
                      setRestaurantSettings({ ...restaurantSettings, restaurantName: e.target.value })
                    }
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Numéro MTN Mobile Money</label>
                  <input
                    type="text"
                    value={restaurantSettings.momoNumber}
                    onChange={(e) =>
                      setRestaurantSettings({ ...restaurantSettings, momoNumber: e.target.value })
                    }
                    placeholder="Ex: 6 70 00 00 00"
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Titulaire MTN MoMo</label>
                  <input
                    type="text"
                    value={restaurantSettings.momoName}
                    onChange={(e) =>
                      setRestaurantSettings({ ...restaurantSettings, momoName: e.target.value })
                    }
                    placeholder="Ex: YAOUNDÉ DÉLICES"
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Numéro Orange Money</label>
                  <input
                    type="text"
                    value={restaurantSettings.omNumber}
                    onChange={(e) =>
                      setRestaurantSettings({ ...restaurantSettings, omNumber: e.target.value })
                    }
                    placeholder="Ex: 6 90 00 00 00"
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Titulaire Orange Money</label>
                  <input
                    type="text"
                    value={restaurantSettings.omName || ''}
                    onChange={(e) =>
                      setRestaurantSettings({ ...restaurantSettings, omName: e.target.value })
                    }
                    placeholder="Ex: YAOUNDÉ DÉLICES"
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Numéro WhatsApp (sans le +)</label>
                  <input
                    type="text"
                    value={restaurantSettings.phoneWhatsApp}
                    onChange={(e) =>
                      setRestaurantSettings({ ...restaurantSettings, phoneWhatsApp: e.target.value })
                    }
                    placeholder="Ex: 237670000000"
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Seuil Livraison Gratuite (FCFA)</label>
                  <input
                    type="number"
                    value={restaurantSettings.freeDeliveryThreshold}
                    onChange={(e) =>
                      setRestaurantSettings({
                        ...restaurantSettings,
                        freeDeliveryThreshold: Number(e.target.value),
                      })
                    }
                    step="500"
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Frais de livraison standard (FCFA)</label>
                  <input
                    type="number"
                    value={restaurantSettings.standardDeliveryFee}
                    onChange={(e) =>
                      setRestaurantSettings({
                        ...restaurantSettings,
                        standardDeliveryFee: Number(e.target.value),
                      })
                    }
                    step="100"
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Horaires de service</label>
                  <div className="flex gap-2">
                    <input
                      type="time"
                      value={restaurantSettings.openingTime}
                      onChange={(e) =>
                        setRestaurantSettings({ ...restaurantSettings, openingTime: e.target.value })
                      }
                      className="w-full p-2 rounded-xl border border-stone-300 bg-white"
                    />
                    <span className="self-center font-bold text-stone-400">à</span>
                    <input
                      type="time"
                      value={restaurantSettings.closingTime}
                      onChange={(e) =>
                        setRestaurantSettings({ ...restaurantSettings, closingTime: e.target.value })
                      }
                      className="w-full p-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Jours d'ouverture</label>
                  <input
                    type="text"
                    value={restaurantSettings.workingDays}
                    onChange={(e) =>
                      setRestaurantSettings({ ...restaurantSettings, workingDays: e.target.value })
                    }
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end">
                <button
                  type="button"
                  onClick={handleSaveSettings}
                  className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-rose-600/20 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Enregistrer les paramètres</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
