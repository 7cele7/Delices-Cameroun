import React, { useState, useMemo } from 'react';
import { X, Plus, Minus, ShoppingBag, Clock, Sparkles, Check, Flame, AlertCircle } from 'lucide-react';
import { MenuItem, PortionOption, ExtraAccompanimentOption, SupplementOption, CartItem } from '../types';
import { formatFCFA } from '../utils/formatters';

interface DishDetailModalProps {
  dish: MenuItem | null;
  onClose: () => void;
  onAddToCartCustom: (cartItem: CartItem) => void;
}

export const DishDetailModal: React.FC<DishDetailModalProps> = ({
  dish,
  onClose,
  onAddToCartCustom,
}) => {
  if (!dish) return null;

  // Find default portion (prefer Standard, otherwise first available)
  const defaultPortion = useMemo(() => {
    if (!dish.portions || dish.portions.length === 0) {
      return { id: 'standard', name: 'Standard', price: 3000, servesInfo: '1-2 personnes' };
    }
    const std = dish.portions.find(p => p.id === 'standard' || p.name.toLowerCase().includes('standard'));
    return std || dish.portions[0];
  }, [dish]);

  const [selectedPortion, setSelectedPortion] = useState<PortionOption>(defaultPortion);
  const [selectedAccompaniment, setSelectedAccompaniment] = useState<string>(
    dish.includedAccompaniments && dish.includedAccompaniments.length > 0
      ? dish.includedAccompaniments[0]
      : ''
  );
  const [selectedExtraAccompaniments, setSelectedExtraAccompaniments] = useState<ExtraAccompanimentOption[]>([]);
  const [selectedSupplements, setSelectedSupplements] = useState<SupplementOption[]>([]);
  const [selectedPreparationOptions, setSelectedPreparationOptions] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [quantity, setQuantity] = useState(1);

  // Toggle Extra Accompaniment
  const toggleExtraAcc = (extra: ExtraAccompanimentOption) => {
    setSelectedExtraAccompaniments(prev => {
      const exists = prev.some(e => e.id === extra.id);
      if (exists) return prev.filter(e => e.id !== extra.id);
      return [...prev, extra];
    });
  };

  // Toggle Supplement
  const toggleSupplement = (sup: SupplementOption) => {
    setSelectedSupplements(prev => {
      const exists = prev.some(s => s.id === sup.id);
      if (exists) return prev.filter(s => s.id !== sup.id);
      return [...prev, sup];
    });
  };

  // Toggle Preparation Option
  const togglePrepOption = (opt: string) => {
    setSelectedPreparationOptions(prev => {
      if (prev.includes(opt)) return prev.filter(o => o !== opt);
      return [...prev, opt];
    });
  };

  // Calculation
  const portionPrice = selectedPortion?.price || 0;
  const extraAccPrice = selectedExtraAccompaniments.reduce((sum, item) => sum + item.price, 0);
  const supplementsPrice = selectedSupplements.reduce((sum, item) => sum + item.price, 0);
  const unitPrice = portionPrice + extraAccPrice + supplementsPrice;
  const totalPrice = unitPrice * quantity;

  const isAvailable = dish.availability === 'disponible' || dish.availability === undefined;

  const handleAdd = () => {
    if (!isAvailable) return;

    const uniqueId = `${dish.id}-${selectedPortion.id}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newCartItem: CartItem = {
      id: uniqueId,
      item: dish,
      quantity,
      selectedPortion,
      selectedAccompaniment: selectedAccompaniment || undefined,
      selectedExtraAccompaniments,
      selectedSupplements,
      selectedPreparationOptions,
      notes: notes.trim() || undefined,
      unitPrice,
      totalPrice,
    };

    onAddToCartCustom(newCartItem);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/75 backdrop-blur-xs animate-fade-in">
      <div
        id="dish-detail-modal"
        className="bg-white rounded-3xl max-w-xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-stone-200 flex flex-col relative"
      >
        {/* Close Button */}
        <button
          id="btn-close-dish-modal"
          onClick={onClose}
          className="absolute top-3.5 right-3.5 z-20 w-9 h-9 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Image & Head Info */}
        <div className="relative aspect-16/9 w-full bg-stone-100 shrink-0 overflow-hidden">
          <img
            src={dish.image}
            alt={dish.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

          {/* Badges top left */}
          <div className="absolute top-3.5 left-3.5 flex flex-wrap gap-1.5 z-10">
            <span className="bg-amber-500 text-stone-900 text-xs font-black px-2.5 py-1 rounded-xl shadow-xs flex items-center gap-1">
              <span>{dish.category}</span>
            </span>
            {dish.subcategory && (
              <span className="bg-white/90 text-stone-800 text-xs font-bold px-2.5 py-1 rounded-xl shadow-xs">
                {dish.subcategory}
              </span>
            )}
            {dish.badge && (
              <span className="bg-rose-600 text-white text-xs font-bold px-2.5 py-1 rounded-xl shadow-xs flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                {dish.badge}
              </span>
            )}
          </div>

          {/* Title & Availability on bottom of image */}
          <div className="absolute bottom-3 left-4 right-4 text-white">
            <h2 className="font-display font-black text-xl sm:text-2xl drop-shadow-sm">
              {dish.name}
            </h2>
            <div className="flex items-center gap-2 mt-1">
              {dish.preparationTime && (
                <span className="text-[11px] text-amber-200 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> {dish.preparationTime}
                </span>
              )}
              {dish.availability === 'epuise' && (
                <span className="text-[10px] bg-red-600 font-bold px-2 py-0.5 rounded-full text-white">
                  Épuisé aujourd'hui
                </span>
              )}
              {dish.availability === 'indisponible' && (
                <span className="text-[10px] bg-stone-600 font-bold px-2 py-0.5 rounded-full text-white">
                  Non disponible
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-5">
          {/* Description */}
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
            {dish.description}
          </p>

          {/* 1. PORTIONS (MANDATORY SELECTION) */}
          <div className="space-y-2 pt-2 border-t border-stone-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-600"></span>
                1. Choisissez la Portion <span className="text-rose-600 font-bold">*</span>
              </label>
              <span className="text-[11px] text-stone-500 font-medium">
                {selectedPortion.servesInfo || ''}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {dish.portions && dish.portions.map((portion) => {
                const isSelected = selectedPortion.id === portion.id;
                return (
                  <button
                    key={portion.id}
                    type="button"
                    onClick={() => setSelectedPortion(portion)}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'border-rose-600 bg-rose-50/90 ring-2 ring-rose-500/30 text-rose-950 font-bold shadow-xs'
                        : 'border-stone-200 hover:border-stone-300 bg-stone-50/60 hover:bg-stone-50 text-stone-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs">{portion.name}</span>
                      {isSelected && (
                        <div className="w-4 h-4 rounded-full bg-rose-600 text-white flex items-center justify-center">
                          <Check className="w-2.5 h-2.5" />
                        </div>
                      )}
                    </div>
                    {portion.servesInfo && (
                      <div className="text-[10px] text-stone-500 font-normal mt-0.5">
                        {portion.servesInfo}
                      </div>
                    )}
                    <div className="font-mono text-xs font-black text-stone-900 mt-2">
                      {formatFCFA(portion.price)}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. ACCOMPAGNEMENT INCLUS */}
          {dish.includedAccompaniments && dish.includedAccompaniments.length > 0 && (
            <div className="space-y-2 pt-3 border-t border-stone-100">
              <label className="text-xs font-black text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                2. Accompagnement inclus (Choisir un)
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {dish.includedAccompaniments.map((acc) => {
                  const isSelected = selectedAccompaniment === acc;
                  return (
                    <button
                      key={acc}
                      type="button"
                      onClick={() => setSelectedAccompaniment(acc)}
                      className={`flex items-center justify-between p-2.5 rounded-xl border text-xs transition-all text-left cursor-pointer ${
                        isSelected
                          ? 'border-amber-500 bg-amber-50/90 text-amber-950 font-bold ring-2 ring-amber-500/30'
                          : 'border-stone-200 hover:bg-stone-50 text-stone-700 font-medium'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>🍚</span>
                        <span>{acc}</span>
                      </span>
                      {isSelected ? (
                        <div className="w-4 h-4 rounded-full bg-amber-500 text-stone-900 flex items-center justify-center">
                          <Check className="w-3 h-3" />
                        </div>
                      ) : (
                        <span className="text-[10px] text-stone-400">Inclus</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 3. ACCOMPAGNEMENTS SUPPLÉMENTAIRES PAYANTS */}
          {dish.extraAccompaniments && dish.extraAccompaniments.length > 0 && (
            <div className="space-y-2 pt-3 border-t border-stone-100">
              <label className="text-xs font-black text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-stone-400"></span>
                3. Accompagnements supplémentaires (Optionnels)
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {dish.extraAccompaniments.map((extra) => {
                  const isSelected = selectedExtraAccompaniments.some(e => e.id === extra.id);
                  return (
                    <button
                      key={extra.id}
                      type="button"
                      onClick={() => toggleExtraAcc(extra)}
                      className={`flex items-center justify-between p-2.5 rounded-xl border text-xs transition-all text-left cursor-pointer ${
                        isSelected
                          ? 'border-stone-800 bg-stone-900 text-white font-bold'
                          : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                      }`}
                    >
                      <span>{extra.name}</span>
                      <span className={`text-[11px] font-mono font-bold ${isSelected ? 'text-amber-300' : 'text-stone-900'}`}>
                        +{formatFCFA(extra.price)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 4. SUPPLÉMENTS (POULET, POISSON, VIANDE, ŒUF, SAUCE) */}
          {dish.supplements && dish.supplements.length > 0 && (
            <div className="space-y-2 pt-3 border-t border-stone-100">
              <label className="text-xs font-black text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                4. Suppléments & Extras (Garnitures riches)
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {dish.supplements.map((sup) => {
                  const isSelected = selectedSupplements.some(s => s.id === sup.id);
                  return (
                    <button
                      key={sup.id}
                      type="button"
                      onClick={() => toggleSupplement(sup)}
                      className={`flex items-center justify-between p-2.5 rounded-xl border text-xs transition-all text-left cursor-pointer ${
                        isSelected
                          ? 'border-rose-600 bg-rose-50 text-rose-950 font-bold ring-2 ring-rose-500/30'
                          : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <div className={`w-4 h-4 rounded-md flex items-center justify-center border ${
                          isSelected ? 'bg-rose-600 border-rose-600 text-white' : 'border-stone-300 bg-white'
                        }`}>
                          {isSelected && <Check className="w-3 h-3" />}
                        </div>
                        <span>{sup.name}</span>
                      </div>
                      <span className="font-mono text-xs font-bold text-rose-600">
                        +{formatFCFA(sup.price)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 5. OPTIONS DE PRÉPARATION (Ex: Sans sel ajouté, Piment à part) */}
          {dish.preparationOptions && dish.preparationOptions.length > 0 && (
            <div className="space-y-2 pt-3 border-t border-stone-100">
              <label className="text-xs font-black text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                5. Préférences de préparation
              </label>

              <div className="flex flex-wrap gap-2">
                {dish.preparationOptions.map((opt) => {
                  const isSelected = selectedPreparationOptions.includes(opt);
                  return (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => togglePrepOption(opt)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                          : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                      }`}
                    >
                      {isSelected ? <Check className="w-3.5 h-3.5" /> : null}
                      <span>{opt}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 6. NOTE SPÉCIALE */}
          <div className="space-y-1.5 pt-3 border-t border-stone-100">
            <label htmlFor="modal-dish-notes" className="text-xs font-bold text-stone-700 block">
              Instructions spécifiques pour la cuisine :
            </label>
            <input
              id="modal-dish-notes"
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Piment bien séparé, viande bien cuite..."
              className="w-full text-xs p-2.5 rounded-xl border border-stone-200 focus:outline-hidden focus:border-rose-500 bg-stone-50/50"
            />
          </div>

          {/* Summary & Order action bar */}
          <div className="pt-4 border-t border-stone-200 bg-stone-50 -mx-4 -mb-4 sm:-mx-6 sm:-mb-6 p-4 sm:p-6 rounded-b-3xl space-y-3">
            {/* Price breakdown pill */}
            <div className="flex items-center justify-between text-xs text-stone-600">
              <span>Portion ({selectedPortion.name}) : <strong>{formatFCFA(portionPrice)}</strong></span>
              {(extraAccPrice > 0 || supplementsPrice > 0) && (
                <span>Extras & Suppléments : <strong>+{formatFCFA(extraAccPrice + supplementsPrice)}</strong></span>
              )}
            </div>

            <div className="flex items-center gap-3">
              {/* Quantity Selector */}
              <div className="flex items-center gap-2 bg-white border border-stone-200 p-1 rounded-2xl shadow-2xs">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center font-bold hover:bg-stone-200 transition-colors cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-7 text-center font-extrabold text-sm text-stone-900">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold hover:bg-rose-700 transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {/* Submit Button */}
              <button
                id="btn-confirm-add-to-cart-structured"
                onClick={handleAdd}
                disabled={!isAvailable}
                className={`flex-1 font-bold py-3.5 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-sm transition-all cursor-pointer ${
                  isAvailable
                    ? 'bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-700 hover:to-rose-600 text-white shadow-rose-600/25 active:scale-98'
                    : 'bg-stone-300 text-stone-500 cursor-not-allowed'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>
                  {isAvailable ? `Ajouter au Panier • ${formatFCFA(totalPrice)}` : 'Non disponible'}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
