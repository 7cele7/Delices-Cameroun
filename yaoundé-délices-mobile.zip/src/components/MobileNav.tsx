import React from 'react';
import { Home, Utensils, ShoppingBag, Clock, Phone } from 'lucide-react';
import { formatFCFA } from '../utils/formatters';

interface MobileNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  cartTotal,
  onOpenCart,
}) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-stone-200 shadow-2xl px-2 py-1.5 flex items-center justify-around">
      <button
        id="mobile-nav-accueil"
        onClick={() => setActiveTab('accueil')}
        className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all ${
          activeTab === 'accueil' ? 'text-rose-600 font-bold scale-105' : 'text-stone-500'
        }`}
      >
        <Home className="w-5 h-5" />
        <span className="text-[10px]">Accueil</span>
      </button>

      <button
        id="mobile-nav-menu"
        onClick={() => setActiveTab('menu')}
        className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all ${
          activeTab === 'menu' ? 'text-rose-600 font-bold scale-105' : 'text-stone-500'
        }`}
      >
        <Utensils className="w-5 h-5" />
        <span className="text-[10px]">La Carte</span>
      </button>

      {/* Floating Center Cart */}
      <button
        id="mobile-nav-cart"
        onClick={onOpenCart}
        className="relative -top-4 flex flex-col items-center"
      >
        <div className="w-13 h-13 rounded-full bg-gradient-to-tr from-rose-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/30 border-3 border-white active:scale-95 transition-transform">
          <ShoppingBag className="w-6 h-6" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-amber-400 text-stone-900 font-black text-[11px] rounded-full h-5 w-5 flex items-center justify-center border-2 border-white">
              {cartCount}
            </span>
          )}
        </div>
        <span className="text-[10px] font-bold text-stone-800 mt-0.5">
          {cartCount > 0 ? formatFCFA(cartTotal) : 'Panier'}
        </span>
      </button>

      <button
        id="mobile-nav-commandes"
        onClick={() => setActiveTab('commandes')}
        className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all ${
          activeTab === 'commandes' ? 'text-rose-600 font-bold scale-105' : 'text-stone-500'
        }`}
      >
        <Clock className="w-5 h-5" />
        <span className="text-[10px]">Suivi</span>
      </button>

      <button
        id="mobile-nav-contact"
        onClick={() => setActiveTab('contact')}
        className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all ${
          activeTab === 'contact' ? 'text-rose-600 font-bold scale-105' : 'text-stone-500'
        }`}
      >
        <Phone className="w-5 h-5" />
        <span className="text-[10px]">Contact</span>
      </button>
    </div>
  );
};
