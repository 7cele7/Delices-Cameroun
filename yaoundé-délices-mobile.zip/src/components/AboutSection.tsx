import React from 'react';
import { Heart, Sparkles, Flame, Award, ShieldCheck, Truck } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <span className="text-xs font-bold uppercase tracking-widest text-rose-600 bg-rose-50 px-3 py-1 rounded-full">
          Notre Histoire
        </span>
        <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-stone-900">
          Yaoundé Délices : L'art culinaire du terroir camerounais
        </h1>
        <p className="text-stone-500 text-xs sm:text-sm max-w-xl mx-auto">
          De la sélection matinale des épices aux Marchés du Mfoundi et de Mokolo jusqu’à la livraison fumante chez vous.
        </p>
      </div>

      {/* Main Story Hero */}
      <div className="bg-white rounded-3xl overflow-hidden border border-stone-200 shadow-xs grid grid-cols-1 md:grid-cols-2">
        <div className="p-6 sm:p-8 flex flex-col justify-center space-y-4">
          <h2 className="font-display font-bold text-xl text-stone-900 leading-tight">
            Une passion pour les saveurs authentiques de nos 10 régions
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
            Fondée au cœur de Yaoundé, <strong>Yaoundé Délices</strong> est née d'une vision simple : permettre à tous les Yaoundéens, qu’ils soient au bureau à Bastos, en famille à Biyem-Assi ou de passage à Nlongkak, de savourer les meilleurs plats traditionnels et grillades avec la rapidité d'un clic.
          </p>
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
            Chaque plat est mijoté à la commande, avec des poissons frais sélectionnés quotidiennement et des épices traditionnelles du pays (djansang, pébè, rondelles, kankankan) qui font la fierté de notre gastronomie.
          </p>
        </div>

        <div className="relative aspect-4/3 md:aspect-auto">
          <img
            src="https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80"
            alt="Grillade Yaoundé Délices"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-white via-transparent to-transparent md:w-16" />
        </div>
      </div>

      {/* Guarantees 4 Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 text-center space-y-2">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
            <Flame className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-stone-900 text-sm">Cuisson au feu de bois</h3>
          <p className="text-stone-500 text-xs">Grillades braisées minute avec les arômes fumés incomparables.</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 text-center space-y-2">
          <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
            <Heart className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-stone-900 text-sm">Ingrédients 100% Frais</h3>
          <p className="text-stone-500 text-xs">Légumes, plantains mûrs et viandes locales sans conservateurs.</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 text-center space-y-2">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-stone-900 text-sm">Hygiène Garantie</h3>
          <p className="text-stone-500 text-xs">Emballages thermiques hermétiques pour garder les plats très chauds.</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 text-center space-y-2">
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto">
            <Truck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-stone-900 text-sm">Livraison à domicile</h3>
          <p className="text-stone-500 text-xs">Livreurs dédiés couvrant tous les quartiers de Yaoundé.</p>
        </div>
      </div>
    </div>
  );
};
