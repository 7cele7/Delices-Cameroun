import React, { useState } from 'react';
import {
  X,
  Trash2,
  Plus,
  Minus,
  MapPin,
  Compass,
  CheckCircle,
  AlertCircle,
  Phone,
  User,
  CreditCard,
  Banknote,
  Send,
  Sparkles,
  ExternalLink,
  Copy,
  Check,
  Loader2,
  UtensilsCrossed
} from 'lucide-react';
import { CartItem, Order, RestaurantConfig, GPSLocation } from '../types';
import { formatFCFA, generateOrderId } from '../utils/formatters';
import { getCurrentGPSPosition } from '../utils/geolocation';
import { openWhatsAppOrder } from '../utils/whatsapp';
import { saveCustomerInfo } from '../utils/storage';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  config: RestaurantConfig;
  savedCustomer: { name: string; phone: string; neighborhood: string; landmark: string };
  onUpdateQuantity: (cartItemId: string, delta: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  config,
  savedCustomer,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOrderSuccess,
}) => {
  if (!isOpen) return null;

  // Form State
  const [customerName, setCustomerName] = useState(savedCustomer.name || '');
  const [customerPhone, setCustomerPhone] = useState(savedCustomer.phone || '');
  const [neighborhood, setNeighborhood] = useState(savedCustomer.neighborhood || 'Bastos');
  const [customNeighborhood, setCustomNeighborhood] = useState('');
  const [landmark, setLandmark] = useState(savedCustomer.landmark || '');
  const [specialInstructions, setSpecialInstructions] = useState('');
  // Payment Method Selection based on config
  const isCashActive = config.cashEnabled !== false;
  const isMomoActive = config.momoEnabled !== false;
  const isOmActive = config.omEnabled !== false;
  const customMethods = (config.customPaymentMethods || []).filter(m => m.enabled);

  const initialPaymentMethod = (): 'cash' | 'momo' | 'om' => {
    if (isCashActive) return 'cash';
    if (isMomoActive) return 'momo';
    if (isOmActive) return 'om';
    return 'cash';
  };

  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'momo' | 'om'>(initialPaymentMethod);

  // GPS State
  const [gpsLocation, setGpsLocation] = useState<GPSLocation | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  // MoMo & OM Copy State
  const [copiedMomo, setCopiedMomo] = useState(false);
  const [copiedOm, setCopiedOm] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Financial calculations
  const subtotal = items.reduce((acc, item) => acc + item.totalPrice, 0);
  const isFreeDelivery = subtotal >= config.freeDeliveryThreshold;
  const deliveryFee = items.length === 0 ? 0 : (isFreeDelivery ? 0 : config.standardDeliveryFee);
  const total = subtotal + deliveryFee;
  const missingForFree = Math.max(0, config.freeDeliveryThreshold - subtotal);
  const freeDeliveryProgress = Math.min(100, Math.round((subtotal / config.freeDeliveryThreshold) * 100));

  // Geolocation Handler
  const handleGetLocation = async () => {
    setIsLocating(true);
    setGpsError(null);
    try {
      const pos = await getCurrentGPSPosition();
      setGpsLocation(pos);
      if (pos.neighborhood) {
        setNeighborhood(pos.neighborhood);
      }
    } catch (err: any) {
      setGpsError(err.message || 'Impossible d’obtenir la localisation.');
    } finally {
      setIsLocating(false);
    }
  };

  const handleCopyMomo = () => {
    navigator.clipboard.writeText(config.momoNumber);
    setCopiedMomo(true);
    setTimeout(() => setCopiedMomo(false), 2500);
  };

  const handleCopyOm = () => {
    navigator.clipboard.writeText(config.omNumber);
    setCopiedOm(true);
    setTimeout(() => setCopiedOm(false), 2500);
  };

  const validateAndBuildOrder = (): Order | null => {
    if (items.length === 0) {
      setFormError('Votre panier est vide.');
      return null;
    }
    if (!customerName.trim()) {
      setFormError('Veuillez renseigner votre nom complet.');
      return null;
    }
    if (!customerPhone.trim() || customerPhone.replace(/\D/g, '').length < 8) {
      setFormError('Veuillez entrer un numéro de téléphone valide (ex: 6XX XX XX XX).');
      return null;
    }

    const finalNeighborhood = neighborhood === 'Autre' ? (customNeighborhood || 'Yaoundé') : neighborhood;

    setFormError(null);

    // Save for next orders
    saveCustomerInfo({
      name: customerName,
      phone: customerPhone,
      neighborhood: finalNeighborhood,
      landmark,
    });

    const newOrder: Order = {
      id: generateOrderId(),
      createdAt: new Date().toISOString(),
      items: [...items],
      subtotal,
      deliveryFee,
      total,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      neighborhood: finalNeighborhood,
      manualAddress: `${finalNeighborhood}${landmark ? ` - ${landmark}` : ''}`,
      landmark: landmark.trim(),
      gpsLocation: gpsLocation || undefined,
      specialInstructions: specialInstructions.trim(),
      paymentMethod,
      status: 'received',
    };

    return newOrder;
  };

  // Submit via WhatsApp
  const handleWhatsAppCheckout = () => {
    const order = validateAndBuildOrder();
    if (!order) return;

    openWhatsAppOrder(order, config);
    onOrderSuccess(order);
    onClearCart();
  };

  // Submit Direct In-App
  const handleDirectCheckout = () => {
    const order = validateAndBuildOrder();
    if (!order) return;

    onOrderSuccess(order);
    onClearCart();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-900/60 backdrop-blur-xs flex justify-end animate-fade-in">
      <div
        id="cart-drawer-panel"
        className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto animate-slide-left"
      >
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50/80 sticky top-0 z-20">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold text-sm">
              {items.reduce((acc, i) => acc + i.quantity, 0)}
            </div>
            <div>
              <h2 className="font-display font-black text-stone-900 text-base sm:text-lg leading-tight">
                Votre Panier de Commande
              </h2>
              <p className="text-[11px] text-stone-500">
                {items.length} met{items.length > 1 ? 's' : ''} sélectionné{items.length > 1 ? 's' : ''}
              </p>
            </div>
          </div>
          <button
            id="btn-close-cart"
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 rounded-xl hover:bg-stone-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Delivery Bar */}
        {items.length > 0 && (
          <div className="bg-amber-50/90 px-4 py-2.5 border-b border-amber-200/70 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800 mb-1">
              <span className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                {isFreeDelivery
                  ? '🎉 Livraison GRATUITE activée !'
                  : `Plus que ${formatFCFA(missingForFree)} pour la livraison GRATUITE !`}
              </span>
              <span className="text-stone-500 font-normal">Palier : {formatFCFA(config.freeDeliveryThreshold)}</span>
            </div>
            <div className="w-full h-2 bg-amber-200/60 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-rose-500 rounded-full transition-all duration-500"
                style={{ width: `${freeDeliveryProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Content Body */}
        <div className="p-4 space-y-6 flex-1">
          {items.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
                <UtensilsCrossed className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-stone-800 text-base">Votre panier est vide</h3>
              <p className="text-stone-500 text-xs max-w-xs mx-auto">
                Choisissez vos mets préférés parmi nos 8 catégories de délices camerounais.
              </p>
              <button
                onClick={onClose}
                className="mt-2 bg-rose-600 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-xs hover:bg-rose-700 cursor-pointer"
              >
                Explorer le menu
              </button>
            </div>
          ) : (
            <>
              {/* Items List */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-xs font-bold text-stone-500 uppercase tracking-wider">
                  <span>Mets commandés</span>
                  <button
                    onClick={onClearCart}
                    className="text-stone-400 hover:text-red-500 flex items-center gap-1 font-normal lowercase text-[11px] cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" /> Vider
                  </button>
                </div>

                <div className="divide-y divide-stone-100 border border-stone-200 rounded-2xl overflow-hidden bg-stone-50/40">
                  {items.map((cartItem) => (
                    <div key={cartItem.id} className="p-3 bg-white space-y-2">
                      <div className="flex items-start justify-between gap-2.5">
                        <img
                          src={cartItem.item.image}
                          alt={cartItem.item.name}
                          referrerPolicy="no-referrer"
                          className="w-14 h-14 rounded-xl object-cover shrink-0 border border-stone-100 mt-0.5"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-baseline justify-between gap-1">
                            <h4 className="font-bold text-stone-900 text-xs truncate">
                              {cartItem.item.name}
                            </h4>
                            <span className="font-mono text-xs font-bold text-rose-600 shrink-0">
                              {formatFCFA(cartItem.totalPrice)}
                            </span>
                          </div>

                          {/* Portion Badge */}
                          <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                            {cartItem.selectedPortion && (
                              <span className="text-[10px] bg-rose-50 text-rose-700 font-bold px-2 py-0.5 rounded-md border border-rose-100">
                                Taille : {cartItem.selectedPortion.name} ({formatFCFA(cartItem.selectedPortion.price)})
                              </span>
                            )}
                            {cartItem.selectedAccompaniment && (
                              <span className="text-[10px] bg-amber-50 text-amber-800 font-medium px-1.5 py-0.5 rounded-md border border-amber-200">
                                🍚 {cartItem.selectedAccompaniment}
                              </span>
                            )}
                          </div>

                          {/* Extra Accompaniments */}
                          {cartItem.selectedExtraAccompaniments && cartItem.selectedExtraAccompaniments.length > 0 && (
                            <div className="text-[10px] text-stone-600 mt-1">
                              <strong>Extra :</strong> {cartItem.selectedExtraAccompaniments.map(e => `${e.name} (+${formatFCFA(e.price)})`).join(', ')}
                            </div>
                          )}

                          {/* Supplements */}
                          {cartItem.selectedSupplements && cartItem.selectedSupplements.length > 0 && (
                            <div className="text-[10px] text-rose-700 mt-0.5">
                              <strong>Suppléments :</strong> {cartItem.selectedSupplements.map(s => `${s.name} (+${formatFCFA(s.price)})`).join(', ')}
                            </div>
                          )}

                          {/* Preparation Options */}
                          {cartItem.selectedPreparationOptions && cartItem.selectedPreparationOptions.length > 0 && (
                            <div className="text-[10px] text-emerald-700 mt-0.5">
                              <strong>Option :</strong> {cartItem.selectedPreparationOptions.join(', ')}
                            </div>
                          )}

                          {cartItem.notes && (
                            <div className="text-[10px] text-amber-800 italic mt-0.5">
                              "{cartItem.notes}"
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Quantity & Delete Bar */}
                      <div className="flex items-center justify-between pt-1 border-t border-stone-100 text-xs">
                        <div className="text-[11px] text-stone-400">
                          {formatFCFA(cartItem.unitPrice)} / unité
                        </div>

                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1 bg-stone-100 p-0.5 rounded-lg">
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(cartItem.id, -1)}
                              className="w-5 h-5 rounded bg-white text-stone-700 flex items-center justify-center shadow-2xs hover:bg-stone-200 cursor-pointer"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-5 text-center text-xs font-black text-stone-900">
                              {cartItem.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(cartItem.id, 1)}
                              className="w-5 h-5 rounded bg-rose-600 text-white flex items-center justify-center shadow-2xs hover:bg-rose-700 cursor-pointer"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <button
                            type="button"
                            onClick={() => onRemoveItem(cartItem.id)}
                            className="text-stone-400 hover:text-red-600 p-1 cursor-pointer"
                            title="Supprimer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Delivery Information & GPS System */}
              <div className="space-y-3 pt-2 border-t border-stone-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-rose-600" />
                    Adresse de livraison à Yaoundé
                  </span>
                  {gpsLocation && (
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" /> GPS Actif
                    </span>
                  )}
                </div>

                {/* GPS Auto-Detect Button */}
                <button
                  id="btn-trigger-gps"
                  type="button"
                  onClick={handleGetLocation}
                  disabled={isLocating}
                  className="w-full bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-xl p-3 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs disabled:opacity-50"
                >
                  {isLocating ? (
                    <>
                      <Loader2 className="w-4 h-4 text-amber-600 animate-spin" />
                      <span>Recherche satellite GPS en cours...</span>
                    </>
                  ) : (
                    <>
                      <Compass className="w-4 h-4 text-rose-600 animate-pulse" />
                      <span>📍 Utiliser ma position GPS (Localisation auto)</span>
                    </>
                  )}
                </button>

                {/* GPS Info Banner if fetched */}
                {gpsLocation && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-xs text-emerald-900 space-y-1">
                    <div className="flex items-center justify-between font-bold">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                        Coordonnées : {gpsLocation.latitude.toFixed(4)}, {gpsLocation.longitude.toFixed(4)}
                      </span>
                      {gpsLocation.accuracy && (
                        <span className="text-[10px] font-normal text-emerald-700">
                          Précision ~{gpsLocation.accuracy}m
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-emerald-800 line-clamp-1">
                      {gpsLocation.address}
                    </div>
                    {gpsLocation.googleMapsUrl && (
                      <a
                        href={gpsLocation.googleMapsUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] text-emerald-700 underline font-semibold mt-1"
                      >
                        <ExternalLink className="w-3 h-3" /> Voir sur Google Maps
                      </a>
                    )}
                  </div>
                )}

                {gpsError && (
                  <div className="bg-rose-50 border border-rose-200 text-rose-700 text-xs p-2.5 rounded-xl flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
                    <div>
                      <p className="font-bold">Information GPS :</p>
                      <p className="text-[11px]">{gpsError}</p>
                    </div>
                  </div>
                )}

                {/* Yaoundé Quarter Dropdown */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label htmlFor="select-neighborhood" className="block text-[11px] font-bold text-stone-700 mb-1">
                      Quartier de livraison *
                    </label>
                    <select
                      id="select-neighborhood"
                      value={neighborhood}
                      onChange={(e) => setNeighborhood(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-stone-200 bg-white focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                    >
                      {config.deliveryZones.map((zone) => (
                        <option key={zone} value={zone}>
                          {zone}
                        </option>
                      ))}
                      <option value="Autre">Autre quartier...</option>
                    </select>
                  </div>

                  {neighborhood === 'Autre' && (
                    <div>
                      <label htmlFor="input-custom-neighborhood" className="block text-[11px] font-bold text-stone-700 mb-1">
                        Précisez le quartier *
                      </label>
                      <input
                        id="input-custom-neighborhood"
                        type="text"
                        value={customNeighborhood}
                        onChange={(e) => setCustomNeighborhood(e.target.value)}
                        placeholder="Ex: Nkolndongo, Nsam..."
                        className="w-full text-xs p-2.5 rounded-xl border border-stone-200 focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                      />
                    </div>
                  )}

                  <div className={neighborhood === 'Autre' ? 'sm:col-span-2' : ''}>
                    <label htmlFor="input-landmark" className="block text-[11px] font-bold text-stone-700 mb-1">
                      Repère précis / Carrefour *
                    </label>
                    <input
                      id="input-landmark"
                      type="text"
                      value={landmark}
                      onChange={(e) => setLandmark(e.target.value)}
                      placeholder="Ex: Face boulangerie Calafatas, portail noir..."
                      className="w-full text-xs p-2.5 rounded-xl border border-stone-200 focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                    />
                  </div>
                </div>

                {/* Customer Name & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <div>
                    <label htmlFor="input-customer-name" className="block text-[11px] font-bold text-stone-700 mb-1">
                      Votre Nom & Prénom *
                    </label>
                    <div className="relative">
                      <User className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-3" />
                      <input
                        id="input-customer-name"
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Ex: Paul Biya / Marie"
                        className="w-full text-xs pl-8 pr-2.5 py-2.5 rounded-xl border border-stone-200 focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="input-customer-phone" className="block text-[11px] font-bold text-stone-700 mb-1">
                      Numéro de Téléphone (WhatsApp/Appel) *
                    </label>
                    <div className="relative">
                      <Phone className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-3" />
                      <input
                        id="input-customer-phone"
                        type="tel"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="Ex: 670 00 00 00"
                        className="w-full text-xs pl-8 pr-2.5 py-2.5 rounded-xl border border-stone-200 focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Special instructions */}
                <div>
                  <label htmlFor="input-special-instructions" className="block text-[11px] font-bold text-stone-700 mb-1">
                    Instructions particulières pour le livreur (optionnel) :
                  </label>
                  <input
                    id="input-special-instructions"
                    type="text"
                    value={specialInstructions}
                    onChange={(e) => setSpecialInstructions(e.target.value)}
                    placeholder="Ex: Appelez dès que vous arrivez au carrefour..."
                    className="w-full text-xs p-2.5 rounded-xl border border-stone-200 focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="space-y-2 pt-2 border-t border-stone-200">
                <span className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                  Mode de Paiement (À la livraison)
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {isCashActive && (
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cash')}
                      className={`p-2.5 rounded-xl border text-xs font-medium flex items-center gap-2.5 transition-all text-left cursor-pointer ${
                        paymentMethod === 'cash'
                          ? 'border-rose-600 bg-rose-50/90 text-rose-950 font-bold ring-2 ring-rose-500/30'
                          : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                        <Banknote className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="leading-tight font-bold">Espèces</div>
                        <div className="text-[10px] text-stone-500 truncate">À la livraison</div>
                      </div>
                    </button>
                  )}

                  {isMomoActive && (
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('momo')}
                      className={`p-2.5 rounded-xl border text-xs font-medium flex items-center gap-2.5 transition-all text-left cursor-pointer ${
                        paymentMethod === 'momo'
                          ? 'border-amber-500 bg-amber-50/90 text-amber-950 font-bold ring-2 ring-amber-500/40'
                          : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-lg bg-amber-400 text-stone-900 flex items-center justify-center font-black text-xs shrink-0 shadow-2xs">
                        MoMo
                      </div>
                      <div className="min-w-0">
                        <div className="leading-tight font-bold truncate">MTN MoMo</div>
                        <div className="text-[10px] text-stone-500 truncate">Paiement Mobile</div>
                      </div>
                    </button>
                  )}

                  {isOmActive && (
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('om')}
                      className={`p-2.5 rounded-xl border text-xs font-medium flex items-center gap-2.5 transition-all text-left cursor-pointer ${
                        paymentMethod === 'om'
                          ? 'border-orange-500 bg-orange-50/90 text-orange-950 font-bold ring-2 ring-orange-500/40'
                          : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-lg bg-orange-500 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-2xs">
                        OM
                      </div>
                      <div className="min-w-0">
                        <div className="leading-tight font-bold truncate">Orange Money</div>
                        <div className="text-[10px] text-stone-500 truncate">Paiement Mobile</div>
                      </div>
                    </button>
                  )}
                </div>

                {/* MoMo Account Notice */}
                {paymentMethod === 'momo' && (
                  <div className="bg-amber-50/90 border border-amber-200 rounded-xl p-3 text-xs space-y-2 animate-fade-in">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-amber-900 flex items-center gap-1.5">
                        <span className="inline-block w-2 h-2 rounded-full bg-amber-500"></span>
                        Numéro MTN Mobile Money :
                      </span>
                      <button
                        type="button"
                        onClick={handleCopyMomo}
                        className="bg-amber-200 hover:bg-amber-300 text-amber-950 px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        {copiedMomo ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-700" /> Copié !
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" /> Copier
                          </>
                        )}
                      </button>
                    </div>
                    <div className="font-mono text-sm font-black text-stone-900 bg-white p-2.5 rounded-lg border border-amber-200 flex items-center justify-between shadow-2xs">
                      <span>{config.momoNumber}</span>
                      {config.momoName && (
                        <span className="text-[10px] font-sans font-bold text-amber-800 uppercase tracking-wide">
                          {config.momoName}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-amber-900 leading-snug">
                      ℹ️ Vous pouvez effectuer le transfert dès validation ou payer directement au livreur par MTN MoMo à la réception.
                    </p>
                  </div>
                )}

                {/* Orange Money Account Notice */}
                {paymentMethod === 'om' && (
                  <div className="bg-orange-50/90 border border-orange-200 rounded-xl p-3 text-xs space-y-2 animate-fade-in">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-orange-950 flex items-center gap-1.5">
                        <span className="inline-block w-2 h-2 rounded-full bg-orange-500"></span>
                        Numéro Orange Money officiel :
                      </span>
                      <button
                        type="button"
                        onClick={handleCopyOm}
                        className="bg-orange-200 hover:bg-orange-300 text-orange-950 px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        {copiedOm ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-700" /> Copié !
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" /> Copier
                          </>
                        )}
                      </button>
                    </div>
                    <div className="font-mono text-sm font-black text-stone-900 bg-white p-2.5 rounded-lg border border-orange-200 flex items-center justify-between shadow-2xs">
                      <span>{config.omNumber}</span>
                      {config.omName && (
                        <span className="text-[10px] font-sans font-bold text-orange-800 uppercase tracking-wide">
                          {config.omName}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-orange-900 leading-snug">
                      ℹ️ Vous pouvez effectuer le transfert dès validation ou payer directement au livreur par Orange Money à la réception.
                    </p>
                  </div>
                )}
              </div>

              {/* Financial Recap with Breakdown */}
              <div className="bg-stone-50 rounded-2xl p-3.5 border border-stone-200 space-y-2 text-xs">
                <div className="flex justify-between text-stone-600">
                  <span>Sous-total repas :</span>
                  <span className="font-bold text-stone-800">{formatFCFA(subtotal)}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Frais de livraison ({neighborhood}) :</span>
                  <span className="font-semibold">
                    {deliveryFee === 0 ? (
                      <strong className="text-emerald-600">GRATUIT (Offert dès {formatFCFA(config.freeDeliveryThreshold)})</strong>
                    ) : (
                      formatFCFA(deliveryFee)
                    )}
                  </span>
                </div>
                <div className="pt-2 border-t border-stone-200 flex justify-between items-baseline font-bold text-stone-900">
                  <span className="text-sm">TOTAL À PAYER :</span>
                  <span className="font-display text-lg text-rose-600 font-black">{formatFCFA(total)}</span>
                </div>
              </div>

              {formError && (
                <div className="bg-red-50 border border-red-200 text-red-700 text-xs p-2.5 rounded-xl font-medium">
                  ⚠️ {formError}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Actions */}
        {items.length > 0 && (
          <div className="p-4 border-t border-stone-200 bg-white space-y-2 sticky bottom-0 z-20">
            {/* WhatsApp Checkout Button */}
            <button
              id="btn-order-whatsapp"
              type="button"
              onClick={handleWhatsAppCheckout}
              className="w-full bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold py-3.5 px-4 rounded-2xl shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 text-sm transition-all cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Commander via WhatsApp • {formatFCFA(total)}</span>
            </button>

            {/* Direct Web Order Button */}
            <button
              id="btn-order-direct-web"
              type="button"
              onClick={handleDirectCheckout}
              className="w-full bg-stone-900 hover:bg-black active:scale-98 text-white font-semibold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <CreditCard className="w-3.5 h-3.5 text-amber-400" />
              <span>Valider la commande en ligne (Sans WhatsApp)</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
