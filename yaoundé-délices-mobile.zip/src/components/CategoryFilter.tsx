import React from 'react';
import { CategoryDef } from '../types';
import { Sparkles } from 'lucide-react';

interface CategoryFilterProps {
  categories: CategoryDef[];
  selectedCategory: string; // 'Tous' or category name
  selectedSubcategory: string; // 'Tous' or subcategory name
  onSelectCategory: (category: string) => void;
  onSelectSubcategory: (subcategory: string) => void;
  categoryCounts: Record<string, number>;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  categories,
  selectedCategory,
  selectedSubcategory,
  onSelectCategory,
  onSelectSubcategory,
  categoryCounts,
}) => {
  const currentCategoryDef = categories.find((c) => c.name === selectedCategory);

  return (
    <div className="w-full space-y-2.5">
      {/* Main Categories Carousel */}
      <div className="w-full overflow-x-auto no-scrollbar py-1">
        <div className="flex items-center gap-2 min-w-max px-1">
          {/* "Tous les mets" pill */}
          <button
            id="filter-category-tous"
            onClick={() => {
              onSelectCategory('Tous');
              onSelectSubcategory('Tous');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              selectedCategory === 'Tous'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20 scale-[1.02]'
                : 'bg-white text-stone-700 hover:bg-rose-50 border border-stone-200 hover:border-rose-200'
            }`}
          >
            <Sparkles className={`w-4 h-4 ${selectedCategory === 'Tous' ? 'text-amber-300' : 'text-rose-500'}`} />
            <span>Tous les mets</span>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                selectedCategory === 'Tous'
                  ? 'bg-white/20 text-white'
                  : 'bg-stone-100 text-stone-600'
              }`}
            >
              {categoryCounts['Tous'] || 0}
            </span>
          </button>

          {/* 8 Main Categories */}
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat.name;
            const count = categoryCounts[cat.name] || 0;

            return (
              <button
                key={cat.id}
                id={`filter-category-${cat.id}`}
                onClick={() => {
                  onSelectCategory(cat.name);
                  onSelectSubcategory('Tous');
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20 scale-[1.02]'
                    : 'bg-white text-stone-700 hover:bg-rose-50 border border-stone-200 hover:border-rose-200'
                }`}
              >
                <span className="text-base">{cat.icon}</span>
                <span>{cat.name}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                    isSelected
                      ? 'bg-white/20 text-white'
                      : 'bg-stone-100 text-stone-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Subcategories pills (if a category is selected and has subcategories) */}
      {currentCategoryDef && currentCategoryDef.subcategories && currentCategoryDef.subcategories.length > 0 && (
        <div className="w-full overflow-x-auto no-scrollbar py-0.5">
          <div className="flex items-center gap-1.5 min-w-max px-1 bg-stone-100/70 p-1.5 rounded-2xl border border-stone-200/60">
            <button
              onClick={() => onSelectSubcategory('Tous')}
              className={`px-3 py-1 rounded-xl text-[11px] font-bold transition-colors cursor-pointer ${
                selectedSubcategory === 'Tous'
                  ? 'bg-white text-stone-900 shadow-2xs border border-stone-200'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-white/50'
              }`}
            >
              Tous ({currentCategoryDef.name})
            </button>

            {currentCategoryDef.subcategories.map((sub) => {
              const isSubSelected = selectedSubcategory === sub;
              return (
                <button
                  key={sub}
                  onClick={() => onSelectSubcategory(sub)}
                  className={`px-3 py-1 rounded-xl text-[11px] font-bold transition-colors cursor-pointer ${
                    isSubSelected
                      ? 'bg-white text-rose-700 shadow-2xs border border-rose-200'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-white/50'
                  }`}
                >
                  {sub}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
