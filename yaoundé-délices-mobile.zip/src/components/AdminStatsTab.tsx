import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  ShoppingBag,
  DollarSign,
  Users,
  Clock,
  CheckCircle2,
  XCircle,
  Download,
  Volume2,
  VolumeX,
  Sparkles,
  MapPin,
  Flame,
  ArrowUpRight,
  RefreshCw,
  Percent,
  Calendar,
  Layers,
  ChevronRight
} from 'lucide-react';
import { Order } from '../types';
import { formatFCFA } from '../utils/formatters';
import { computeDashboardStats, downloadOrdersCSV, downloadStatsCSV } from '../utils/statsHelper';
import { soundNotifier } from '../utils/audioAlert';

interface AdminStatsTabProps {
  orders: Order[];
  onNavigateToOrders: (statusFilter?: string) => void;
  showToast: (msg: string) => void;
}

export const AdminStatsTab: React.FC<AdminStatsTabProps> = ({
  orders,
  onNavigateToOrders,
  showToast,
}) => {
  const [period, setPeriod] = useState<'today' | 'week' | 'month' | 'all'>('week');
  const [soundActive, setSoundActive] = useState<boolean>(() => soundNotifier.isEnabled());

  const stats = useMemo(() => computeDashboardStats(orders), [orders]);

  const handleToggleSound = () => {
    const next = !soundActive;
    setSoundActive(next);
    soundNotifier.setEnabled(next);
    if (next) {
      soundNotifier.playNewOrderAlert();
      showToast('Notifications sonores activées (Test de son joué)');
    } else {
      showToast('Notifications sonores désactivées');
    }
  };

  const handleTestSound = () => {
    soundNotifier.playNewOrderAlert();
    showToast('Alerte sonore de nouvelle commande jouée !');
  };

  const maxDailyRevenue = Math.max(...stats.dailyTrend.map(d => d.revenue), 10000);

  return (
    <div className="space-y-6">
      {/* Top Action Bar: Sound Alert & CSV Exports */}
      <div className="bg-gradient-to-r from-stone-900 via-stone-800 to-amber-950 text-white p-4 sm:p-5 rounded-2xl border border-stone-700 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-display font-extrabold text-base sm:text-lg text-white">
                Tableau de Bord & Statistiques
              </h2>
              <span className="text-[10px] uppercase font-black tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Temps Réel
              </span>
            </div>
            <p className="text-xs text-stone-300">
              Indicateurs de performance, chiffre d'affaires et suivi des ventes à Yaoundé.
            </p>
          </div>
        </div>

        {/* Action Buttons: Sound & CSV */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Sound notification toggle */}
          <button
            type="button"
            onClick={handleToggleSound}
            className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              soundActive
                ? 'bg-amber-500 text-stone-950 hover:bg-amber-400 shadow-xs'
                : 'bg-stone-800 text-stone-400 hover:text-white border border-stone-700'
            }`}
            title="Activer/Désactiver l'alerte sonore pour les nouvelles commandes"
          >
            {soundActive ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span>{soundActive ? 'Son : Actif' : 'Son : Muet'}</span>
          </button>

          {soundActive && (
            <button
              type="button"
              onClick={handleTestSound}
              className="px-2.5 py-2 rounded-xl text-[11px] bg-stone-800/80 hover:bg-stone-700 text-stone-300 border border-stone-700 font-medium transition-colors cursor-pointer"
              title="Tester le son de notification"
            >
              Tester le son
            </button>
          )}

          {/* Export CSV Commandes */}
          <button
            type="button"
            onClick={() => {
              downloadOrdersCSV(orders);
              showToast('Export CSV des commandes téléchargé !');
            }}
            className="px-3 py-2 rounded-xl text-xs font-bold bg-stone-800 hover:bg-stone-700 text-white border border-stone-600 flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            title="Exporter la liste des commandes pour Excel"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Export Commandes</span>
          </button>

          {/* Export CSV Stats */}
          <button
            type="button"
            onClick={() => {
              downloadStatsCSV(stats);
              showToast('Rapport statistiques téléchargé en CSV !');
            }}
            className="px-3 py-2 rounded-xl text-xs font-bold bg-stone-800 hover:bg-stone-700 text-white border border-stone-600 flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            title="Exporter le rapport d'analyse pour Excel"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export Stats</span>
          </button>
        </div>
      </div>

      {/* Period Filter Selector */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="text-xs font-bold text-stone-600 flex items-center gap-1.5">
          <Calendar className="w-4 h-4 text-stone-400" />
          <span>Vue Synthétique :</span>
        </div>
        <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-xl border border-stone-200">
          <button
            type="button"
            onClick={() => setPeriod('today')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              period === 'today'
                ? 'bg-white text-stone-900 shadow-2xs'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            Aujourd'hui
          </button>
          <button
            type="button"
            onClick={() => setPeriod('week')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              period === 'week'
                ? 'bg-white text-stone-900 shadow-2xs'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            7 Derniers Jours
          </button>
          <button
            type="button"
            onClick={() => setPeriod('month')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              period === 'month'
                ? 'bg-white text-stone-900 shadow-2xs'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            Ce Mois
          </button>
          <button
            type="button"
            onClick={() => setPeriod('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              period === 'all'
                ? 'bg-white text-stone-900 shadow-2xs'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            Global
          </button>
        </div>
      </div>

      {/* 1. KEY METRICS GRID (Optimized for mobile & high contrast) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Metric 1: Selected Period CA */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-amber-50 to-orange-50/60 border border-amber-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-amber-800 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {period === 'today'
                ? "CA Aujourd'hui"
                : period === 'week'
                ? 'CA Semaine'
                : period === 'month'
                ? 'CA du Mois'
                : 'CA Total'}
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-200/80 text-amber-900 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="font-display font-black text-xl sm:text-2xl text-stone-950 tracking-tight">
            {formatFCFA(
              period === 'today'
                ? stats.todayRevenue
                : period === 'week'
                ? stats.weekRevenue
                : period === 'month'
                ? stats.monthRevenue
                : stats.allTimeRevenue
            )}
          </div>
          <div className="text-[11px] text-stone-500 mt-1 flex items-center gap-1 font-medium">
            <span>Commandes :</span>
            <strong className="text-stone-900">
              {period === 'today'
                ? stats.todayOrdersCount
                : period === 'week'
                ? stats.weekOrdersCount
                : period === 'month'
                ? stats.monthOrdersCount
                : stats.allTimeOrdersCount}
            </strong>
          </div>
        </div>

        {/* Metric 2: Average Basket */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-stone-200 shadow-2xs">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Panier Moyen</span>
            <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-800 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="font-display font-black text-xl sm:text-2xl text-stone-950 tracking-tight">
            {formatFCFA(stats.averageOrderValue)}
          </div>
          <p className="text-[11px] text-stone-500 mt-1">Montant moyen / commande</p>
        </div>

        {/* Metric 3: Orders in Real-Time / Pending */}
        <div
          onClick={() => onNavigateToOrders('pending')}
          className="p-4 sm:p-5 rounded-2xl bg-white border border-stone-200 hover:border-amber-400 transition-all shadow-2xs cursor-pointer group"
          title="Cliquer pour voir les commandes en attente"
        >
          <div className="flex items-center justify-between text-amber-600 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              En Attente
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="font-display font-black text-xl sm:text-2xl text-stone-950 tracking-tight flex items-baseline justify-between">
            <span>{stats.pendingCount}</span>
            <span className="text-[11px] text-amber-700 font-bold group-hover:underline flex items-center gap-0.5">
              Voir <ChevronRight className="w-3 h-3" />
            </span>
          </div>
          <p className="text-[11px] text-stone-500 mt-1">Reçues & En préparation</p>
        </div>

        {/* Metric 4: Conversion Rate & Traffic */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-stone-200 shadow-2xs">
          <div className="flex items-center justify-between text-emerald-700 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Conversion</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <div className="font-display font-black text-xl sm:text-2xl text-emerald-800 tracking-tight">
            {stats.conversionRate}%
          </div>
          <p className="text-[11px] text-stone-500 mt-1">
            {stats.allTimeOrdersCount} cmd / {stats.visitorsCount} visiteurs
          </p>
        </div>
      </div>

      {/* 2. REAL-TIME STATUS QUICK STRIP */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-extrabold text-xs sm:text-sm text-stone-900 flex items-center gap-1.5">
            <span>État des Commandes en Temps Réel</span>
          </h3>
          <span className="text-[11px] text-stone-500">
            Total : <strong>{orders.length}</strong> commandes
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {/* Reçue / En attente */}
          <button
            type="button"
            onClick={() => onNavigateToOrders('received')}
            className="p-3 rounded-xl border border-amber-300/80 bg-amber-50/70 hover:bg-amber-100/60 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-bold text-amber-900 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span>Reçues</span>
            </div>
            <div className="text-lg font-display font-black text-amber-950 mt-1">
              {orders.filter(o => o.status === 'received').length}
            </div>
            <div className="text-[10px] text-amber-700 font-medium">À confirmer</div>
          </button>

          {/* En préparation */}
          <button
            type="button"
            onClick={() => onNavigateToOrders('preparing')}
            className="p-3 rounded-xl border border-orange-300/80 bg-orange-50/70 hover:bg-orange-100/60 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-bold text-orange-900 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-orange-500" />
              <span>En préparation</span>
            </div>
            <div className="text-lg font-display font-black text-orange-950 mt-1">
              {orders.filter(o => o.status === 'preparing').length}
            </div>
            <div className="text-[10px] text-orange-700 font-medium">En cuisine</div>
          </button>

          {/* En route */}
          <button
            type="button"
            onClick={() => onNavigateToOrders('on_the_way')}
            className="p-3 rounded-xl border border-blue-300/80 bg-blue-50/70 hover:bg-blue-100/60 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-bold text-blue-900 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
              <span>En route</span>
            </div>
            <div className="text-lg font-display font-black text-blue-950 mt-1">
              {orders.filter(o => o.status === 'on_the_way').length}
            </div>
            <div className="text-[10px] text-blue-700 font-medium">Avec le livreur</div>
          </button>

          {/* Livrées */}
          <button
            type="button"
            onClick={() => onNavigateToOrders('delivered')}
            className="p-3 rounded-xl border border-emerald-300/80 bg-emerald-50/70 hover:bg-emerald-100/60 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-bold text-emerald-900 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>Livrées</span>
            </div>
            <div className="text-lg font-display font-black text-emerald-950 mt-1">
              {stats.deliveredCount}
            </div>
            <div className="text-[10px] text-emerald-700 font-medium">Finalisées avec succès</div>
          </button>
        </div>
      </div>

      {/* 3. DAILY REVENUE & ORDERS BAR CHART */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
          <div>
            <h3 className="font-display font-extrabold text-stone-900 text-sm flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-amber-500" />
              <span>Chiffre d'Affaires & Commandes (7 Derniers Jours)</span>
            </h3>
            <p className="text-[11px] text-stone-500">
              Évolution journalière des ventes à Yaoundé
            </p>
          </div>
          <div className="text-xs font-bold text-stone-700 bg-stone-50 px-2.5 py-1 rounded-lg border border-stone-200">
            Total 7J : <span className="text-amber-800">{formatFCFA(stats.weekRevenue)}</span> ({stats.weekOrdersCount} cmd)
          </div>
        </div>

        {/* Visual Bar Chart */}
        <div className="pt-2">
          <div className="grid grid-cols-7 gap-2 sm:gap-4 items-end h-44 sm:h-52 pb-6 border-b border-stone-200 relative">
            {stats.dailyTrend.map((day, idx) => {
              const heightPct = Math.max(Math.round((day.revenue / maxDailyRevenue) * 100), 8);
              const isToday = idx === stats.dailyTrend.length - 1;

              return (
                <div key={day.dateKey} className="flex flex-col items-center h-full justify-end group">
                  {/* Tooltip on hover */}
                  <div className="text-[10px] font-bold text-stone-700 mb-1.5 opacity-90 text-center truncate w-full">
                    {day.revenue > 0 ? (
                      <span className="hidden sm:inline">{formatFCFA(day.revenue)}</span>
                    ) : (
                      <span className="text-stone-300">0 F</span>
                    )}
                  </div>

                  {/* Bar column */}
                  <div
                    style={{ height: `${heightPct}%` }}
                    className={`w-full max-w-[38px] rounded-t-xl transition-all duration-300 relative group-hover:scale-105 flex flex-col justify-end p-1 ${
                      isToday
                        ? 'bg-gradient-to-t from-amber-600 to-amber-400 ring-2 ring-amber-400/40 shadow-sm'
                        : day.revenue > 0
                        ? 'bg-gradient-to-t from-stone-800 to-stone-600'
                        : 'bg-stone-100 border border-dashed border-stone-200'
                    }`}
                  >
                    {day.ordersCount > 0 && (
                      <span className="text-[9px] font-black text-white text-center drop-shadow-xs">
                        {day.ordersCount}
                      </span>
                    )}
                  </div>

                  {/* Day label below */}
                  <span className={`text-[10px] sm:text-xs mt-2 font-medium truncate max-w-full ${
                    isToday ? 'font-bold text-amber-700' : 'text-stone-500'
                  }`}>
                    {day.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-[11px] text-stone-400 pt-2">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-md bg-stone-700 inline-block" />
              <span>Chiffre d'Affaires</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-md bg-amber-500 inline-block" />
              <span>Aujourd'hui</span>
            </span>
            <span>Unité : FCFA</span>
          </div>
        </div>
      </div>

      {/* 4. DUAL COLUMN: TOP 10 DISHES & NEIGHBORHOOD BREAKDOWN */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Top 10 Best Sellers */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display font-extrabold text-stone-900 text-sm flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-rose-500" />
                <span>Top 10 Plats les Plus Vendus</span>
              </h3>
              <p className="text-[11px] text-stone-500">Classement par volume de commandes</p>
            </div>
            <span className="text-[11px] font-bold text-stone-600 bg-stone-100 px-2 py-0.5 rounded-lg">
              {stats.topDishes.length} mets classés
            </span>
          </div>

          {stats.topDishes.length === 0 ? (
            <div className="p-6 text-center text-xs text-stone-400">
              Aucune vente enregistrée pour le moment.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
              {stats.topDishes.map((dish, idx) => {
                const maxQty = stats.topDishes[0]?.quantitySold || 1;
                const fillPct = Math.round((dish.quantitySold / maxQty) * 100);

                return (
                  <div
                    key={dish.dishId}
                    className="p-2.5 rounded-xl border border-stone-100 hover:border-stone-200 bg-stone-50/50 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        {/* Rank Badge */}
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center font-black text-[10px] shrink-0 ${
                          idx === 0
                            ? 'bg-amber-400 text-stone-950 shadow-2xs'
                            : idx === 1
                            ? 'bg-stone-300 text-stone-900'
                            : idx === 2
                            ? 'bg-amber-700 text-white'
                            : 'bg-stone-200 text-stone-600'
                        }`}>
                          {idx + 1}
                        </span>

                        <div className="min-w-0">
                          <h4 className="font-bold text-stone-900 text-xs truncate">
                            {dish.dishName}
                          </h4>
                          <span className="text-[10px] text-stone-500">
                            {dish.category}
                          </span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="font-black text-xs text-stone-900">
                          {dish.quantitySold} vendus
                        </div>
                        <div className="text-[10px] font-medium text-amber-700">
                          {formatFCFA(dish.totalRevenue)}
                        </div>
                      </div>
                    </div>

                    {/* Progress Fill Bar */}
                    <div className="w-full bg-stone-200/80 rounded-full h-1.5 overflow-hidden">
                      <div
                        style={{ width: `${fillPct}%` }}
                        className="bg-gradient-to-r from-rose-500 to-amber-500 h-full rounded-full transition-all"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Neighborhood Distribution */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display font-extrabold text-stone-900 text-sm flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span>Statistiques par Quartier (Yaoundé)</span>
              </h3>
              <p className="text-[11px] text-stone-500">Zones les plus actives en livraison</p>
            </div>
            <span className="text-[11px] font-bold text-stone-600 bg-stone-100 px-2 py-0.5 rounded-lg">
              {stats.neighborhoodStats.length} quartiers
            </span>
          </div>

          {stats.neighborhoodStats.length === 0 ? (
            <div className="p-6 text-center text-xs text-stone-400">
              Aucune commande par quartier enregistrée.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
              {stats.neighborhoodStats.map((neigh, idx) => {
                const maxOrders = stats.neighborhoodStats[0]?.ordersCount || 1;
                const fillPct = Math.round((neigh.ordersCount / maxOrders) * 100);

                return (
                  <div
                    key={neigh.neighborhood}
                    className="p-2.5 rounded-xl border border-stone-100 hover:border-stone-200 bg-stone-50/50 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                        <span className="font-bold text-stone-900 text-xs truncate">
                          {neigh.neighborhood}
                        </span>
                      </div>
                      <div className="text-right shrink-0 flex items-center gap-3">
                        <span className="font-black text-xs text-stone-900">
                          {neigh.ordersCount} cmd
                        </span>
                        <span className="text-[11px] text-stone-500 font-medium min-w-[70px] text-right">
                          {formatFCFA(neigh.totalRevenue)}
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-stone-200/80 rounded-full h-1.5 overflow-hidden">
                      <div
                        style={{ width: `${fillPct}%` }}
                        className="bg-emerald-600 h-full rounded-full transition-all"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
