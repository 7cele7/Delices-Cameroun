import React from 'react';
import { Search, Sparkles, MapPin, Phone, ShieldCheck, Clock } from 'lucide-react';
import { RestaurantConfig } from '../types';
import { formatFCFA } from '../utils/formatters';

interface HeroBannerProps {
  config: RestaurantConfig;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOrderNow: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  config,
  searchQuery,
  onSearchChange,
  onOrderNow,
}) => {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-stone-900 via-rose-950 to-amber-950 text-white shadow-xl mb-6 sm:mb-8">
      {/* Background Graphic Patterns & Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(244,162,97,0.25),transparent_50%)] pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-rose-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 p-5 sm:p-8 md:p-10 max-w-4xl">
        {/* Top pill badge */}
        <div className="inline-flex items-center gap-1.5 bg-white/10 backdrop-blur-md border border-white/15 px-3 py-1 rounded-full text-xs font-semibold text-amber-300 mb-3 sm:mb-4">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Le goût authentique du Cameroun à Yaoundé</span>
        </div>

        {/* Hero Title */}
        <h1 className="font-display font-extrabold text-2xl sm:text-4xl md:text-5xl text-white tracking-tight leading-tight sm:leading-tight">
          Les saveurs camerounaises <br className="hidden sm:inline" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-rose-400">
            que vous aimez
          </span>
          , livrées chez vous.
        </h1>

        <p className="text-stone-300 text-xs sm:text-base mt-2 sm:mt-3 max-w-2xl leading-relaxed">
          Commandez vos mets traditionnels préférés préparés à la commande.
          Livraison offerte dès <strong>{formatFCFA(config.freeDeliveryThreshold)}</strong> à Yaoundé.
        </p>

        {/* Search Bar Input */}
        <div className="mt-5 sm:mt-6 max-w-xl">
          <div className="relative flex items-center">
            <Search className="w-5 h-5 text-stone-400 absolute left-3.5" />
            <input
              id="hero-search-dish"
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Rechercher un plat (ex: Poulet DG, Soya, Poisson...)"
              className="w-full bg-white text-stone-900 pl-11 pr-24 sm:pr-28 py-3 rounded-2xl text-xs sm:text-sm font-medium shadow-lg border-2 border-transparent focus:border-amber-400 focus:outline-hidden placeholder:text-stone-400"
            />
            {searchQuery ? (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 text-xs text-stone-400 hover:text-stone-700 bg-stone-100 px-2 py-1 rounded-lg"
              >
                Effacer
              </button>
            ) : (
              <button
                onClick={onOrderNow}
                className="absolute right-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-3 sm:px-4 py-2 rounded-xl transition-colors shadow-xs"
              >
                Commander
              </button>
            )}
          </div>
        </div>

        {/* Feature Badges */}
        <div className="mt-6 sm:mt-8 pt-4 sm:pt-6 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center text-amber-400 shrink-0">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white">Localisation GPS</div>
              <div className="text-[11px] text-stone-400">Précision à Yaoundé</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center text-amber-400 shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white">Paiement MoMo</div>
              <div className="text-[11px] text-stone-400">Ou espèces à la livraison</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center text-amber-400 shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white">{config.openingTime} - {config.closingTime}</div>
              <div className="text-[11px] text-stone-400">{config.workingDays}</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center text-amber-400 shrink-0">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white">WhatsApp & Appel</div>
              <div className="text-[11px] text-stone-400">Assistance directe</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
