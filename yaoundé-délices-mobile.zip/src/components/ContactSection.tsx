import React, { useState } from 'react';
import { Phone, MessageCircle, Clock, MapPin, CreditCard, Copy, Check, Truck, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { RestaurantConfig } from '../types';
import { formatFCFA } from '../utils/formatters';

interface ContactSectionProps {
  config: RestaurantConfig;
}

const FAQS = [
  {
    q: "Comment fonctionne la géolocalisation GPS pour ma livraison ?",
    a: "Dans votre panier, cliquez simplement sur « 📍 Utiliser ma position GPS ». Votre navigateur transmettra vos coordonnées précises. Notre livreur reçoit le lien Google Maps exact vers votre localisation à Yaoundé."
  },
  {
    q: "Quels sont les frais de livraison ?",
    a: "La livraison est GRATUITE pour toute commande à partir de 5 000 FCFA. Pour les commandes inférieures, les frais sont fixés à 1 000 FCFA pour couvrir l'ensemble des quartiers de Yaoundé."
  },
  {
    q: "Comment payer par MTN MoMo ou Orange Money ?",
    a: "Vous pouvez effectuer un transfert direct vers nos comptes officiels MTN Mobile Money ou Orange Money, ou régler directement auprès du livreur à la réception de vos plats."
  },
  {
    q: "Quels sont les délais de livraison à Yaoundé ?",
    a: "Les repas sont cuisinés à la commande. Le délai moyen de préparation et de livraison est de 30 à 45 minutes selon l'affluence et le quartier."
  }
];

export const ContactSection: React.FC<ContactSectionProps> = ({ config }) => {
  const [copiedMomo, setCopiedMomo] = useState(false);
  const [copiedOm, setCopiedOm] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleCopyMomo = () => {
    navigator.clipboard.writeText(config.momoNumber);
    setCopiedMomo(true);
    setTimeout(() => setCopiedMomo(false), 2500);
  };

  const handleCopyOm = () => {
    navigator.clipboard.writeText(config.omNumber);
    setCopiedOm(true);
    setTimeout(() => setCopiedOm(false), 2500);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      {/* Title */}
      <div className="text-center space-y-2">
        <span className="text-xs font-bold uppercase tracking-widest text-rose-600 bg-rose-50 px-3 py-1 rounded-full">
          Informations & Contact
        </span>
        <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-stone-900">
          Nous contacter & Zones de livraison
        </h1>
        <p className="text-stone-500 text-xs sm:text-sm max-w-md mx-auto">
          Besoin d'une commande spéciale, d'un traiteur pour événement ou d'une information ? Nous sommes à votre écoute.
        </p>
      </div>

      {/* 4 Main Action Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Phone Card */}
        <div className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs hover:border-amber-300 transition-all flex flex-col justify-between space-y-3">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <Phone className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-stone-900 text-sm">Appels directs</h3>
            <p className="text-xs text-stone-500">Pour passer commande ou joindre la réception.</p>
          </div>
          <a
            href={`tel:${config.phoneCall.replace(/\s+/g, '')}`}
            className="w-full bg-rose-600 hover:bg-rose-700 text-white font-bold py-2 px-3 rounded-xl text-xs text-center block transition-colors"
          >
            {config.phoneCall}
          </a>
        </div>

        {/* WhatsApp Card */}
        <div className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs hover:border-emerald-300 transition-all flex flex-col justify-between space-y-3">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <MessageCircle className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-stone-900 text-sm">WhatsApp Délices</h3>
            <p className="text-xs text-stone-500">Service client et commandes rapides 24/7.</p>
          </div>
          <a
            href={`https://wa.me/${config.phoneWhatsApp.replace(/\D/g, '')}`}
            target="_blank"
            rel="noreferrer"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-3 rounded-xl text-xs text-center block transition-colors"
          >
            Discuter sur WhatsApp
          </a>
        </div>

        {/* MTN MoMo Card */}
        <div className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs hover:border-amber-400 transition-all flex flex-col justify-between space-y-3">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-stone-900 text-sm">MTN Mobile Money</h3>
            <p className="text-xs text-stone-500">
              {config.momoName ? `Compte : ${config.momoName}` : 'Paiement sécurisé'}
            </p>
          </div>
          <button
            onClick={handleCopyMomo}
            className="w-full bg-amber-400 hover:bg-amber-500 text-stone-900 font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            {copiedMomo ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-900" /> Copié !
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" /> {config.momoNumber}
              </>
            )}
          </button>
        </div>

        {/* Orange Money Card */}
        <div className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs hover:border-orange-400 transition-all flex flex-col justify-between space-y-3">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-stone-900 text-sm">Orange Money</h3>
            <p className="text-xs text-stone-500">
              {config.omName ? `Compte : ${config.omName}` : 'Paiement sécurisé'}
            </p>
          </div>
          <button
            onClick={handleCopyOm}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            {copiedOm ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-200" /> Copié !
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" /> {config.omNumber}
              </>
            )}
          </button>
        </div>
      </div>

      {/* Opening hours & Delivery details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hours & Rules */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <h2 className="font-display font-bold text-stone-900 text-base">
              Horaires & Tarification
            </h2>
          </div>

          <div className="space-y-2.5 text-xs text-stone-600">
            <div className="flex justify-between py-1.5 border-b border-stone-100">
              <span className="font-semibold text-stone-700">Jours de service :</span>
              <span className="font-bold text-stone-900">{config.workingDays}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-stone-100">
              <span className="font-semibold text-stone-700">Heures de livraison :</span>
              <span className="font-bold text-stone-900">{config.openingTime} - {config.closingTime}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-stone-100">
              <span className="font-semibold text-stone-700">Livraison GRATUITE :</span>
              <span className="font-bold text-emerald-600">Dès {formatFCFA(config.freeDeliveryThreshold)}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="font-semibold text-stone-700">Tarif standard livraison :</span>
              <span className="font-bold text-stone-900">{formatFCFA(config.standardDeliveryFee)}</span>
            </div>
          </div>
        </div>

        {/* Delivery Zones in Yaoundé */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
              <MapPin className="w-4 h-4" />
            </div>
            <h2 className="font-display font-bold text-stone-900 text-base">
              Quartiers desservis à Yaoundé
            </h2>
          </div>

          <p className="text-xs text-stone-500">
            Nos livreurs à moto couvrent l'intégralité des 7 arrondissements de la capitale :
          </p>

          <div className="flex flex-wrap gap-1.5">
            {config.deliveryZones.map((zone) => (
              <span
                key={zone}
                className="bg-stone-100 hover:bg-rose-50 text-stone-700 hover:text-rose-700 text-xs px-2.5 py-1 rounded-lg transition-colors font-medium border border-stone-200/60"
              >
                {zone}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
            <HelpCircle className="w-4 h-4" />
          </div>
          <h2 className="font-display font-bold text-stone-900 text-base">
            Questions Fréquentes (FAQ)
          </h2>
        </div>

        <div className="divide-y divide-stone-100">
          {FAQS.map((faq, index) => {
            const isOpen = openFaq === index;
            return (
              <div key={index} className="py-3">
                <button
                  type="button"
                  onClick={() => setOpenFaq(isOpen ? null : index)}
                  className="w-full flex items-center justify-between text-left font-bold text-stone-800 text-xs sm:text-sm hover:text-rose-600 transition-colors"
                >
                  <span>{faq.q}</span>
                  {isOpen ? <ChevronUp className="w-4 h-4 shrink-0 text-stone-400" /> : <ChevronDown className="w-4 h-4 shrink-0 text-stone-400" />}
                </button>
                {isOpen && (
                  <p className="text-stone-600 text-xs mt-2 leading-relaxed bg-amber-50/50 p-3 rounded-xl border border-amber-100">
                    {faq.a}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
