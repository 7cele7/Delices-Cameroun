export type AvailabilityStatus = 'disponible' | 'indisponible' | 'epuise';

export interface PortionOption {
  id: string; // 'petite' | 'standard' | 'grande' | 'familiale'
  name: string; // "Petite", "Standard", "Grande", "Familiale"
  price: number; // in FCFA
  isAvailable?: boolean;
  servesInfo?: string; // "1 pers.", "1-2 pers.", "2-3 pers.", "4-6 pers."
}

export interface SupplementOption {
  id: string;
  name: string; // e.g. "Poisson", "Poulet", "Viande", "Œuf", "Sauce supplémentaire"
  price: number; // in FCFA
}

export interface ExtraAccompanimentOption {
  id: string;
  name: string; // e.g. "Plantains frits extra", "Bâton de manioc additionnel", "Riz parfumé extra"
  price: number; // in FCFA
}

export interface CategoryDef {
  id: string;
  name: string;
  icon: string;
  subcategories: string[];
}

export interface MenuItem {
  id: string;
  name: string;
  category: string; // Matches CategoryDef.name
  subcategory: string;
  description: string;
  image: string;
  badge?: string; // e.g. "Spécialité", "Populaire", "Nouveau"
  popular?: boolean;
  preparationTime?: string; // e.g. "25-35 min"
  availability: AvailabilityStatus;
  
  // Portions with price per portion
  portions: PortionOption[];
  
  // Accompagnements
  includedAccompaniments: string[]; // Options among which customer picks 1 (e.g. ['Plantain', 'Riz', 'Manioc'])
  extraAccompaniments?: ExtraAccompanimentOption[]; // Paid extra accompaniments
  
  // Suppléments payants
  supplements?: SupplementOption[]; // e.g. [{id: 'sup-1', name: 'Poisson', price: 2000}]
  
  // Options de préparation
  preparationOptions?: string[]; // e.g. ['Sans sel ajouté', 'Piment à part', 'Bien épicé / pimenté']
}

export interface CartItem {
  id: string; // unique item line id (hash or random string)
  item: MenuItem;
  quantity: number;
  selectedPortion: PortionOption;
  selectedAccompaniment?: string; // included one
  selectedExtraAccompaniments: ExtraAccompanimentOption[];
  selectedSupplements: SupplementOption[];
  selectedPreparationOptions: string[];
  notes?: string;
  unitPrice: number; // calculated unit price (portion + extras + supplements)
  totalPrice: number; // unitPrice * quantity
}

export interface GPSLocation {
  latitude: number;
  longitude: number;
  accuracy?: number;
  address?: string;
  neighborhood?: string;
  googleMapsUrl?: string;
}

export type OrderStatus = 'received' | 'preparing' | 'on_the_way' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  createdAt: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  customerName: string;
  customerPhone: string;
  neighborhood: string;
  manualAddress: string;
  landmark: string; // Repère (ex: Face boulangerie)
  gpsLocation?: GPSLocation;
  specialInstructions?: string;
  adminNote?: string;
  cancellationReason?: string;
  paymentMethod: 'cash' | 'momo' | 'om';
  status: OrderStatus;
}

export interface CustomPaymentMethod {
  id: string;
  name: string;
  details?: string;
  instructions?: string;
  enabled: boolean;
}

export interface RestaurantConfig {
  restaurantName: string;
  phoneCall: string; // e.g. "+237670000000"
  phoneWhatsApp: string; // e.g. "237670000000"
  momoNumber: string; // e.g. "6 70 00 00 00"
  momoName: string; // e.g. "YAOUNDE DELICES SARL"
  omNumber: string; // e.g. "6 90 00 00 00"
  omName: string; // e.g. "YAOUNDE DELICES SARL"
  momoEnabled?: boolean;
  omEnabled?: boolean;
  cashEnabled?: boolean;
  customPaymentMethods?: CustomPaymentMethod[];
  freeDeliveryThreshold: number; // 5000 FCFA
  standardDeliveryFee: number; // 1000 FCFA
  openingTime: string; // "11:00"
  closingTime: string; // "22:00"
  workingDays: string; // "Lundi au Samedi"
  city: string;
  deliveryZones: string[];
  adminPassword?: string; // Default "yaounde2026"
}

