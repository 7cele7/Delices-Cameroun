/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { MobileNav } from './components/MobileNav';
import { HeroBanner } from './components/HeroBanner';
import { CategoryFilter } from './components/CategoryFilter';
import { DishCard } from './components/DishCard';
import { DishDetailModal } from './components/DishDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { OrdersTracker } from './components/OrdersTracker';
import { ContactSection } from './components/ContactSection';
import { AboutSection } from './components/AboutSection';
import { OurCommitment } from './components/OurCommitment';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { AutoUpdateBanner } from './components/AutoUpdateBanner';
import { Footer } from './components/Footer';
import { MenuItem, CartItem, Order, RestaurantConfig, CategoryDef, PortionOption, ExtraAccompanimentOption, SupplementOption } from './types';
import { initAutoUpdateSystem } from './utils/versionChecker';
import {
  getStoredMenu,
  saveStoredMenu,
  resetMenuToDefault,
  getStoredCategories,
  saveStoredCategories,
  getStoredConfig,
  saveStoredConfig,
  getStoredOrders,
  saveStoredOrder,
  updateStoredOrderStatus,
  deleteStoredOrder,
  getSavedCustomer,
} from './utils/storage';
import { formatFCFA } from './utils/formatters';
import { Utensils, Flame, ArrowRight, ShieldCheck, Truck, Clock, Sparkles } from 'lucide-react';

export default function App() {
  // Application Data States
  const [menu, setMenu] = useState<MenuItem[]>(getStoredMenu);
  const [categories, setCategories] = useState<CategoryDef[]>(getStoredCategories);
  const [config, setConfig] = useState<RestaurantConfig>(getStoredConfig);
  const [orders, setOrders] = useState<Order[]>(getStoredOrders);
  const [savedCustomer] = useState(getSavedCustomer);

  // Navigation & View States
  const [activeTab, setActiveTab] = useState<string>('accueil');
  const [selectedCategory, setSelectedCategory] = useState<string>('Tous');
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>('Tous');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Modals
  const [selectedDishForDetail, setSelectedDishForDetail] = useState<MenuItem | null>(null);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Initialize auto-update system (checks every 30s)
  useEffect(() => {
    initAutoUpdateSystem();
  }, []);

  // Cart summary calculations
  const cartCount = useMemo(() => cart.reduce((acc, item) => acc + item.quantity, 0), [cart]);
  const cartTotal = useMemo(
    () => cart.reduce((acc, item) => acc + (item.totalPrice || (item.unitPrice * item.quantity)), 0),
    [cart]
  );

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { Tous: menu.length };
    menu.forEach((dish) => {
      counts[dish.category] = (counts[dish.category] || 0) + 1;
    });
    return counts;
  }, [menu]);

  // Filtered dishes
  const filteredDishes = useMemo(() => {
    return menu.filter((dish) => {
      const matchesCategory =
        selectedCategory === 'Tous' || dish.category === selectedCategory;
      const matchesSubcategory =
        selectedSubcategory === 'Tous' || dish.subcategory === selectedSubcategory;
      const matchesSearch =
        searchQuery === '' ||
        dish.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        dish.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        dish.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (dish.subcategory && dish.subcategory.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSubcategory && matchesSearch;
    });
  }, [menu, selectedCategory, selectedSubcategory, searchQuery]);

  // Featured dishes for Accueil (popular or badge)
  const featuredDishes = useMemo(() => {
    return menu.filter((d) => d.popular || d.badge).slice(0, 4);
  }, [menu]);

  // Quick add from card (uses default/standard portion)
  const handleAddToCartQuick = (dish: MenuItem) => {
    const defaultPortion: PortionOption =
      dish.portions && dish.portions.length > 0
        ? dish.portions[0]
        : { id: 'standard', name: 'Standard', price: 3500 };

    const defaultIncludedAcc =
      dish.includedAccompaniments && dish.includedAccompaniments.length > 0
        ? dish.includedAccompaniments[0]
        : undefined;

    const unitPrice = defaultPortion.price;
    const totalPrice = unitPrice * 1;

    const cartItemId = `${dish.id}-${defaultPortion.id}`;

    setCart((prev) => {
      const existing = prev.find((item) => item.id === cartItemId);
      if (existing) {
        return prev.map((item) =>
          item.id === cartItemId
            ? {
                ...item,
                quantity: item.quantity + 1,
                totalPrice: (item.quantity + 1) * item.unitPrice,
              }
            : item
        );
      }
      return [
        ...prev,
        {
          id: cartItemId,
          item: dish,
          quantity: 1,
          selectedPortion: defaultPortion,
          selectedIncludedAccompaniment: defaultIncludedAcc,
          selectedExtraAccompaniments: [],
          selectedSupplements: [],
          selectedPreparationOptions: [],
          unitPrice,
          totalPrice,
        },
      ];
    });
  };

  // Add customized item from Detail Modal
  const handleAddToCartCustom = (customItem: {
    dish: MenuItem;
    quantity: number;
    portion: PortionOption;
    includedAccompaniment?: string;
    extraAccompaniments: ExtraAccompanimentOption[];
    supplements: SupplementOption[];
    preparationOptions: string[];
    notes?: string;
    unitPrice: number;
    totalPrice: number;
  }) => {
    const extraAccIds = customItem.extraAccompaniments.map(e => e.id).sort().join('-');
    const supIds = customItem.supplements.map(s => s.id).sort().join('-');
    const prepIds = customItem.preparationOptions.sort().join('-');
    const cartItemId = `${customItem.dish.id}-${customItem.portion.id}-${customItem.includedAccompaniment || 'none'}-${extraAccIds}-${supIds}-${prepIds}-${customItem.notes || ''}`;

    setCart((prev) => {
      const existing = prev.find((item) => item.id === cartItemId);
      if (existing) {
        const newQty = existing.quantity + customItem.quantity;
        return prev.map((item) =>
          item.id === cartItemId
            ? {
                ...item,
                quantity: newQty,
                totalPrice: newQty * item.unitPrice,
              }
            : item
        );
      }
      return [
        ...prev,
        {
          id: cartItemId,
          item: customItem.dish,
          quantity: customItem.quantity,
          selectedPortion: customItem.portion,
          selectedIncludedAccompaniment: customItem.includedAccompaniment,
          selectedExtraAccompaniments: customItem.extraAccompaniments,
          selectedSupplements: customItem.supplements,
          selectedPreparationOptions: customItem.preparationOptions,
          notes: customItem.notes,
          unitPrice: customItem.unitPrice,
          totalPrice: customItem.totalPrice,
        },
      ];
    });

    setIsCartOpen(true);
  };

  // Cart actions
  const handleUpdateQuantity = (cartItemId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.id === cartItemId) {
            const newQty = item.quantity + delta;
            return newQty > 0
              ? { ...item, quantity: newQty, totalPrice: newQty * item.unitPrice }
              : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== cartItemId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Order Handlers
  const handleOrderSuccess = (newOrder: Order) => {
    saveStoredOrder(newOrder);
    setOrders((prev) => [newOrder, ...prev]);
    setCompletedOrder(newOrder);
    setIsCartOpen(false);
  };

  const handleUpdateOrderStatus = (
    orderId: string,
    status: Order['status'],
    note?: string,
    cancellationReason?: string
  ) => {
    updateStoredOrderStatus(orderId, status, note, cancellationReason);
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== orderId) return o;
        return {
          ...o,
          status,
          ...(note !== undefined ? { adminNote: note } : {}),
          ...(cancellationReason !== undefined ? { cancellationReason } : {}),
        };
      })
    );
  };

  const handleDeleteOrder = (orderId: string) => {
    deleteStoredOrder(orderId);
    setOrders((prev) => prev.filter((o) => o.id !== orderId));
  };

  // Admin / Menu Management Handlers
  const handleSaveMenu = (newMenu: MenuItem[]) => {
    setMenu(newMenu);
    saveStoredMenu(newMenu);
  };

  const handleSaveCategories = (newCategories: CategoryDef[]) => {
    setCategories(newCategories);
    saveStoredCategories(newCategories);
  };

  const handleSaveConfig = (newConfig: RestaurantConfig) => {
    setConfig(newConfig);
    saveStoredConfig(newConfig);
  };

  const handleResetMenu = () => {
    const def = resetMenuToDefault();
    setMenu(def);
    return def;
  };

  return (
    <div className="min-h-screen bg-stone-50/50 flex flex-col font-sans text-stone-900">
      {/* Navigation Header */}
      <Navbar
        config={config}
        cartCount={cartCount}
        cartTotal={cartTotal}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 py-4 sm:py-6">
        {/* Tab 1: ACCUEIL */}
        {activeTab === 'accueil' && (
          <div className="space-y-6 sm:space-y-8">
            {/* Hero Header */}
            <HeroBanner
              config={config}
              searchQuery={searchQuery}
              onSearchChange={(q) => {
                setSearchQuery(q);
                if (q) setActiveTab('menu');
              }}
              onOrderNow={() => setActiveTab('menu')}
            />

            {/* Incontournables / Spécialités Phares */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-extrabold uppercase tracking-widest text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded-full">
                    Les Incontournables
                  </span>
                  <h2 className="font-display font-extrabold text-xl sm:text-2xl text-stone-900 mt-1">
                    Nos Plats Vedettes du Moment
                  </h2>
                </div>
                <button
                  onClick={() => {
                    setSelectedCategory('Tous');
                    setSelectedSubcategory('Tous');
                    setActiveTab('menu');
                  }}
                  className="text-xs sm:text-sm font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 group cursor-pointer"
                >
                  <span>Voir toute la carte ({menu.length})</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              {/* 2-column mobile, 4-column desktop grid */}
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {featuredDishes.map((dish) => {
                  const cartItem = cart.find((i) => i.item.id === dish.id);
                  return (
                    <DishCard
                      key={dish.id}
                      dish={dish}
                      cartItem={cartItem}
                      onAddToCart={handleAddToCartQuick}
                      onUpdateQuantity={(delta) => {
                        if (cartItem) handleUpdateQuantity(cartItem.id, delta);
                      }}
                      onOpenDetail={(d) => setSelectedDishForDetail(d)}
                    />
                  );
                })}
              </div>
            </div>

            {/* 8 Official Categories Quick Discovery */}
            <div className="bg-amber-500/10 rounded-3xl p-5 sm:p-7 border border-amber-200/70 space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-stone-900 flex items-center justify-center font-black">
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-base sm:text-lg text-stone-900">
                    Explorez nos 8 Catégories Gourmandes
                  </h3>
                  <p className="text-stone-500 text-xs">
                    Légumes traditionnels, Grillades & Braises, Rôtis, Fritures, Plats en sauce, Accompagnements, Salades & Boissons
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 gap-2.5">
                {categories.map((cat) => {
                  const count = categoryCounts[cat.name] || 0;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setSelectedCategory(cat.name);
                        setSelectedSubcategory('Tous');
                        setActiveTab('menu');
                      }}
                      className="p-3 bg-white hover:bg-rose-50/80 border border-stone-200 hover:border-rose-300 rounded-2xl text-left transition-all group shadow-2xs cursor-pointer"
                    >
                      <div className="text-lg mb-1">{cat.icon}</div>
                      <div className="font-bold text-stone-900 group-hover:text-rose-600 text-xs leading-tight">
                        {cat.name}
                      </div>
                      <div className="text-[10px] text-stone-500 mt-1">
                        {count} met{count > 1 ? 's' : ''}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Notre Engagement - Assurance & Qualité Camerounaise */}
            <OurCommitment />

            {/* Guarantees & Delivery Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                  <Truck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-stone-900 text-xs">Livraison à domicile</h4>
                  <p className="text-[11px] text-stone-500">
                    Gratuite dès {formatFCFA(config.freeDeliveryThreshold)} à Yaoundé
                  </p>
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-stone-900 text-xs">Paiement Mobile Money</h4>
                  <p className="text-[11px] text-stone-500">
                    MTN MoMo, Orange Money & Espèces
                  </p>
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-stone-900 text-xs">Horaires de Service</h4>
                  <p className="text-[11px] text-stone-500">
                    {config.workingDays} : {config.openingTime} - {config.closingTime}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: MENU COMPLET */}
        {activeTab === 'menu' && (
          <div className="space-y-6">
            {/* Header with Search & Filter */}
            <div className="space-y-3">
              <div>
                <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-stone-900">
                  Catalogue des Mets & Saveurs
                </h1>
                <p className="text-stone-500 text-xs">
                  {filteredDishes.length} met{filteredDishes.length > 1 ? 's' : ''} disponible{filteredDishes.length > 1 ? 's' : ''} • Choisissez vos portions et suppléments
                </p>
              </div>

              {/* 8 Categories & Subcategories Filter */}
              <CategoryFilter
                categories={categories}
                selectedCategory={selectedCategory}
                selectedSubcategory={selectedSubcategory}
                onSelectCategory={setSelectedCategory}
                onSelectSubcategory={setSelectedSubcategory}
                categoryCounts={categoryCounts}
              />
            </div>

            {/* Dish Grid: 2 columns on mobile, 3-4 on desktop */}
            {filteredDishes.length === 0 ? (
              <div className="py-16 text-center space-y-3 bg-white rounded-3xl border border-stone-200 p-6">
                <div className="w-14 h-14 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
                  <Utensils className="w-7 h-7" />
                </div>
                <h3 className="font-bold text-stone-800 text-base">Aucun met trouvé</h3>
                <p className="text-stone-500 text-xs max-w-sm mx-auto">
                  Aucun résultat ne correspond à votre filtre. Essayez d'autres critères ou réinitialisez la recherche.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('Tous');
                    setSelectedSubcategory('Tous');
                  }}
                  className="bg-rose-600 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs cursor-pointer"
                >
                  Réinitialiser les filtres
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {filteredDishes.map((dish) => {
                  const cartItem = cart.find((i) => i.item.id === dish.id);
                  return (
                    <DishCard
                      key={dish.id}
                      dish={dish}
                      cartItem={cartItem}
                      onAddToCart={handleAddToCartQuick}
                      onUpdateQuantity={(delta) => {
                        if (cartItem) handleUpdateQuantity(cartItem.id, delta);
                      }}
                      onOpenDetail={(d) => setSelectedDishForDetail(d)}
                    />
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: SUIVI COMMANDES */}
        {activeTab === 'commandes' && (
          <OrdersTracker
            orders={orders}
            config={config}
            onUpdateStatus={handleUpdateOrderStatus}
            onStartNewOrder={() => setActiveTab('menu')}
          />
        )}

        {/* Tab 4: CONTACT & LIVRAISON */}
        {activeTab === 'contact' && <ContactSection config={config} />}

        {/* Tab 5: À PROPOS */}
        {activeTab === 'apropos' && <AboutSection />}
      </main>

      {/* Footer */}
      <Footer
        config={config}
        setActiveTab={setActiveTab}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Mobile Bottom Floating Nav */}
      <MobileNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={cartCount}
        cartTotal={cartTotal}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Dish Detail / Portions & Supplements Modal */}
      <DishDetailModal
        dish={selectedDishForDetail}
        onClose={() => setSelectedDishForDetail(null)}
        onAddToCart={handleAddToCartCustom}
      />

      {/* Cart & Checkout Drawer with GPS & MoMo / Orange Money */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        config={config}
        savedCustomer={savedCustomer}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Order Success Celebratory Modal */}
      <OrderSuccessModal
        order={completedOrder}
        config={config}
        onClose={() => setCompletedOrder(null)}
        onViewTracker={() => {
          setCompletedOrder(null);
          setActiveTab('commandes');
        }}
      />

      {/* Admin / Menu Customizer Modal */}
      <AdminDashboardModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        menu={menu}
        categories={categories}
        config={config}
        orders={orders}
        onSaveMenu={handleSaveMenu}
        onSaveCategories={handleSaveCategories}
        onSaveConfig={handleSaveConfig}
        onUpdateOrderStatus={handleUpdateOrderStatus}
        onDeleteOrder={handleDeleteOrder}
        onAddOrder={handleOrderSuccess}
        onResetMenu={handleResetMenu}
      />
      {/* Auto-Update Detector Banner & Status */}
      <AutoUpdateBanner />
    </div>
  );
}
