/**
 * Yaoundé Délices - Système de Vérification et Mise à Jour Automatique
 * Vérifie toutes les 30 secondes si une nouvelle version ou modification est disponible.
 */

export interface VersionInfo {
  versionId: string;
  checkedAt: number;
  hasUpdate: boolean;
  mode: 'banner' | 'silent';
  checkIntervalSeconds: number;
  isChecking: boolean;
}

const STORAGE_KEYS = {
  MODE: 'yd_autoupdate_mode',
  INTERVAL: 'yd_autoupdate_interval',
  ENABLED: 'yd_autoupdate_enabled',
};

// Initial fingerprint captured on page load
let initialFingerprint: string | null = null;
let isUpdateAvailable = false;
let checkTimer: number | null = null;
const listeners = new Set<(info: VersionInfo) => void>();

/**
 * Calcule une empreinte de la page HTML actuelle (scripts, tags, balises ou ETag)
 */
async function fetchCurrentFingerprint(): Promise<string> {
  try {
    const timestamp = Date.now();
    const response = await fetch(`/?_t=${timestamp}`, {
      method: 'GET',
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      },
      cache: 'no-store',
    });

    const etag = response.headers.get('ETag') || response.headers.get('etag');
    const lastModified = response.headers.get('Last-Modified') || response.headers.get('last-modified');

    const htmlText = await response.text();
    
    // Extract script src attributes or HTML structure checksum
    const scriptMatches = htmlText.match(/<script[^>]+src="([^">]+)"/gi) || [];
    const scriptSrcs = scriptMatches.join('|');
    const headLength = htmlText.substring(0, 1500);

    return `${etag || ''}::${lastModified || ''}::${scriptSrcs}::${headLength.length}::${htmlText.length}`;
  } catch (err) {
    console.warn('[AutoUpdate] Erreur lors de la vérification de version:', err);
    return initialFingerprint || 'fallback-v1';
  }
}

export function getAutoUpdateMode(): 'banner' | 'silent' {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.MODE);
    return saved === 'silent' ? 'silent' : 'banner';
  } catch {
    return 'banner';
  }
}

export function setAutoUpdateMode(mode: 'banner' | 'silent') {
  try {
    localStorage.setItem(STORAGE_KEYS.MODE, mode);
    notifyListeners();
  } catch (e) {
    console.error(e);
  }
}

export function getAutoUpdateInterval(): number {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.INTERVAL);
    const parsed = saved ? parseInt(saved, 10) : 30;
    return parsed >= 10 ? parsed : 30;
  } catch {
    return 30;
  }
}

export function setAutoUpdateInterval(seconds: number) {
  try {
    localStorage.setItem(STORAGE_KEYS.INTERVAL, seconds.toString());
    restartTimer();
    notifyListeners();
  } catch (e) {
    console.error(e);
  }
}

export function isAutoUpdateEnabled(): boolean {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.ENABLED);
    return saved !== 'false';
  } catch {
    return true;
  }
}

export function setAutoUpdateEnabled(enabled: boolean) {
  try {
    localStorage.setItem(STORAGE_KEYS.ENABLED, enabled ? 'true' : 'false');
    if (enabled) {
      restartTimer();
    } else if (checkTimer) {
      window.clearInterval(checkTimer);
      checkTimer = null;
    }
    notifyListeners();
  } catch (e) {
    console.error(e);
  }
}

let isCurrentlyChecking = false;
let lastCheckTime = Date.now();

/**
 * Lance la vérification de nouvelle version
 */
export async function checkForUpdate(isManual = false): Promise<boolean> {
  if (isCurrentlyChecking) return isUpdateAvailable;
  isCurrentlyChecking = true;
  lastCheckTime = Date.now();
  notifyListeners();

  try {
    if (!initialFingerprint) {
      initialFingerprint = await fetchCurrentFingerprint();
      isCurrentlyChecking = false;
      notifyListeners();
      return false;
    }

    const currentFingerprint = await fetchCurrentFingerprint();

    if (currentFingerprint && initialFingerprint && currentFingerprint !== initialFingerprint) {
      isUpdateAvailable = true;
      const mode = getAutoUpdateMode();
      
      notifyListeners();

      if (mode === 'silent' && !isManual) {
        console.log('[AutoUpdate] Nouvelle version détectée en mode silencieux -> rechargement automatique...');
        setTimeout(() => {
          window.location.reload();
        }, 800);
      }

      isCurrentlyChecking = false;
      return true;
    }
  } catch (err) {
    console.warn('[AutoUpdate] Erreur vérification:', err);
  } finally {
    isCurrentlyChecking = false;
    notifyListeners();
  }

  return isUpdateAvailable;
}

/**
 * Simule une nouvelle version (pour tester l'affichage de l'alerte ou le rechargement)
 */
export function simulateNewVersion() {
  isUpdateAvailable = true;
  const mode = getAutoUpdateMode();
  notifyListeners();

  if (mode === 'silent') {
    setTimeout(() => {
      window.location.reload();
    }, 1200);
  }
}

export function triggerReload() {
  window.location.reload();
}

export function dismissUpdateNotification() {
  isUpdateAvailable = false;
  notifyListeners();
}

function notifyListeners() {
  const info: VersionInfo = {
    versionId: initialFingerprint || 'v1',
    checkedAt: lastCheckTime,
    hasUpdate: isUpdateAvailable,
    mode: getAutoUpdateMode(),
    checkIntervalSeconds: getAutoUpdateInterval(),
    isChecking: isCurrentlyChecking,
  };

  listeners.forEach((listener) => {
    try {
      listener(info);
    } catch (err) {
      console.error(err);
    }
  });
}

export function subscribeToVersionUpdates(listener: (info: VersionInfo) => void): () => void {
  listeners.add(listener);
  // Send current status immediately
  listener({
    versionId: initialFingerprint || 'v1',
    checkedAt: lastCheckTime,
    hasUpdate: isUpdateAvailable,
    mode: getAutoUpdateMode(),
    checkIntervalSeconds: getAutoUpdateInterval(),
    isChecking: isCurrentlyChecking,
  });

  return () => {
    listeners.delete(listener);
  };
}

function restartTimer() {
  if (checkTimer) {
    window.clearInterval(checkTimer);
    checkTimer = null;
  }

  if (!isAutoUpdateEnabled()) return;

  const intervalMs = getAutoUpdateInterval() * 1000;
  checkTimer = window.setInterval(() => {
    checkForUpdate(false);
  }, intervalMs);
}

/**
 * Initialise le système de vérification automatique au démarrage
 */
export function initAutoUpdateSystem() {
  if (typeof window === 'undefined') return;

  // Capture initial fingerprint
  fetchCurrentFingerprint().then((fp) => {
    initialFingerprint = fp;
    notifyListeners();
  });

  // Start periodic 30-second checking loop
  restartTimer();

  // Also check when window regains focus or network reconnects
  window.addEventListener('focus', () => {
    checkForUpdate(false);
  });

  window.addEventListener('online', () => {
    checkForUpdate(false);
  });
}
