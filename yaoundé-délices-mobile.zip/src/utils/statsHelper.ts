import { Order } from '../types';
import { formatFCFA } from './formatters';
import { getVisitorCount } from './storage';

export interface DayRevenueStat {
  dateKey: string; // YYYY-MM-DD
  label: string; // "Aujourd'hui", "Hier", "Lun 24", etc.
  revenue: number;
  ordersCount: number;
}

export interface DishSalesStat {
  dishId: string;
  dishName: string;
  category: string;
  image?: string;
  quantitySold: number;
  totalRevenue: number;
  percentage: number;
}

export interface NeighborhoodStat {
  neighborhood: string;
  ordersCount: number;
  totalRevenue: number;
  percentage: number;
}

export interface DashboardStats {
  todayOrdersCount: number;
  todayRevenue: number;
  weekOrdersCount: number;
  weekRevenue: number;
  monthOrdersCount: number;
  monthRevenue: number;
  allTimeOrdersCount: number;
  allTimeRevenue: number;
  averageOrderValue: number;
  pendingCount: number; // 'received' + 'preparing'
  deliveredCount: number;
  cancelledCount: number;
  visitorsCount: number;
  conversionRate: number; // %
  topDishes: DishSalesStat[];
  neighborhoodStats: NeighborhoodStat[];
  dailyTrend: DayRevenueStat[];
}

export function computeDashboardStats(orders: Order[]): DashboardStats {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const weekStart = todayStart - 6 * 24 * 3600 * 1000;
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();

  let todayOrdersCount = 0;
  let todayRevenue = 0;
  let weekOrdersCount = 0;
  let weekRevenue = 0;
  let monthOrdersCount = 0;
  let monthRevenue = 0;
  let allTimeOrdersCount = 0;
  let allTimeRevenue = 0;
  let pendingCount = 0;
  let deliveredCount = 0;
  let cancelledCount = 0;

  const dishMap = new Map<string, { name: string; category: string; image?: string; qty: number; revenue: number }>();
  const neighborhoodMap = new Map<string, { count: number; revenue: number }>();
  const dailyMap = new Map<string, { label: string; revenue: number; count: number }>();

  // Prepare last 7 days slots for daily trend
  for (let i = 6; i >= 0; i--) {
    const d = new Date(todayStart - i * 24 * 3600 * 1000);
    const key = d.toISOString().split('T')[0];
    let label = d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric' });
    if (i === 0) label = "Aujourd'hui";
    else if (i === 1) label = 'Hier';
    dailyMap.set(key, { label, revenue: 0, count: 0 });
  }

  orders.forEach((order) => {
    const orderTime = new Date(order.createdAt).getTime();
    const isCancelled = order.status === 'cancelled';
    const amount = isCancelled ? 0 : order.total;

    allTimeOrdersCount += 1;
    if (!isCancelled) {
      allTimeRevenue += amount;
    }

    if (order.status === 'received' || order.status === 'preparing') {
      pendingCount += 1;
    } else if (order.status === 'delivered') {
      deliveredCount += 1;
    } else if (order.status === 'cancelled') {
      cancelledCount += 1;
    }

    // Today
    if (orderTime >= todayStart) {
      todayOrdersCount += 1;
      if (!isCancelled) todayRevenue += amount;
    }

    // This week
    if (orderTime >= weekStart) {
      weekOrdersCount += 1;
      if (!isCancelled) weekRevenue += amount;
    }

    // This month
    if (orderTime >= monthStart) {
      monthOrdersCount += 1;
      if (!isCancelled) monthRevenue += amount;
    }

    // Daily trend
    const dayKey = order.createdAt.split('T')[0];
    if (dailyMap.has(dayKey)) {
      const current = dailyMap.get(dayKey)!;
      current.count += 1;
      if (!isCancelled) current.revenue += amount;
    }

    // Dish sales (only count non-cancelled or include all order attempts)
    if (!isCancelled) {
      order.items.forEach((cartItem) => {
        const dishId = cartItem.item.id;
        const existing = dishMap.get(dishId) || {
          name: cartItem.item.name,
          category: cartItem.item.category,
          image: cartItem.item.image,
          qty: 0,
          revenue: 0,
        };
        existing.qty += cartItem.quantity;
        existing.revenue += cartItem.totalPrice;
        dishMap.set(dishId, existing);
      });

      // Neighborhood breakdown
      const neigh = order.neighborhood || 'Autre quartier';
      const nExist = neighborhoodMap.get(neigh) || { count: 0, revenue: 0 };
      nExist.count += 1;
      nExist.revenue += order.total;
      neighborhoodMap.set(neigh, nExist);
    }
  });

  // Calculate average order value
  const validNonCancelledOrders = orders.filter(o => o.status !== 'cancelled').length;
  const averageOrderValue = validNonCancelledOrders > 0 ? Math.round(allTimeRevenue / validNonCancelledOrders) : 0;

  // Visitors & conversion
  const visitorsCount = getVisitorCount();
  const conversionRate = visitorsCount > 0 ? Number(((allTimeOrdersCount / visitorsCount) * 100).toFixed(1)) : 0;

  // Sort Top Dishes
  const topDishes: DishSalesStat[] = Array.from(dishMap.entries())
    .map(([dishId, data]) => ({
      dishId,
      dishName: data.name,
      category: data.category,
      image: data.image,
      quantitySold: data.qty,
      totalRevenue: data.revenue,
      percentage: allTimeRevenue > 0 ? Math.round((data.revenue / allTimeRevenue) * 100) : 0,
    }))
    .sort((a, b) => b.quantitySold - a.quantitySold)
    .slice(0, 10);

  // Sort Neighborhoods
  const neighborhoodStats: NeighborhoodStat[] = Array.from(neighborhoodMap.entries())
    .map(([neighborhood, data]) => ({
      neighborhood,
      ordersCount: data.count,
      totalRevenue: data.revenue,
      percentage: allTimeRevenue > 0 ? Math.round((data.revenue / allTimeRevenue) * 100) : 0,
    }))
    .sort((a, b) => b.ordersCount - a.ordersCount);

  // Daily Trend Array
  const dailyTrend: DayRevenueStat[] = Array.from(dailyMap.entries()).map(([dateKey, data]) => ({
    dateKey,
    label: data.label,
    revenue: data.revenue,
    ordersCount: data.count,
  }));

  return {
    todayOrdersCount,
    todayRevenue,
    weekOrdersCount,
    weekRevenue,
    monthOrdersCount,
    monthRevenue,
    allTimeOrdersCount,
    allTimeRevenue,
    averageOrderValue,
    pendingCount,
    deliveredCount,
    cancelledCount,
    visitorsCount,
    conversionRate,
    topDishes,
    neighborhoodStats,
    dailyTrend,
  };
}

export function downloadOrdersCSV(orders: Order[]): void {
  const headers = [
    'ID Commande',
    'Date et Heure',
    'Client',
    'Telephone',
    'Quartier',
    'Adresse precise',
    'Repere',
    'Plats commandes',
    'Sous-total FCFA',
    'Frais Livraison FCFA',
    'Total FCFA',
    'Mode de Paiement',
    'Statut',
    'Note Interne',
    'Motif Annulation'
  ];

  const statusLabels: Record<string, string> = {
    received: 'Reçue (En attente)',
    preparing: 'En préparation',
    on_the_way: 'En route',
    delivered: 'Livrée',
    cancelled: 'Annulée',
  };

  const paymentLabels: Record<string, string> = {
    cash: 'Espèces à la livraison',
    momo: 'MTN Mobile Money',
    om: 'Orange Money',
  };

  const rows = orders.map(order => {
    const formattedDate = new Date(order.createdAt).toLocaleString('fr-FR');
    const itemsSummary = order.items.map(i => `${i.quantity}x ${i.item.name} (${i.selectedPortion.name})`).join(' + ');
    
    return [
      `"${order.id}"`,
      `"${formattedDate}"`,
      `"${(order.customerName || '').replace(/"/g, '""')}"`,
      `"${order.customerPhone || ''}"`,
      `"${(order.neighborhood || '').replace(/"/g, '""')}"`,
      `"${(order.manualAddress || '').replace(/"/g, '""')}"`,
      `"${(order.landmark || '').replace(/"/g, '""')}"`,
      `"${itemsSummary.replace(/"/g, '""')}"`,
      order.subtotal,
      order.deliveryFee,
      order.total,
      `"${paymentLabels[order.paymentMethod] || order.paymentMethod}"`,
      `"${statusLabels[order.status] || order.status}"`,
      `"${(order.adminNote || '').replace(/"/g, '""')}"`,
      `"${(order.cancellationReason || '').replace(/"/g, '""')}"`
    ].join(';');
  });

  const csvContent = '\uFEFF' + [headers.join(';'), ...rows].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `yaounde_delices_commandes_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function downloadStatsCSV(stats: DashboardStats): void {
  const lines: string[] = [];
  lines.push('=== RAPPORT STATISTIQUES YAOUNDÉ DÉLICES ===');
  lines.push(`Date d'exportation;${new Date().toLocaleString('fr-FR')}`);
  lines.push('');
  lines.push('INDICATEURS CLÉS;VALEUR');
  lines.push(`Commandes Aujourd'hui;${stats.todayOrdersCount}`);
  lines.push(`Chiffre d'Affaires Aujourd'hui;${stats.todayRevenue} FCFA`);
  lines.push(`Commandes Cette Semaine;${stats.weekOrdersCount}`);
  lines.push(`Chiffre d'Affaires Cette Semaine;${stats.weekRevenue} FCFA`);
  lines.push(`Commandes Ce Mois;${stats.monthOrdersCount}`);
  lines.push(`Chiffre d'Affaires Ce Mois;${stats.monthRevenue} FCFA`);
  lines.push(`Total Historique Commandes;${stats.allTimeOrdersCount}`);
  lines.push(`Chiffre d'Affaires Total;${stats.allTimeRevenue} FCFA`);
  lines.push(`Panier Moyen;${stats.averageOrderValue} FCFA`);
  lines.push(`Commandes En Attente;${stats.pendingCount}`);
  lines.push(`Commandes Livrées;${stats.deliveredCount}`);
  lines.push(`Commandes Annulées;${stats.cancelledCount}`);
  lines.push(`Visiteurs Uniques;${stats.visitorsCount}`);
  lines.push(`Taux de Conversion;${stats.conversionRate} %`);
  lines.push('');
  lines.push('TOP 10 DES PLATS LES PLUS VENDUS');
  lines.push('Rang;Plat;Catégorie;Quantité Vendue;Chiffre d\'Affaires FCFA;Part %');
  stats.topDishes.forEach((dish, idx) => {
    lines.push(`${idx + 1};"${dish.dishName}";"${dish.category}";${dish.quantitySold};${dish.totalRevenue};${dish.percentage}%`);
  });
  lines.push('');
  lines.push('RÉPARTITION PAR QUARTIER DE YAOUNDÉ');
  lines.push('Quartier;Nombre de Commandes;Chiffre d\'Affaires FCFA;Part %');
  stats.neighborhoodStats.forEach((neigh) => {
    lines.push(`"${neigh.neighborhood}";${neigh.ordersCount};${neigh.totalRevenue};${neigh.percentage}%`);
  });

  const csvContent = '\uFEFF' + lines.join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `yaounde_delices_statistiques_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
