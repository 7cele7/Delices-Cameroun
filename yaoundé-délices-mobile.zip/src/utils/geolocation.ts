import { GPSLocation } from '../types';

export const YAOUNDE_QUARTERS_COORDINATES: Record<string, { lat: number; lng: number }> = {
  'Bastos': { lat: 3.8967, lng: 11.5133 },
  'Mvog-Mbi': { lat: 3.8465, lng: 11.5186 },
  'Mokolo': { lat: 3.8741, lng: 11.4983 },
  'Etoudi': { lat: 3.9189, lng: 11.5312 },
  'Nlongkak': { lat: 3.8821, lng: 11.5204 },
  'Omnisports': { lat: 3.8845, lng: 11.5367 },
  'Biyem-Assi': { lat: 3.8342, lng: 11.4876 },
  'Tsinga': { lat: 3.8812, lng: 11.5034 },
  'Odza': { lat: 3.7981, lng: 11.5358 },
  'Mendong': { lat: 3.8291, lng: 11.4721 },
  'Essos': { lat: 3.8654, lng: 11.5412 },
  'Melen': { lat: 3.8582, lng: 11.4941 },
  'Santa Barbara': { lat: 3.9042, lng: 11.5276 },
  'Nkolbisson': { lat: 3.8643, lng: 11.4589 },
  'Ngousso': { lat: 3.8992, lng: 11.5543 },
  'Emana': { lat: 3.9245, lng: 11.5211 },
  'Ekounou': { lat: 3.8312, lng: 11.5389 },
  'Messassi': { lat: 3.9412, lng: 11.5298 },
  'Madagascar': { lat: 3.8791, lng: 11.4912 },
  'Camp SIC': { lat: 3.8612, lng: 11.5089 }
};

export async function getCurrentGPSPosition(): Promise<GPSLocation> {
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) {
      reject(new Error('La géolocalisation n’est pas supportée par votre navigateur.'));
      return;
    }

    const options: PositionOptions = {
      enableHighAccuracy: true,
      timeout: 12000,
      maximumAge: 30000
    };

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
        const accuracy = Math.round(position.coords.accuracy);
        const googleMapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;

        let address = `Yaoundé (Lat: ${latitude.toFixed(4)}, Long: ${longitude.toFixed(4)})`;
        let neighborhood = detectNearestYaoundeQuarter(latitude, longitude);

        // Try reverse geocoding via OpenStreetMap Nominatim
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}&accept-language=fr`,
            {
              headers: {
                'Accept': 'application/json'
              }
            }
          );
          if (response.ok) {
            const data = await response.json();
            if (data && data.display_name) {
              // Extract suburb/quarter if available
              const addr = data.address || {};
              const quarterName = addr.suburb || addr.neighbourhood || addr.quarter || addr.city_district || addr.road;
              if (quarterName) {
                neighborhood = quarterName;
              }
              address = data.display_name;
            }
          }
        } catch {
          // If network reverse geocode fails, we keep the nearest detected quarter
        }

        resolve({
          latitude,
          longitude,
          accuracy,
          address,
          neighborhood,
          googleMapsUrl
        });
      },
      (error) => {
        let msg = 'Impossible de récupérer votre position GPS.';
        if (error.code === error.PERMISSION_DENIED) {
          msg = 'Accès à la position GPS refusé. Veuillez autoriser la localisation ou saisir votre quartier manuellement.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          msg = 'Signal GPS indisponible. Veuillez saisir votre quartier.';
        } else if (error.code === error.TIMEOUT) {
          msg = 'Délai d’attente GPS dépassé. Veuillez réessayer ou choisir votre quartier.';
        }
        reject(new Error(msg));
      },
      options
    );
  });
}

function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of earth in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in km
}

export function detectNearestYaoundeQuarter(lat: number, lng: number): string {
  let minDistance = Infinity;
  let nearestQuarter = 'Bastos';

  for (const [quarter, coords] of Object.entries(YAOUNDE_QUARTERS_COORDINATES)) {
    const dist = calculateDistance(lat, lng, coords.lat, coords.lng);
    if (dist < minDistance) {
      minDistance = dist;
      nearestQuarter = quarter;
    }
  }

  return nearestQuarter;
}
