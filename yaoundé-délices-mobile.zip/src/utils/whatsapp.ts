import { Order, RestaurantConfig } from '../types';
import { formatFCFA } from './formatters';

export function generateWhatsAppOrderMessage(order: Order, config: RestaurantConfig): string {
  const itemsText = order.items
    .map((cartItem, idx) => {
      const portionText = cartItem.selectedPortion?.name
        ? ` (Portion ${cartItem.selectedPortion.name})`
        : '';
      
      const lines: string[] = [
        `▪️ *${cartItem.quantity}x ${cartItem.item.name}*${portionText} — *${formatFCFA(cartItem.totalPrice)}*`
      ];

      // Included accompaniment
      if (cartItem.selectedAccompaniment) {
        lines.push(`   🍚 Accompagnement : _${cartItem.selectedAccompaniment}_`);
      }

      // Extra accompaniments
      if (cartItem.selectedExtraAccompaniments && cartItem.selectedExtraAccompaniments.length > 0) {
        const extraNames = cartItem.selectedExtraAccompaniments
          .map(a => `${a.name} (+${formatFCFA(a.price)})`)
          .join(', ');
        lines.push(`   ➕ Extra Accompagnement : _${extraNames}_`);
      }

      // Supplements
      if (cartItem.selectedSupplements && cartItem.selectedSupplements.length > 0) {
        const supNames = cartItem.selectedSupplements
          .map(s => `${s.name} (+${formatFCFA(s.price)})`)
          .join(', ');
        lines.push(`   🥩 Suppléments : _${supNames}_`);
      }

      // Preparation Options
      if (cartItem.selectedPreparationOptions && cartItem.selectedPreparationOptions.length > 0) {
        lines.push(`   ⚙️ Préparation : _${cartItem.selectedPreparationOptions.join(', ')}_`);
      }

      // Special notes
      if (cartItem.notes) {
        lines.push(`   📝 Note : _${cartItem.notes}_`);
      }

      return lines.join('\n');
    })
    .join('\n\n');

  const gpsText = order.gpsLocation
    ? `\n🗺️ *Position GPS Google Maps :*\n${order.gpsLocation.googleMapsUrl || `https://www.google.com/maps?q=${order.gpsLocation.latitude},${order.gpsLocation.longitude}`}`
    : `\n🗺️ *Position GPS :* Non fournie`;

  const paymentText =
    order.paymentMethod === 'momo'
      ? `📱 MTN Mobile Money (Compte : ${config.momoNumber}${config.momoName ? ` - ${config.momoName}` : ''})`
      : order.paymentMethod === 'om'
      ? `🍊 Orange Money (Compte : ${config.omNumber}${config.omName ? ` - ${config.omName}` : ''})`
      : `💵 Espèces à la livraison`;

  const deliveryText =
    order.deliveryFee === 0
      ? `🎉 *GRATUITE* (Offerte dès ${formatFCFA(config.freeDeliveryThreshold)})`
      : `${formatFCFA(order.deliveryFee)}`;

  const message = `🍽️ *NOUVELLE COMMANDE - YAOUNDÉ DÉLICES*
━━━━━━━━━━━━━━━━━━━━
🆔 *Code Commande :* #${order.id}
📅 *Date :* ${new Date(order.createdAt).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}

👤 *INFORMATIONS DU CLIENT*
• *Nom :* ${order.customerName}
• *Téléphone :* ${order.customerPhone}
• *Quartier :* ${order.neighborhood}
• *Adresse / Repère :* ${order.landmark || order.manualAddress || 'Non spécifié'}${gpsText}

🛒 *DÉTAIL DES METS COMMANDÉS*
${itemsText}

━━━━━━━━━━━━━━━━━━━━
📊 *RÉCAPITULATIF FINANCIER*
• *Sous-total repas :* ${formatFCFA(order.subtotal)}
• *Frais de livraison :* ${deliveryText}
💰 *TOTAL À PAYER : ${formatFCFA(order.total)}*

💳 *Mode de paiement choisi :* ${paymentText}
${order.specialInstructions ? `📝 *Instructions livreur :* ${order.specialInstructions}\n` : ''}
━━━━━━━━━━━━━━━━━━━━
Merci de me confirmer la commande et le délai estimé ! 🛵💨`;

  return message;
}

export function openWhatsAppOrder(order: Order, config: RestaurantConfig): void {
  const message = generateWhatsAppOrderMessage(order, config);
  const cleanPhone = config.phoneWhatsApp.replace(/\D/g, '');
  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}
