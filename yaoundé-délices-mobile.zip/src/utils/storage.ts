import { CategoryDef, MenuItem, Order, RestaurantConfig } from '../types';
import { DEFAULT_CATEGORIES, DEFAULT_RESTAURANT_CONFIG, INITIAL_MENU_ITEMS } from '../data/initialMenu';

const STORAGE_KEYS = {
  MENU: 'yaounde_delices_menu_v2', // bump version for clean migration
  CATEGORIES: 'yaounde_delices_categories_v2',
  CONFIG: 'yaounde_delices_config_v2',
  ORDERS: 'yaounde_delices_orders_v2',
  SAVED_CUSTOMER: 'yaounde_delices_customer_info_v2',
  VISITOR_COUNT: 'yaounde_delices_visitor_count_v2',
};

export function recordVisitorHit(): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.VISITOR_COUNT);
    let count = raw ? parseInt(raw, 10) : 48; // baseline
    if (isNaN(count)) count = 48;
    // Only increment once per session tab
    if (!sessionStorage.getItem('yaounde_visitor_counted')) {
      count += 1;
      sessionStorage.setItem('yaounde_visitor_counted', 'true');
      localStorage.setItem(STORAGE_KEYS.VISITOR_COUNT, String(count));
    }
    return count;
  } catch {
    return 50;
  }
}

export function getVisitorCount(): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.VISITOR_COUNT);
    const count = raw ? parseInt(raw, 10) : 48;
    return isNaN(count) ? 48 : count;
  } catch {
    return 48;
  }
}

export function getStoredCategories(): CategoryDef[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure "Légumes & Feuilles" is in first position
        const legIdx = parsed.findIndex(c => c.name.includes('Légumes') || c.name.includes('Feuilles'));
        if (legIdx > 0) {
          const leg = parsed.splice(legIdx, 1)[0];
          parsed.unshift(leg);
        }
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error reading stored categories', e);
  }
  return DEFAULT_CATEGORIES;
}

export function saveStoredCategories(categories: CategoryDef[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  } catch (e) {
    console.error('Error saving categories', e);
  }
}

export function resetCategoriesToDefault(): CategoryDef[] {
  try {
    localStorage.removeItem(STORAGE_KEYS.CATEGORIES);
  } catch (e) {
    console.error(e);
  }
  return DEFAULT_CATEGORIES;
}

export function getStoredMenu(): MenuItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.MENU);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error reading stored menu', e);
  }
  return INITIAL_MENU_ITEMS;
}

export function saveStoredMenu(items: MenuItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(items));
  } catch (e) {
    console.error('Error saving menu', e);
  }
}

export function resetMenuToDefault(): MenuItem[] {
  try {
    localStorage.removeItem(STORAGE_KEYS.MENU);
  } catch (e) {
    console.error(e);
  }
  return INITIAL_MENU_ITEMS;
}

export function getStoredConfig(): RestaurantConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CONFIG);
    if (raw) {
      return { ...DEFAULT_RESTAURANT_CONFIG, ...JSON.parse(raw) };
    }
  } catch (e) {
    console.error('Error reading stored config', e);
  }
  return DEFAULT_RESTAURANT_CONFIG;
}

export function saveStoredConfig(config: RestaurantConfig): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
  } catch (e) {
    console.error('Error saving config', e);
  }
}

export function getStoredOrders(): Order[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ORDERS);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error reading stored orders', e);
  }
  // Initialize with sample realistic orders across the week for Yaounde
  const now = new Date();
  const sampleOrders: Order[] = [
    {
      id: 'CMD-849201',
      createdAt: new Date(now.getTime() - 25 * 60 * 1000).toISOString(), // 25 mins ago
      items: [
        {
          id: 'item-1',
          item: {
            id: 'met-1',
            name: 'Poulet DG Royal Traditionnel',
            category: '🍃 Légumes & Feuilles',
            subcategory: 'Spécialités Traditionnelles',
            description: 'Poulet fermier mijoté aux plantains mûrs.',
            image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=600&auto=format&fit=crop&q=80',
            availability: 'disponible',
            portions: [{ id: 'standard', name: 'Standard (1-2 pers.)', price: 4500 }],
            includedAccompaniments: ['Plantains mûrs frits'],
          },
          quantity: 1,
          selectedPortion: { id: 'standard', name: 'Standard (1-2 pers.)', price: 4500 },
          selectedAccompaniment: 'Plantains mûrs frits',
          selectedExtraAccompaniments: [],
          selectedSupplements: [],
          selectedPreparationOptions: ['Piment doux'],
          unitPrice: 4500,
          totalPrice: 4500,
        }
      ],
      subtotal: 4500,
      deliveryFee: 1000,
      total: 5500,
      customerName: 'Marcelle N.',
      customerPhone: '677 89 42 10',
      neighborhood: 'Bastos',
      manualAddress: 'Derrière Ambassade de France, Résidence Les Palmiers',
      landmark: 'Portail blanc après le rond-point',
      paymentMethod: 'momo',
      status: 'received',
      adminNote: 'Appeler 5 min avant d\'arriver au portail',
    },
    {
      id: 'CMD-739182',
      createdAt: new Date(now.getTime() - 95 * 60 * 1000).toISOString(), // ~1.5 hours ago
      items: [
        {
          id: 'item-2',
          item: {
            id: 'met-2',
            name: 'Ndolé Royal Crevettes & Viande',
            category: '🍃 Légumes & Feuilles',
            subcategory: 'Plats Mijotés & Feuilles',
            description: 'Feuilles de ndolé fraîches aux arachides.',
            image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80',
            availability: 'disponible',
            portions: [{ id: 'standard', name: 'Standard', price: 4000 }],
            includedAccompaniments: ['Miondo / Bâton de manioc'],
          },
          quantity: 2,
          selectedPortion: { id: 'standard', name: 'Standard', price: 4000 },
          selectedAccompaniment: 'Miondo / Bâton de manioc',
          selectedExtraAccompaniments: [{ id: 'ext-1', name: 'Plantains mûrs frits', price: 1000 }],
          selectedSupplements: [{ id: 'sup-1', name: 'Crevettes fraîches sautées', price: 1500 }],
          selectedPreparationOptions: [],
          unitPrice: 6500,
          totalPrice: 13000,
        }
      ],
      subtotal: 13000,
      deliveryFee: 0, // Free delivery
      total: 13000,
      customerName: 'Christian M.',
      customerPhone: '699 45 12 78',
      neighborhood: 'Mvog-Mbi',
      manualAddress: 'Carrefour Mvog-Mbi, près pharmacie',
      landmark: 'Immeuble beige 2ème étage',
      paymentMethod: 'om',
      status: 'preparing',
    },
    {
      id: 'CMD-629471',
      createdAt: new Date(now.getTime() - 4 * 3600 * 1000).toISOString(), // 4h ago
      items: [
        {
          id: 'item-3',
          item: {
            id: 'met-3',
            name: 'Poisson Braisé au Feu de Bois (Bar)',
            category: '🔥 Grillades & Braises',
            subcategory: 'Poissons Braisés',
            description: 'Bar braisé avec marinade secrète épicée.',
            image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=600&auto=format&fit=crop&q=80',
            availability: 'disponible',
            portions: [{ id: 'standard', name: 'Bar Moyen (1-2 pers.)', price: 5000 }],
            includedAccompaniments: ['Plantains frits', 'Bâton de manioc'],
          },
          quantity: 1,
          selectedPortion: { id: 'standard', name: 'Bar Moyen (1-2 pers.)', price: 5000 },
          selectedAccompaniment: 'Plantains frits',
          selectedExtraAccompaniments: [],
          selectedSupplements: [],
          selectedPreparationOptions: ['Sauce piment à part'],
          unitPrice: 5000,
          totalPrice: 5000,
        }
      ],
      subtotal: 5000,
      deliveryFee: 0,
      total: 5000,
      customerName: 'Valérie T.',
      customerPhone: '675 33 21 09',
      neighborhood: 'Mokolo',
      manualAddress: 'Entrée Marché Mokolo, boutique 14',
      landmark: 'Face station Total',
      paymentMethod: 'cash',
      status: 'on_the_way',
    },
    {
      id: 'CMD-519384',
      createdAt: new Date(now.getTime() - 7 * 3600 * 1000).toISOString(), // 7h ago
      items: [
        {
          id: 'item-4',
          item: {
            id: 'met-4',
            name: 'Soya Croustillant de Bœuf (Brochettes)',
            category: '🔥 Grillades & Braises',
            subcategory: 'Viandes & Brochettes',
            description: 'Lanières de bœuf marinées et grillées à la flamme.',
            image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=600&auto=format&fit=crop&q=80',
            availability: 'disponible',
            portions: [{ id: 'standard', name: '10 Brochettes', price: 3000 }],
            includedAccompaniments: ['Oignons & piment Kankan'],
          },
          quantity: 2,
          selectedPortion: { id: 'standard', name: '10 Brochettes', price: 3000 },
          selectedAccompaniment: 'Oignons & piment Kankan',
          selectedExtraAccompaniments: [],
          selectedSupplements: [],
          selectedPreparationOptions: ['Beaucoup d\'oignons'],
          unitPrice: 3000,
          totalPrice: 6000,
        }
      ],
      subtotal: 6000,
      deliveryFee: 0,
      total: 6000,
      customerName: 'Emmanuel B.',
      customerPhone: '694 22 10 55',
      neighborhood: 'Biyem-Assi',
      manualAddress: 'Carrefour Acacias, Montée Biyem-Assi',
      landmark: 'Immeuble vert face boulangerie',
      paymentMethod: 'momo',
      status: 'delivered',
    },
    {
      id: 'CMD-409172',
      createdAt: new Date(now.getTime() - 28 * 3600 * 1000).toISOString(), // Yesterday
      items: [
        {
          id: 'item-5',
          item: {
            id: 'met-5',
            name: 'Eru Traditionnel & Waterleaf au Fufu',
            category: '🍃 Légumes & Feuilles',
            subcategory: 'Plats Mijotés & Feuilles',
            description: 'Feuilles d\'okazi et de waterleaf à l\'huile de palme.',
            image: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=600&auto=format&fit=crop&q=80',
            availability: 'disponible',
            portions: [{ id: 'standard', name: 'Standard (1-2 pers.)', price: 3500 }],
            includedAccompaniments: ['Waterfufu (Manioc pilé)'],
          },
          quantity: 2,
          selectedPortion: { id: 'standard', name: 'Standard (1-2 pers.)', price: 3500 },
          selectedAccompaniment: 'Waterfufu (Manioc pilé)',
          selectedExtraAccompaniments: [],
          selectedSupplements: [{ id: 'sup-canda', name: 'Peau de bœuf (Canda)', price: 1000 }],
          selectedPreparationOptions: [],
          unitPrice: 4500,
          totalPrice: 9000,
        }
      ],
      subtotal: 9000,
      deliveryFee: 0,
      total: 9000,
      customerName: 'Patricia K.',
      customerPhone: '671 00 99 88',
      neighborhood: 'Etoudi',
      manualAddress: 'Près Palais des Congrès, Entrée Dispensaire',
      landmark: 'Grande barrière noire',
      paymentMethod: 'cash',
      status: 'delivered',
    },
    {
      id: 'CMD-308192',
      createdAt: new Date(now.getTime() - 52 * 3600 * 1000).toISOString(), // 2 days ago
      items: [
        {
          id: 'item-6',
          item: {
            id: 'met-6',
            name: 'Koki de Cornille à l\'Huile de Palme',
            category: '🍃 Légumes & Feuilles',
            subcategory: 'Pâtes & Gâteaux Traditionnels',
            description: 'Gâteau de cornilles onctueux cuit à l\'étouffée.',
            image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&auto=format&fit=crop&q=80',
            availability: 'disponible',
            portions: [{ id: 'standard', name: 'Portion généreuse', price: 2500 }],
            includedAccompaniments: ['Plantain mûr vapeur'],
          },
          quantity: 2,
          selectedPortion: { id: 'standard', name: 'Portion généreuse', price: 2500 },
          selectedAccompaniment: 'Plantain mûr vapeur',
          selectedExtraAccompaniments: [],
          selectedSupplements: [],
          selectedPreparationOptions: [],
          unitPrice: 2500,
          totalPrice: 5000,
        }
      ],
      subtotal: 5000,
      deliveryFee: 0,
      total: 5000,
      customerName: 'Fabrice E.',
      customerPhone: '693 77 12 34',
      neighborhood: 'Odza',
      manualAddress: 'Borne 10 Odza, après le Collège',
      landmark: 'Maison crépie en jaune',
      paymentMethod: 'om',
      status: 'delivered',
    },
    {
      id: 'CMD-207183',
      createdAt: new Date(now.getTime() - 76 * 3600 * 1000).toISOString(), // 3 days ago
      items: [
        {
          id: 'item-7',
          item: {
            id: 'met-1',
            name: 'Poulet DG Royal Traditionnel',
            category: '🍃 Légumes & Feuilles',
            subcategory: 'Spécialités Traditionnelles',
            description: 'Poulet fermier mijoté aux plantains mûrs.',
            image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=600&auto=format&fit=crop&q=80',
            availability: 'disponible',
            portions: [{ id: 'familiale', name: 'Familiale (4-6 pers.)', price: 11000 }],
            includedAccompaniments: ['Plantains mûrs frits'],
          },
          quantity: 1,
          selectedPortion: { id: 'familiale', name: 'Familiale (4-6 pers.)', price: 11000 },
          selectedAccompaniment: 'Plantains mûrs frits',
          selectedExtraAccompaniments: [],
          selectedSupplements: [],
          selectedPreparationOptions: ['Piment à part'],
          unitPrice: 11000,
          totalPrice: 11000,
        }
      ],
      subtotal: 11000,
      deliveryFee: 0,
      total: 11000,
      customerName: 'Dieudonné O.',
      customerPhone: '674 55 66 77',
      neighborhood: 'Bastos',
      manualAddress: 'Quartier Golf, Bastos',
      landmark: 'Résidence des Ambassadeurs',
      paymentMethod: 'momo',
      status: 'delivered',
    }
  ];

  try {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(sampleOrders));
  } catch {}
  return sampleOrders;
}

export function saveStoredOrders(orders: Order[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  } catch (e) {
    console.error('Error saving orders', e);
  }
}

export function saveStoredOrder(order: Order): void {
  try {
    const orders = getStoredOrders();
    const updated = [order, ...orders.filter(o => o.id !== order.id)];
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving order', e);
  }
}

export function updateStoredOrder(updatedOrder: Order): void {
  try {
    const orders = getStoredOrders();
    const updated = orders.map(o => o.id === updatedOrder.id ? updatedOrder : o);
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(updated));
  } catch (e) {
    console.error('Error updating order', e);
  }
}

export function updateStoredOrderStatus(orderId: string, status: Order['status'], note?: string, cancellationReason?: string): void {
  try {
    const orders = getStoredOrders();
    const updated = orders.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          status,
          ...(note !== undefined ? { adminNote: note } : {}),
          ...(cancellationReason !== undefined ? { cancellationReason } : {}),
        };
      }
      return o;
    });
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(updated));
  } catch (e) {
    console.error(e);
  }
}

export function deleteStoredOrder(orderId: string): void {
  try {
    const orders = getStoredOrders();
    const updated = orders.filter(o => o.id !== orderId);
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(updated));
  } catch (e) {
    console.error(e);
  }
}

export function resetOrdersToDemo(): Order[] {
  try {
    localStorage.removeItem(STORAGE_KEYS.ORDERS);
  } catch {}
  return getStoredOrders();
}

export function clearAllStoredOrders(): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify([]));
  } catch {}
}

export function getSavedCustomer(): { name: string; phone: string; neighborhood: string; landmark: string } {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SAVED_CUSTOMER);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error(e);
  }
  return { name: '', phone: '', neighborhood: 'Bastos', landmark: '' };
}

export function saveCustomerInfo(info: { name: string; phone: string; neighborhood: string; landmark: string }): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SAVED_CUSTOMER, JSON.stringify(info));
  } catch (e) {
    console.error(e);
  }
}
