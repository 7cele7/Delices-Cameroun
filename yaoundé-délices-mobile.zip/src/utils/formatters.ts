export function formatFCFA(amount: number): string {
  return new Intl.NumberFormat('fr-FR', {
    style: 'decimal',
    maximumFractionDigits: 0
  }).format(amount) + ' FCFA';
}

export function formatPhoneNumber(phone: string): string {
  // Clean non-digit characters
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 9) {
    return `${cleaned.slice(0, 1)} ${cleaned.slice(1, 3)} ${cleaned.slice(3, 5)} ${cleaned.slice(5, 7)} ${cleaned.slice(7, 9)}`;
  }
  return phone;
}

export function generateOrderId(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = 'YD-';
  for (let i = 0; i < 5; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export function isRestaurantOpen(opening: string = "11:00", closing: string = "22:00"): { isOpen: boolean; message: string } {
  const now = new Date();
  const currentHour = now.getHours();
  const currentMin = now.getMinutes();
  const currentTime = currentHour * 60 + currentMin;

  const [openH, openM] = opening.split(':').map(Number);
  const [closeH, closeM] = closing.split(':').map(Number);
  
  const openTime = openH * 60 + (openM || 0);
  const closeTime = closeH * 60 + (closeM || 0);

  // Sunday check (optional)
  const isSunday = now.getDay() === 0;

  if (isSunday) {
    return {
      isOpen: false,
      message: 'Fermé le dimanche (Réouverture lundi à 11h)'
    };
  }

  if (currentTime >= openTime && currentTime < closeTime) {
    return {
      isOpen: true,
      message: `Ouvert actuellement • Fermeture à ${closing}`
    };
  } else {
    return {
      isOpen: false,
      message: `Fermé actuellement • Ouverture à ${opening}`
    };
  }
}
