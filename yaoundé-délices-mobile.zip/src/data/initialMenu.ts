import { CategoryDef, MenuItem, RestaurantConfig, SupplementOption, ExtraAccompanimentOption } from '../types';

export const DEFAULT_RESTAURANT_CONFIG: RestaurantConfig = {
  restaurantName: "Yaoundé Délices",
  phoneCall: "+237 6 70 00 00 00",
  phoneWhatsApp: "237670000000",
  momoNumber: "6 70 00 00 00",
  momoName: "YAOUNDE DELICES",
  omNumber: "6 90 00 00 00",
  omName: "YAOUNDE DELICES",
  momoEnabled: true,
  omEnabled: true,
  cashEnabled: true,
  customPaymentMethods: [],
  freeDeliveryThreshold: 5000,
  standardDeliveryFee: 1000,
  openingTime: "11:00",
  closingTime: "22:00",
  workingDays: "Lundi au Samedi",
  city: "Yaoundé, Cameroun",
  deliveryZones: [
    "Bastos",
    "Mvog-Mbi",
    "Mokolo",
    "Etoudi",
    "Nlongkak",
    "Omnisports",
    "Biyem-Assi",
    "Tsinga",
    "Odza",
    "Mendong",
    "Essos",
    "Melen",
    "Santa Barbara",
    "Nkolbisson",
    "Ngousso",
    "Emana",
    "Ekounou",
    "Messassi",
    "Madagascar",
    "Camp SIC"
  ],
  adminPassword: "yaounde2026"
};

export const DEFAULT_CATEGORIES: CategoryDef[] = [
  {
    id: 'cat-1',
    name: 'Légumes & Feuilles',
    icon: '🍃',
    subcategories: ['Légumes traditionnels', 'Feuilles sautées', 'Feuilles en sauce']
  },
  {
    id: 'cat-2',
    name: 'Grillades & Braises',
    icon: '🔥',
    subcategories: ['Poissons braisés', 'Volailles braisées', 'Viandes braisées', 'Brochettes & Soya']
  },
  {
    id: 'cat-3',
    name: 'Rôtis',
    icon: '🍖',
    subcategories: ['Poulet rôti', 'Porc rôti', 'Viandes rôties']
  },
  {
    id: 'cat-4',
    name: 'Fritures',
    icon: '🍟',
    subcategories: ['Beignets & Street food', 'Poissons frits', 'Poulet & Viandes frites']
  },
  {
    id: 'cat-5',
    name: 'Plats en sauce',
    icon: '🍲',
    subcategories: ['Sauces jaunes & Traditionnelles', 'Sauces arachide & Gombo', 'Sauces tomate & Ragouts']
  },
  {
    id: 'cat-6',
    name: 'Accompagnements',
    icon: '🍚',
    subcategories: ['Tubercules & Bâtons', 'Féculents frits & Alloco', 'Riz & Céréales']
  },
  {
    id: 'cat-7',
    name: 'Salades & Crudités',
    icon: '🥗',
    subcategories: ['Salades composées', 'Crudités & Vinaigrettes']
  },
  {
    id: 'cat-8',
    name: 'Boissons',
    icon: '🧃',
    subcategories: ['Jus naturels & Foléré', 'Boissons gazeuses & Eau', 'Bières locales']
  }
];

export const STANDARD_SUPPLEMENTS: SupplementOption[] = [
  { id: 'sup-poisson', name: 'Poisson braisé extra', price: 2000 },
  { id: 'sup-poulet', name: 'Poulet tendre extra', price: 1500 },
  { id: 'sup-viande', name: 'Viande de bœuf extra', price: 1500 },
  { id: 'sup-crevettes', name: 'Crevettes royales', price: 1500 },
  { id: 'sup-oeuf', name: 'Œuf dur', price: 500 },
  { id: 'sup-sauce', name: 'Sauce supplémentaire', price: 300 }
];

export const STANDARD_EXTRA_ACCOMPANIMENTS: ExtraAccompanimentOption[] = [
  { id: 'acc-plantain', name: 'Portion Plantains frits (Alloco)', price: 500 },
  { id: 'acc-bobolo', name: 'Bâton de manioc (Bobolo/Miondo)', price: 300 },
  { id: 'acc-riz', name: 'Portion Riz parfumé', price: 500 },
  { id: 'acc-frites', name: 'Portion Frites de pomme', price: 600 }
];

export const INITIAL_MENU_ITEMS: MenuItem[] = [
  // 1. Légumes & Feuilles
  {
    id: 'plat-sanga',
    name: 'Sanga Traditionnel',
    category: 'Légumes & Feuilles',
    subcategory: 'Légumes traditionnels',
    description: 'Plat traditionnel camerounais à base de feuilles de zom fraîches, maïs doux tendre et jus de noix de palme mijoté au feu de bois.',
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
    badge: 'Spécialité du Terroir',
    popular: true,
    preparationTime: '25-35 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Petite', price: 2500, servesInfo: '1 personne' },
      { id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande', price: 4500, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Familiale', price: 8000, servesInfo: '4-6 personnes' }
    ],
    includedAccompaniments: ['Plantain vapeur', 'Riz parfumé', 'Manioc bouilli', 'Sans accompagnement inclus'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-poisson', name: 'Poisson fumé', price: 2000 },
      { id: 'sup-poulet', name: 'Poulet fermier', price: 1500 },
      { id: 'sup-oeuf', name: 'Œuf dur', price: 500 },
      { id: 'sup-sauce', name: 'Sauce supplémentaire', price: 300 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment à part', 'Bien épicé / pimenté']
  },
  {
    id: 'plat-ndole',
    name: 'Ndolé Royal Viande & Crevettes',
    category: 'Légumes & Feuilles',
    subcategory: 'Feuilles en sauce',
    description: 'Feuilles de ndolé amères blanchies, pâte d’arachides fraîches, crevettes fumées et morceaux de bœuf juteux dorés aux oignons.',
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
    badge: 'Incontournable',
    popular: true,
    preparationTime: '20-30 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Petite', price: 2500, servesInfo: '1 personne' },
      { id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande', price: 5000, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Familiale', price: 9000, servesInfo: '4-6 personnes' }
    ],
    includedAccompaniments: ['Miondo / Bobolo', 'Plantains frits', 'Plantains vapeur', 'Riz blanc'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-crevettes', name: 'Crevettes fraîches sautées', price: 1500 },
      { id: 'sup-viande', name: 'Viande de bœuf extra', price: 1500 },
      { id: 'sup-poisson', name: 'Poisson fumé', price: 2000 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment à part', 'Bien épicé / pimenté']
  },
  {
    id: 'plat-eru',
    name: 'Eru & Waterfufu Traditionnel',
    category: 'Légumes & Feuilles',
    subcategory: 'Légumes traditionnels',
    description: 'Feuilles d’okazi sauvages et waterleaf mijotées à l’huile de palme avec peau de bœuf (kanda), viande fumée et écrevisses.',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    badge: 'Saveur Sud-Ouest',
    popular: false,
    preparationTime: '20-30 min',
    availability: 'disponible',
    portions: [
      { id: 'standard', name: 'Standard', price: 3000, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande', price: 4500, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Familiale', price: 8000, servesInfo: '4-5 personnes' }
    ],
    includedAccompaniments: ['Waterfufu traditionnel', 'Garri jaune', 'Plantain mûr'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-viande', name: 'Kanda & Viande fumée extra', price: 1500 },
      { id: 'sup-poisson', name: 'Poisson séché extra', price: 2000 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment doux', 'Bien pimenté']
  },

  // 2. Grillades & Braises
  {
    id: 'plat-poisson-braise',
    name: 'Poisson Braisé au Feu de Bois (Bar / Capitaine)',
    category: 'Grillades & Braises',
    subcategory: 'Poissons braisés',
    description: 'Poisson frais mariné aux épices du pays (djansang, pébè, rondelles), grillé lentement à la braise avec sauce pimentée et oignons.',
    image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=800&q=80',
    badge: 'Coup de Cœur',
    popular: true,
    preparationTime: '30-40 min',
    availability: 'disponible',
    portions: [
      { id: 'standard', name: 'Moyen (Standard)', price: 4000, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grand Bar Royal', price: 5500, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Bar Géant Familial', price: 9500, servesInfo: '3-4 personnes' }
    ],
    includedAccompaniments: ['Bâton de manioc (Bobolo)', 'Plantain mûr braisé', 'Frites de pomme', 'Plantains frits'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-sauce-extra', name: 'Sauce piment braise maison', price: 300 },
      { id: 'sup-crevettes', name: 'Crevettes braisées (+4 pcs)', price: 1500 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment fort à part', 'Piment doux', 'Bien grillé croustillant']
  },
  {
    id: 'plat-poulet-braise',
    name: 'Poulet Fermier Braisé aux Épices',
    category: 'Grillades & Braises',
    subcategory: 'Volailles braisées',
    description: 'Demi ou Poulet entier fermier mariné au gingembre, ail, poivre blanc de Penja et braisé à point.',
    image: 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=800&q=80',
    badge: 'Best Seller',
    popular: true,
    preparationTime: '25-35 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Quart de poulet', price: 2000, servesInfo: '1 personne' },
      { id: 'standard', name: 'Demi Poulet', price: 3500, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Poulet Entier', price: 6500, servesInfo: '2-4 personnes' },
      { id: 'familiale', name: 'Poulet Entier XXL + Garnitures', price: 9000, servesInfo: '4-6 personnes' }
    ],
    includedAccompaniments: ['Plantains frits (Alloco)', 'Bâton de manioc', 'Frites de pomme'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-sauce', name: 'Sauce pimentée supplémentaire', price: 300 },
      { id: 'sup-oeuf', name: 'Œuf dur', price: 500 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment à part', 'Sauce à part']
  },
  {
    id: 'plat-soya-boeuf',
    name: 'Soya de Bœuf & Brochettes au Kankankan',
    category: 'Grillades & Braises',
    subcategory: 'Brochettes & Soya',
    description: 'Fines lamelles de bœuf tendre et brochettes assaisonnées au kankankan traditionnel, servies avec rondelles d’oignons frais et piment.',
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80',
    badge: 'Street Grill',
    popular: true,
    preparationTime: '15-20 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Petite barquette (5 brochettes)', price: 1500, servesInfo: '1 personne' },
      { id: 'standard', name: 'Barquette Standard (10 brochettes)', price: 2500, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Barquette Grande (16 brochettes)', price: 4000, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Plateau Soya Festif (30 brochettes)', price: 7500, servesInfo: '4-6 personnes' }
    ],
    includedAccompaniments: ['Bâton de manioc', 'Oignons frais marinés', 'Plantain frit'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-sauce', name: 'Piment kankankan supplémentaire', price: 300 },
      { id: 'sup-oeuf', name: 'Œuf dur', price: 500 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment très fort', 'Piment doux']
  },

  // 3. Rôtis
  {
    id: 'plat-poulet-roti',
    name: 'Poulet Rôti Doré au Four & Aromates',
    category: 'Rôtis',
    subcategory: 'Poulet rôti',
    description: 'Poulet fermier rôti lentement au four, peau croustillante et chair tendre infusée d’ail, romarin et poivre blanc de Penja.',
    image: 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=800&q=80',
    popular: false,
    preparationTime: '25-30 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Quart de poulet rôti', price: 2000, servesInfo: '1 personne' },
      { id: 'standard', name: 'Demi Poulet rôti', price: 3500, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Poulet Rôti Entier', price: 6500, servesInfo: '2-4 personnes' },
      { id: 'familiale', name: 'Pack Rôti Familial', price: 9000, servesInfo: '4-6 personnes' }
    ],
    includedAccompaniments: ['Frites de pomme', 'Riz parfumé', 'Plantains frits'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: STANDARD_SUPPLEMENTS,
    preparationOptions: ['Sans sel ajouté', 'Sauce à part', 'Piment à part']
  },
  {
    id: 'plat-porc-roti',
    name: 'Porc Rôti Croustillant Yaoundé',
    category: 'Rôtis',
    subcategory: 'Porc rôti',
    description: 'Quartiers de porc frais marinés et rôtis jusqu’à caramélisation parfaite, servis avec jus de cuisson épicé.',
    image: 'https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=800&q=80',
    badge: 'Spécialité',
    popular: true,
    preparationTime: '20-25 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Petite portion (300g)', price: 2000, servesInfo: '1 personne' },
      { id: 'standard', name: 'Portion Standard (500g)', price: 3500, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande portion (800g)', price: 5000, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Plat Familial (1.5 kg)', price: 9000, servesInfo: '4-6 personnes' }
    ],
    includedAccompaniments: ['Bâton de manioc', 'Plantains frits', 'Frites de pomme'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: STANDARD_SUPPLEMENTS,
    preparationOptions: ['Sans sel ajouté', 'Piment à part', 'Bien croustillant']
  },

  // 4. Fritures
  {
    id: 'plat-bhb',
    name: 'Beignets Haricots & Bouillie (BHB)',
    category: 'Fritures',
    subcategory: 'Beignets & Street food',
    description: 'Le grand classique du matin et du soir à Yaoundé : beignets dorés croustillants, haricots rouges savoureux et bouillie de maïs.',
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=800&q=80',
    badge: 'Street Food',
    popular: true,
    preparationTime: '10-15 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Petite portion', price: 700, servesInfo: '1 personne' },
      { id: 'standard', name: 'Portion Standard', price: 1200, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande Portion Duo', price: 2000, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Pack Familial BHB', price: 3500, servesInfo: '4-5 personnes' }
    ],
    includedAccompaniments: ['Sucre & Citron inclus', 'Piment rouge maison'],
    extraAccompaniments: [
      { id: 'acc-beignets', name: 'Portion de 5 beignets extra', price: 300 },
      { id: 'acc-haricots', name: 'Portion haricots extra', price: 400 }
    ],
    supplements: [
      { id: 'sup-oeuf', name: 'Œuf dur', price: 500 },
      { id: 'sup-viande', name: 'Viande sautée extra', price: 1500 }
    ],
    preparationOptions: ['Sans sel ajouté dans les haricots', 'Piment à part', 'Bouillie sans sucre']
  },
  {
    id: 'plat-poisson-frit',
    name: 'Poisson Frit Doré à la Camerounaise',
    category: 'Fritures',
    subcategory: 'Poissons frits',
    description: 'Daurade ou Bar frit croustillant assaisonné au poivre vert et ail, accompagné de sa sauce tomate pimentée maison.',
    image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=800&q=80',
    popular: false,
    preparationTime: '20 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Petite daurade', price: 2000, servesInfo: '1 personne' },
      { id: 'standard', name: 'Portion Standard', price: 3000, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande Daurade Royale', price: 4500, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Plateau de Poissons Frits (3 pcs)', price: 8000, servesInfo: '4-5 personnes' }
    ],
    includedAccompaniments: ['Plantains frits (Alloco)', 'Bâton de manioc', 'Frites de pomme'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: STANDARD_SUPPLEMENTS,
    preparationOptions: ['Sans sel ajouté', 'Piment à part']
  },

  // 5. Plats en sauce
  {
    id: 'plat-poulet-dg',
    name: 'Poulet DG Royal Camerounais',
    category: 'Plats en sauce',
    subcategory: 'Sauces tomate & Ragouts',
    description: 'Poulet mijoté aux dés de plantains mûrs dorés, carottes, haricots verts, poivrons colorés et jus aromatisé aux épices locales.',
    image: 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=800&q=80',
    badge: 'Spécialité Nationale',
    popular: true,
    preparationTime: '25-35 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Petite', price: 2500, servesInfo: '1 personne' },
      { id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande', price: 5000, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Familiale (Plat de fête)', price: 9000, servesInfo: '4-6 personnes' }
    ],
    includedAccompaniments: ['Plantains mûrs inclus', 'Riz blanc parfumé', 'Frites de pomme'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-poulet', name: 'Poulet extra', price: 1500 },
      { id: 'sup-oeuf', name: 'Œuf dur', price: 500 },
      { id: 'sup-sauce', name: 'Sauce supplémentaire', price: 300 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment à part', 'Bien épicé / pimenté']
  },
  {
    id: 'plat-sauce-jaune',
    name: 'Sauce Jaune Royale & Taro Pilé (Achu)',
    category: 'Plats en sauce',
    subcategory: 'Sauces jaunes & Traditionnelles',
    description: 'Sauce jaune parfumée aux épices médicinales traditionnelles (achuispices, canfa), huile de palme, peau de bœuf et tripes, servie avec taro pilé.',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=80',
    badge: 'Authentique Nord-Ouest',
    popular: false,
    preparationTime: '25-30 min',
    availability: 'disponible',
    portions: [
      { id: 'standard', name: 'Standard', price: 3500, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande', price: 5000, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Familiale', price: 8500, servesInfo: '4-5 personnes' }
    ],
    includedAccompaniments: ['Taro pilé traditionnel', 'Plantain pilé'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-viande', name: 'Tripes & Kanda extra', price: 1500 },
      { id: 'sup-poisson', name: 'Poisson fumé', price: 2000 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment doux', 'Bien relevé tradition']
  },
  {
    id: 'plat-koki',
    name: 'Koki de Corn aux Feuilles de Bananier',
    category: 'Plats en sauce',
    subcategory: 'Sauces jaunes & Traditionnelles',
    description: 'Gâteau de niébé doré à l’huile de palme rouge et piment doux, cuit à l’étouffée dans des feuilles de bananier.',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=80',
    popular: false,
    preparationTime: '15-20 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: '1 Paquet Koki', price: 1500, servesInfo: '1 personne' },
      { id: 'standard', name: '2 Paquets Koki', price: 2800, servesInfo: '1-2 personnes' },
      { id: 'grande', name: '3 Paquets Koki', price: 4000, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Pack Festif (6 Paquets)', price: 7500, servesInfo: '4-6 personnes' }
    ],
    includedAccompaniments: ['Plantain mûr vapeur', 'Manioc bouilli', 'Patate douce vapeur'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-oeuf', name: 'Œuf dur', price: 500 },
      { id: 'sup-poisson', name: 'Poisson fumé', price: 2000 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment à part']
  },

  // 6. Accompagnements
  {
    id: 'plat-alloco-solo',
    name: 'Grande Portion de Plantains Frits (Alloco)',
    category: 'Accompagnements',
    subcategory: 'Féculents frits & Alloco',
    description: 'Rondelles ou dés de plantains bien mûrs frits à l’huile dorée, moelleux à cœur et croustillants sur les bords.',
    image: 'https://images.unsplash.com/photo-1528751014936-863e6e7a319c?auto=format&fit=crop&w=800&q=80',
    popular: false,
    preparationTime: '10 min',
    availability: 'disponible',
    portions: [
      { id: 'standard', name: 'Portion Standard', price: 1000, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande Portion', price: 1800, servesInfo: '2-3 personnes' },
      { id: 'familiale', name: 'Plat Familial', price: 3000, servesInfo: '4-5 personnes' }
    ],
    includedAccompaniments: ['Piment doux à part', 'Sauce tomate oignons'],
    extraAccompaniments: [],
    supplements: [
      { id: 'sup-oeuf', name: 'Œuf dur', price: 500 },
      { id: 'sup-sauce', name: 'Sauce supplémentaire', price: 300 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Piment à part']
  },
  {
    id: 'plat-bobolo-miondo',
    name: 'Assortiment de Bâtons de Manioc & Miondo',
    category: 'Accompagnements',
    subcategory: 'Tubercules & Bâtons',
    description: 'Pâte de manioc fermentée roulée dans des feuilles de marantacées et cuite à la vapeur.',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    popular: false,
    preparationTime: '5 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Lot de 3 Bâtons', price: 800, servesInfo: '1 personne' },
      { id: 'standard', name: 'Lot de 6 Bâtons', price: 1500, servesInfo: '2 personnes' },
      { id: 'grande', name: 'Lot de 12 Bâtons', price: 2800, servesInfo: '3-4 personnes' }
    ],
    includedAccompaniments: ['Feuilles fraîches protégées'],
    extraAccompaniments: [],
    supplements: [
      { id: 'sup-sauce', name: 'Sauce piment', price: 300 }
    ],
    preparationOptions: ['Chaud à la vapeur']
  },

  // 7. Salades & Crudités
  {
    id: 'plat-salade-avocat',
    name: 'Salade Tropicale Avocat & Crevettes de Kribi',
    category: 'Salades & Crudités',
    subcategory: 'Salades composées',
    description: 'Avocats crémeux de Mbouda, crevettes fraîches de Kribi, tomates cerises, concombres croquants, maïs doux et vinaigrette aux herbes.',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    badge: 'Fraîcheur',
    popular: false,
    preparationTime: '15 min',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Petite', price: 1800, servesInfo: '1 personne' },
      { id: 'standard', name: 'Standard', price: 2800, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Grande Salade Bol', price: 4200, servesInfo: '2-3 personnes' }
    ],
    includedAccompaniments: ['Vinaigrette maison à part', 'Tranches de pain grillé'],
    extraAccompaniments: STANDARD_EXTRA_ACCOMPANIMENTS,
    supplements: [
      { id: 'sup-crevettes', name: 'Crevettes supplémentaires', price: 1500 },
      { id: 'sup-oeuf', name: 'Œuf dur', price: 500 }
    ],
    preparationOptions: ['Sans sel ajouté', 'Sauce vinaigrette à part']
  },

  // 8. Boissons
  {
    id: 'plat-folere',
    name: 'Jus de Foléré Glacé Maison (Bissap)',
    category: 'Boissons',
    subcategory: 'Jus naturels & Foléré',
    description: 'Infusion fraîche de calices d’hibiscus parfumé aux feuilles de menthe fraîche, ananas victoria pressé et vanille.',
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80',
    badge: '100% Naturel',
    popular: true,
    preparationTime: 'Immédiat',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Bouteille 33cl', price: 500, servesInfo: '1 personne' },
      { id: 'standard', name: 'Bouteille 50cl', price: 800, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Bouteille 1.5L', price: 2000, servesInfo: '3-4 personnes' },
      { id: 'familiale', name: 'Pack Fête (3 x 1.5L)', price: 5500, servesInfo: '6-10 personnes' }
    ],
    includedAccompaniments: ['Très frais / glaçons'],
    extraAccompaniments: [],
    supplements: [],
    preparationOptions: ['Peu sucré', 'Bien glacé']
  },
  {
    id: 'plat-gingembre',
    name: 'Cocktail Pur Jus de Gingembre & Citron Vert',
    category: 'Boissons',
    subcategory: 'Jus naturels & Foléré',
    description: 'Gingembre camerounais pressé à froid, jus de citron vert et une touche de miel pour un coup de fouet revigorant.',
    image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=800&q=80',
    badge: 'Énergisant',
    popular: false,
    preparationTime: 'Immédiat',
    availability: 'disponible',
    portions: [
      { id: 'petite', name: 'Bouteille 33cl', price: 500, servesInfo: '1 personne' },
      { id: 'standard', name: 'Bouteille 50cl', price: 800, servesInfo: '1-2 personnes' },
      { id: 'grande', name: 'Bouteille 1.5L', price: 2000, servesInfo: '3-4 personnes' }
    ],
    includedAccompaniments: ['Très frais'],
    extraAccompaniments: [],
    supplements: [],
    preparationOptions: ['Bien glacé']
  }
];
